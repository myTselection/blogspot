#!/bin/sh

#SETUP
REPO_URL=https://url:8443/base/project
REPO_PATH=c:/repository/project
DUMP_DIR=/home/user/dumps
LAST_DELTA_FILE=svn_backup_delta.txt
#BEGINING OF THE SCRIPT ITSELF

date=$(date +%Y%m%d)
LOG=dump-$date.log


LAST_REV=$(svn info $REPO_URL |grep Revision |gawk ' { print $2}')

#Both files MUST exist, otherwise, wer'e going to init new "delting"

if [ -e $LAST_DELTA_FILE ] ; then
	LAST_DELTA=$(cat $LAST_DELTA_FILE)
	if [ $LAST_DELTA -ne $LAST_REV ] ; then
		DUMP_FILE_NAME=$date-INCREMENTAL-R$((LAST_DELTA+1))-TO-R$LAST_REV.dump.gz
		DUMP_FILE=$DUMP_DIR/$DUMP_FILE_NAME
		svnadmin dump $REPO_PATH -r $((LAST_DELTA +1)):$LAST_REV --incremental --deltas 2>>$LOG |gzip -c > $DUMP_FILE
	else
		echo nothing to do : last revision number is same as last delta number, run it again later !
		exit 0
	fi
else
	DUMP_FILE_NAME=$date-INITIAL-R$LAST_REV.dump.gz
	DUMP_FILE=$DUMP_DIR/$DUMP_FILE_NAME
	svnadmin dump $REPO_PATH 2>>$LOG | gzip -c > $DUMP_FILE
fi

#Is all ok ?
if [ $? -eq 0 ] ; then
	rm $DUMP_FILE
	echo -n $LAST_REV > $LAST_DELTA_FILE
else
	echo "ERROR :" $date "Problem occured while saving dump" >>$LOG
fi
