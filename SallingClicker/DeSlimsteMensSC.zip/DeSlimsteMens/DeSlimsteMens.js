//myT De Slimste Mens
//http://myTselection.blogspot.com
//UUID generator: http://www.famkruithof.net/uuid/uuidgen

var browserExe = "iexplore.exe";
var browserName = "Internet Explorer";
var browserClass = "IEFrame";
var browserContentClass = "MacromediaFlashPlayerActiveX";
var browserOpenDialogClass = "#32770";
var browserObject = null;
var fso = new ActiveXObject( "Scripting.FileSystemObject" );


var playerNames = new Array();
playerNames[1] = ["Speler 1",60,1];
playerNames[2] = ["Speler 2",60,2];
playerNames[3] = ["Speler 3",60,3];
playerNames[4] = ["Speler 4",60,4];

var sortedPlayerNames = new Array();
var sortedFinalPlayerNames = new Array();


var switchScorePanel = false;
var enableRoundInfoPanel = true;
var repeatImageGallery = true;
var repeatSameImageGallery = true;
var short369 = false;
var activePlayer = 0;
var activePlayerTiming = new Date();
var fileSizeLineLimit = 1000;
var currentImageBaseFolder = "";


var questions369 = null;
var openDourMovies = null;
var puzzels = null;
var galleries = null;
var collectiveMemories = null;
var finals = null;


//3-6-9
var info369Shown = false;
var current369QuestionNumber = 0;
var questions369SendKeys = new Array();
questions369SendKeys = ["a","z","e","r","t","y","q","s","d","f","g","h","x","c","v"];
var played369 = new Array();
played369 = [0, 0, 0, 0]; //keep track for each player (location in array) if the player played the current question (value in array)
var previousActive369Player = 0;

//OPEN DOUR
var infoOpenDourShown = false;
var openDourMoviesSendKeys = new Array();
openDourMoviesSendKeys = ["a","z","e","r"];
var openDourMoviesAnswersFound = new Array();
openDourMoviesAnswersFound[0] = [false,false,false,false];
openDourMoviesAnswersFound[1] = [false,false,false,false];
openDourMoviesAnswersFound[2] = [false,false,false,false];
openDourMoviesAnswersFound[3] = [false,false,false,false];
var playedOpenDour = new Array();
playedOpenDour = [0, 0, 0, 0]; //keep track if the player played the current open dour
var currentOpenDourMovie = 0;
var currentOpenDourMoviePlayer = 0;


//PUZZEL
var infoPuzzelShown = false;
var puzzelSendKeys = new Array();
puzzelSendKeys = ["a","z","e"];
var puzzelsAnswersFound = new Array();
puzzelsAnswersFound[0] = [false,false,false];
puzzelsAnswersFound[1] = [false,false,false];
puzzelsAnswersFound[2] = [false,false,false];
puzzelsAnswersFound[3] = [false,false,false];
var playedPuzzel = new Array();
playedPuzzel = [0, 0, 0, 0]; //keep track for each player (location in array) if the player played the current puzzel (value in puzzel)
var currentPuzzel = 0;
var currentPuzzelPlayer = 0;


//GALLERY
var infoGalleryShown = false;
var playedGallery = new Array();
playedGallery = [0, 0, 0, 0]; //keep track for each player (location in array) if the player played the current gallery (value in gallery)
var currentGallery = 0;
var currentGalleryPlayer = 0;
var currentGalleryImageNumber = 0;
var galleriesAnswersFound = new Array();
var galleryCorrectAnswers = 0;
galleriesAnswersFound[0] = [false,false,false,false,false,false,false,false,false,false];
galleriesAnswersFound[1] = [false,false,false,false,false,false,false,false,false,false];
galleriesAnswersFound[2] = [false,false,false,false,false,false,false,false,false,false];
galleriesAnswersFound[3] = [false,false,false,false,false,false,false,false,false,false];
var galleryMediaWidget;
var galleryMediaWidgetCurrentStartTime = new Date();


//COLLECTIVE MEMORY
var infoCollectiveMemoryShown = false;
var collectiveMemorySendKeys = new Array();
collectiveMemorySendKeys = ["a","z","e","r","t"];
var collectiveMemoryAnswersFound = new Array(); //keep track if the answers are found
collectiveMemoryAnswersFound[0] = [false,false,false,false,false];
collectiveMemoryAnswersFound[1] = [false,false,false,false,false];
collectiveMemoryAnswersFound[2] = [false,false,false,false,false];
collectiveMemoryAnswersFound[3] = [false,false,false,false,false];
var collectiveMemoryAnswerSolvedSequence = 1;
var playedCollectiveMemory = new Array();
playedCollectiveMemory = [0, 0, 0, 0]; //keep track if the player played the current collective memory
var currentCollectiveMemory = 0;
var currentCollectiveMemoryPlayer = 0;


//FINALS
var infoFinalsShown = false;
var finalsSendKeys = new Array();
finalsSendKeys = ["a","z","e","r","t"];
var finalsAnswersFound = new Array(); //keep track if the answers are found
finalsAnswersFound[0] = [false,false,false,false,false];
finalsAnswersFound[1] = [false,false,false,false,false];
finalsAnswersFound[2] = [false,false,false,false,false];
finalsAnswersFound[3] = [false,false,false,false,false];
finalsAnswersFound[4] = [false,false,false,false,false];
finalsAnswersFound[5] = [false,false,false,false,false];
finalsAnswersFound[6] = [false,false,false,false,false];
finalsAnswersFound[7] = [false,false,false,false,false];
finalsAnswersFound[8] = [false,false,false,false,false];
finalsAnswersFound[9] = [false,false,false,false,false];
finalsAnswersFound[10] = [false,false,false,false,false];
finalsAnswersFound[11] = [false,false,false,false,false];
finalsAnswersFound[12] = [false,false,false,false,false];
finalsAnswersFound[13] = [false,false,false,false,false];
finalsAnswersFound[14] = [false,false,false,false,false];
finalsAnswersFound[15] = [false,false,false,false,false];
finalsAnswersFound[16] = [false,false,false,false,false];
finalsAnswersFound[17] = [false,false,false,false,false];
finalsAnswersFound[18] = [false,false,false,false,false];
finalsAnswersFound[19] = [false,false,false,false,false];
finalsAnswersFound[20] = [false,false,false,false,false];
finalsAnswersFound[21] = [false,false,false,false,false];
finalsAnswersFound[22] = [false,false,false,false,false];
finalsAnswersFound[23] = [false,false,false,false,false];
finalsAnswersFound[24] = [false,false,false,false,false];
finalsAnswersFound[25] = [false,false,false,false,false];
finalsAnswersFound[26] = [false,false,false,false,false];
var playedFinals = new Array();
playedFinals = [0, 0]; //keep track if the player played the current final
var firstTimeShowFinalsPlayerMenu = true;
var finalPlayer1 = 0;
var finalPlayer2 = 0;


// Initialize options menu
var optionsMenuItems = new Array();
optionsMenuItems[0] = "Send long text (write on device)";
optionsMenuItems[1] = "Activate Shift key";
optionsMenuItems[2] = "Activate Ctrl key";
optionsMenuItems[3] = "Activate Alt key";
optionsMenuItems[4] = "Activate Win key";
optionsMenuItems[5] = "Send Function keys";
optionsMenuItems[6] = "Send Media keys";
optionsMenuItems[7] = "Send Combination keys";
optionsMenuItems[8] = "Send Special characters";
optionsMenuItems[9] = "Disable Scroll mode";
optionsMenuItems[10] = "Clear device home screen";
//optionsMenuItems[11] = "Send Ctrl + Alt + Delete";

var fkeysMenuItems = new Array();
fkeysMenuItems[0] = "F1";
fkeysMenuItems[1] = "F2";
fkeysMenuItems[2] = "F3";
fkeysMenuItems[3] = "F4";
fkeysMenuItems[4] = "F5";
fkeysMenuItems[5] = "F6";
fkeysMenuItems[6] = "F7";
fkeysMenuItems[7] = "F8";
fkeysMenuItems[8] = "F9";
fkeysMenuItems[9] = "F10";
fkeysMenuItems[10] = "F11";
fkeysMenuItems[11] = "F12";
fkeysMenuItems[12] = "Esc";
fkeysMenuItems[13] = "Tab";
fkeysMenuItems[14] = "End";
fkeysMenuItems[15] = "Home";
fkeysMenuItems[16] = "Page Up";
fkeysMenuItems[17] = "Page Down";
fkeysMenuItems[18] = "Insert";
fkeysMenuItems[19] = "Delete";
fkeysMenuItems[20] = "Num Lock";
fkeysMenuItems[21] = "Caps Lock";
fkeysMenuItems[22] = "Scroll Lock";
fkeysMenuItems[23] = "Print screen";
	fkeysMenuItems[24] = "Pause";
	fkeysMenuItems[25] = "Enter";
	fkeysMenuItems[26] = "Middle Mouse";
	fkeysMenuItems[27] = "Shift";
	fkeysMenuItems[28] = "Ctrl";
	fkeysMenuItems[29] = "Alt";
	fkeysMenuItems[30] = "Win";
	fkeysMenuItems[31] = "Left";
	fkeysMenuItems[32] = "Right";
	fkeysMenuItems[33] = "Up";
	fkeysMenuItems[34] = "Down";


var specialcharkeysMenuItems = new Array();
specialcharkeysMenuItems[0] = "\\";
specialcharkeysMenuItems[1] = "/";
specialcharkeysMenuItems[2] = "$";
specialcharkeysMenuItems[3] = "&";
specialcharkeysMenuItems[4] = "@";
specialcharkeysMenuItems[5] = "\'";
specialcharkeysMenuItems[6] = "(";
specialcharkeysMenuItems[7] = ")";
specialcharkeysMenuItems[8] = "^";
specialcharkeysMenuItems[9] = "\"";
specialcharkeysMenuItems[10] = "!";
specialcharkeysMenuItems[11] = "\{";
specialcharkeysMenuItems[12] = "}";
specialcharkeysMenuItems[13] = "[";
specialcharkeysMenuItems[14] = "]";
specialcharkeysMenuItems[15] = "(";
specialcharkeysMenuItems[16] = ")";
specialcharkeysMenuItems[17] = "_";
specialcharkeysMenuItems[18] = "~";
	specialcharkeysMenuItems[19] = "=";
	specialcharkeysMenuItems[20] = "|";
	specialcharkeysMenuItems[21] = "�";
	specialcharkeysMenuItems[22] = "�";
	specialcharkeysMenuItems[23] = "�";
	specialcharkeysMenuItems[24] = "�";
	specialcharkeysMenuItems[25] = "�";
	specialcharkeysMenuItems[26] = "�";
	specialcharkeysMenuItems[27] = "�";
	specialcharkeysMenuItems[28] = "�";
	specialcharkeysMenuItems[29] = "�";
	specialcharkeysMenuItems[30] = "�";
	specialcharkeysMenuItems[31] = "�";
	specialcharkeysMenuItems[32] = "�";
	specialcharkeysMenuItems[33] = "�";
	specialcharkeysMenuItems[34] = "�";
	specialcharkeysMenuItems[35] = "�";
	specialcharkeysMenuItems[36] = "�";
	specialcharkeysMenuItems[37] = "�";
	specialcharkeysMenuItems[38] = "�";
	specialcharkeysMenuItems[39] = "�";
	specialcharkeysMenuItems[40] = "�";
	specialcharkeysMenuItems[41] = "�";
	specialcharkeysMenuItems[42] = "�";
	specialcharkeysMenuItems[43] = "�";
	specialcharkeysMenuItems[44] = "�";
	specialcharkeysMenuItems[45] = "�";
	specialcharkeysMenuItems[46] = "",
	specialcharkeysMenuItems[47] = "�";
	specialcharkeysMenuItems[48] = "�";
	specialcharkeysMenuItems[49] = "�";
	specialcharkeysMenuItems[50] = "�";
	specialcharkeysMenuItems[51] = "�";
	specialcharkeysMenuItems[52] = "�";
	specialcharkeysMenuItems[53] = "�";
	specialcharkeysMenuItems[54] = "�";
	specialcharkeysMenuItems[55] = "�";
	specialcharkeysMenuItems[56] = "�";
	specialcharkeysMenuItems[57] = "�";
	specialcharkeysMenuItems[58] = "�";
	specialcharkeysMenuItems[59] = "�";
	specialcharkeysMenuItems[60] = "�";
	specialcharkeysMenuItems[61] = "�";
	specialcharkeysMenuItems[62] = "�";
	specialcharkeysMenuItems[63] = "�";
	specialcharkeysMenuItems[64] = "�";
	specialcharkeysMenuItems[65] = "�";
	specialcharkeysMenuItems[66] = "�";
	specialcharkeysMenuItems[67] = "�";
	specialcharkeysMenuItems[68] = "�";
	specialcharkeysMenuItems[69] = "�";
	specialcharkeysMenuItems[70] = "�";
	specialcharkeysMenuItems[71] = "�";
	specialcharkeysMenuItems[72] = "�";
	specialcharkeysMenuItems[73] = "�";
	specialcharkeysMenuItems[74] = "�";
	specialcharkeysMenuItems[75] = "�";
	specialcharkeysMenuItems[76] = "�";
	specialcharkeysMenuItems[77] = "�";
	specialcharkeysMenuItems[78] = "�";
	specialcharkeysMenuItems[79] = "�";
	specialcharkeysMenuItems[80] = "�";
	specialcharkeysMenuItems[81] = "�";
	specialcharkeysMenuItems[82] = "�";
	specialcharkeysMenuItems[83] = "�";
	specialcharkeysMenuItems[84] = "�";
	specialcharkeysMenuItems[85] = "�";
	specialcharkeysMenuItems[86] = "�";
	specialcharkeysMenuItems[87] = "�";
	specialcharkeysMenuItems[88] = "�";
	specialcharkeysMenuItems[89] = "�";
	specialcharkeysMenuItems[90] = "�";
	specialcharkeysMenuItems[91] = "�";
	specialcharkeysMenuItems[92] = "�";
	specialcharkeysMenuItems[93] = "�";
	specialcharkeysMenuItems[94] = "�";
	specialcharkeysMenuItems[95] = "�";
	specialcharkeysMenuItems[96] = "�";
	specialcharkeysMenuItems[97] = "�";
	specialcharkeysMenuItems[98] = "�";
	specialcharkeysMenuItems[99] = "�";
	specialcharkeysMenuItems[100] = "�";
	specialcharkeysMenuItems[101] = "�";
	specialcharkeysMenuItems[102] = "�";
	specialcharkeysMenuItems[103] = "�";
	specialcharkeysMenuItems[104] = "�";
	specialcharkeysMenuItems[105] = "�";
	specialcharkeysMenuItems[106] = "�";
	specialcharkeysMenuItems[107] = "�";
	specialcharkeysMenuItems[108] = "�";
	specialcharkeysMenuItems[109] = "�";
	specialcharkeysMenuItems[110] = "�";
	specialcharkeysMenuItems[111] = "�";
	specialcharkeysMenuItems[112] = "�";
	specialcharkeysMenuItems[113] = "�";
	specialcharkeysMenuItems[114] = "�";
	specialcharkeysMenuItems[115] = "�";
	specialcharkeysMenuItems[116] = "�";
	specialcharkeysMenuItems[117] = "�";
	specialcharkeysMenuItems[118] = "�";
	specialcharkeysMenuItems[119] = "�";
	specialcharkeysMenuItems[120] = "�";
	specialcharkeysMenuItems[121] = "�";
	specialcharkeysMenuItems[122] = "�";
	specialcharkeysMenuItems[123] = "�";
	specialcharkeysMenuItems[124] = "�";
	specialcharkeysMenuItems[125] = "�";
	specialcharkeysMenuItems[126] = "�";
	specialcharkeysMenuItems[127] = "�";
	specialcharkeysMenuItems[128] = "�";
	specialcharkeysMenuItems[129] = "�";
	specialcharkeysMenuItems[130] = "�";
	specialcharkeysMenuItems[131] = "�";
	specialcharkeysMenuItems[132] = "�";
	specialcharkeysMenuItems[133] = "�";
	specialcharkeysMenuItems[134] = "�";
	specialcharkeysMenuItems[135] = "�";
	specialcharkeysMenuItems[136] = "�";
	specialcharkeysMenuItems[137] = "�";
	specialcharkeysMenuItems[138] = "�";
	specialcharkeysMenuItems[139] = "�";
	specialcharkeysMenuItems[140] = "�";
	specialcharkeysMenuItems[141] = "�";
	specialcharkeysMenuItems[142] = "�";
	specialcharkeysMenuItems[143] = "�";


var mediakeysMenuItems = new Array();
mediakeysMenuItems[0] = "Media";
mediakeysMenuItems[1] = "Play Pause";
mediakeysMenuItems[2] = "Next track";
mediakeysMenuItems[3] = "Previous track";
mediakeysMenuItems[4] = "Stop";
mediakeysMenuItems[5] = "Mode change";
mediakeysMenuItems[6] = "Volume up";
mediakeysMenuItems[7] = "Volume down";
mediakeysMenuItems[8] = "Volume mute";
mediakeysMenuItems[9] = "Browser Back";
mediakeysMenuItems[10] = "Browser Forward";
mediakeysMenuItems[11] = "Browser Favorites";
mediakeysMenuItems[12] = "Browser Home";
mediakeysMenuItems[13] = "Browser Refresh";
mediakeysMenuItems[14] = "Browser Search";
mediakeysMenuItems[15] = "Browser Stop";
//mediakeysMenuItems[16] = "Zoom";


var scrollMenuItems = new Array();
scrollMenuItems[0] = "Scroll Up";
scrollMenuItems[1] = "Scroll Down";
scrollMenuItems[2] = "";
scrollMenuItems[3] = "Mouse Up (quick)";
scrollMenuItems[4] = "Mouse Up";
scrollMenuItems[5] = "Mouse Down (quick)";
scrollMenuItems[6] = "Mouse Down";
scrollMenuItems[7] = "Mouse Left (quick)";
scrollMenuItems[8] = "Mouse Left";
scrollMenuItems[9] = "Mouse Right (quick)";
scrollMenuItems[10] = "Mouse Right";


var localTempFolder = fso.GetSpecialFolder(2);
var ComboCount = 0;
var combinationMenuItems = new Array();
combinationMenuItems[0] = "Release All Keys";
var combinations = new Array ();
combinations[0] = "";

try {
	var combinationsFileStream = fso.OpenTextFile( resourcesPath + "\\Combinations.txt" );
	while(true) {
		ComboCount++;
		fullName = combinationsFileStream.Readline();
		if (fullName.indexOf("(") != -1 )	{
				combinationMenuItems[ComboCount] = ComboCount + ": " + fullName.slice(fullName.indexOf("(") + 1, fullName.length - 1);
				combinations[ComboCount] = fullName
		}
	}
} catch (e) {	}
finally {
	if( combinationsFileStream != null ) combinationsFileStream.Close();	
}

//supported characters to send:  !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~�����������������������������������������������������������������������������������������������
//characters that are not working (but configured): ���������������������������

var keys = new Array();
keys[32]  = [" ",""];
keys[33]  = ["!",""];
keys[34]  = ["\"",""];
keys[35]  = ["#",""];
keys[36]  = ["$",""];
keys[37]  = ["%",""];
keys[38]  = ["&",""];
keys[39]  = ["\'",""];
keys[40]  = ["(",""];
keys[41]  = [")",""];
keys[42]  = ["*",""];
keys[43]  = ["+",0x6b];
keys[44]  = [",",""];
keys[45]  = ["-",""];
keys[46]  = [".",0x6e];
keys[47]  = ["/",0x6f];
keys[48]  = ["0",0x30];
keys[49]  = ["1",0x31];
keys[50]  = ["2",0x32];
keys[51]  = ["3",0x33];
keys[52]  = ["4",0x34];
keys[53]  = ["5",0x35];
keys[54]  = ["6",0x36];
keys[55]  = ["7",0x37];
keys[56]  = ["8",0x38];
keys[57]  = ["9",0x39];
keys[58]  = [":",""];
keys[59]  = [";",""];
keys[60]  = ["<",""];
keys[61]  = ["=",""];
keys[62]  = [">",""];
keys[63]  = ["?",""];
keys[64]  = ["@",""];
keys[65]  = ["A",0x41];
keys[66]  = ["B",0x42];
keys[67]  = ["C",0x43];
keys[68]  = ["D",0x44];
keys[69]  = ["E",0x45];
keys[70]  = ["F",0x46];
keys[71]  = ["G",0x47];
keys[72]  = ["H",0x48];
keys[73]  = ["I",0x49];
keys[74]  = ["J",0x4a];
keys[75]  = ["K",0x4b];
keys[76]  = ["L",0x4c];
keys[77]  = ["M",0x4d];
keys[78]  = ["N",0x4e];
keys[79]  = ["O",0x4f];
keys[80]  = ["P",0x50];
keys[81]  = ["Q",0x51];
keys[82]  = ["R",0x52];
keys[83]  = ["S",0x53];
keys[84]  = ["T",0x54];
keys[85]  = ["U",0x55];
keys[86]  = ["V",0x56];
keys[87]  = ["W",0x57];
keys[88]  = ["X",0x58];
keys[89]  = ["Y",0x59];
keys[90]  = ["Z",0x5a];
keys[91]  = ["[",""];
keys[92]  = ["\\",""];
keys[93]  = ["]",""];
keys[94]  = ["^",""];
keys[95]  = ["_",""];
keys[96]  = ["`",""];
keys[97]  = ["a",0x41];
keys[98]  = ["b",0x42];
keys[99]  = ["c",0x43];
keys[100] = ["d",0x44];
keys[101] = ["e",0x45];
keys[102] = ["f",0x46];
keys[103] = ["g",0x47];
keys[104] = ["h",0x48];
keys[105] = ["i",0x49];
keys[106] = ["j",0x4a];
keys[107] = ["k",0x4b];
keys[108] = ["l",0x4c];
keys[109] = ["m",0x4d];
keys[110] = ["n",0x4e];
keys[111] = ["o",0x4f];
keys[112] = ["p",0x50];
keys[113] = ["q",0x51];
keys[114] = ["r",0x52];
keys[115] = ["s",0x53];
keys[116] = ["t",0x54];
keys[117] = ["u",0x55];
keys[118] = ["v",0x56];
keys[119] = ["w",0x57];
keys[120] = ["x",0x58];
keys[121] = ["y",0x59];
keys[122] = ["z",0x5a];
keys[123] = ["{",""];
keys[124] = ["|",""];
keys[125] = ["}",""];
keys[126] = ["~",""];
keys[127] = ["",""];
keys[128] = ["�",""];
keys[129] = ["",""];
keys[130] = ["�",""];
keys[131] = ["�",""];
keys[132] = ["�",""];
keys[133] = ["�",""];
keys[134] = ["�",""];
keys[135] = ["�",""];
keys[136] = ["�",""];
keys[137] = ["�",""];
keys[138] = ["�",""];
keys[139] = ["�",""];
keys[140] = ["�",""];
keys[141] = ["",""];
keys[142] = ["�",""];
keys[143] = ["",""];
keys[144] = ["",""];
keys[145] = ["�",""];
keys[146] = ["�",""];
keys[147] = ["�",""];
keys[148] = ["�",""];
keys[149] = ["�",""];
keys[150] = ["�",0x6d];
keys[151] = ["�",""];
keys[152] = ["�",""];
keys[153] = ["�",""];
keys[154] = ["�",""];
keys[155] = ["�",""];
keys[156] = ["�",""];
keys[157] = ["",""];
keys[158] = ["�",""];
keys[159] = ["�",""];
keys[160] = ["",""];
keys[161] = ["�",""];
keys[162] = ["�",""];
keys[163] = ["�",""];
keys[164] = ["�",""];
keys[165] = ["�",""];
keys[166] = ["�",""];
keys[167] = ["�",""];
keys[168] = ["�",""];
keys[169] = ["�",""];
keys[170] = ["�",""];
keys[171] = ["�",""];
keys[172] = ["�",""];
keys[173] = ["�",""];
keys[174] = ["�",""];
keys[175] = ["�",""];
keys[176] = ["�",""];
keys[177] = ["�",""];
keys[178] = ["�",""];
keys[179] = ["�",""];
keys[180] = ["�",""];
keys[181] = ["�",""];
keys[182] = ["�",""];
keys[183] = ["�",""];
keys[184] = ["�",""];
keys[185] = ["�",""];
keys[186] = ["�",""];
keys[187] = ["�",""];
keys[188] = ["�",""];
keys[189] = ["�",""];
keys[190] = ["�",""];
keys[191] = ["�",""];
keys[192] = ["�",""];
keys[193] = ["�",""];
keys[194] = ["�",""];
keys[195] = ["�",""];
keys[196] = ["�",""];
keys[197] = ["�",""];
keys[198] = ["�",""];
keys[199] = ["�",""];
keys[200] = ["�",""];
keys[201] = ["�",""];
keys[202] = ["�",""];
keys[203] = ["�",""];
keys[204] = ["�",""];
keys[205] = ["�",""];
keys[206] = ["�",""];
keys[207] = ["�",""];
keys[208] = ["�",""];
keys[209] = ["�",""];
keys[210] = ["�",""];
keys[211] = ["�",""];
keys[212] = ["�",""];
keys[213] = ["�",""];
keys[214] = ["�",""];
keys[215] = ["�",""];
keys[216] = ["�",""];
keys[217] = ["�",""];
keys[218] = ["�",""];
keys[219] = ["�",""];
keys[220] = ["�",""];
keys[221] = ["�",""];
keys[222] = ["�",""];
keys[223] = ["�",""];
keys[224] = ["�",""];
keys[225] = ["�",""];
keys[226] = ["�",""];
keys[227] = ["�",""];
keys[228] = ["�",""];
keys[229] = ["�",""];
keys[230] = ["�",""];
keys[231] = ["�",""];
keys[232] = ["�",""];
keys[233] = ["�",""];
keys[234] = ["�",""];
keys[235] = ["�",""];
keys[236] = ["�",""];
keys[237] = ["�",""];
keys[238] = ["�",""];
keys[239] = ["�",""];
keys[240] = ["�",""];
keys[241] = ["�",""];
keys[242] = ["�",""];
keys[243] = ["�",""];
keys[244] = ["�",""];
keys[245] = ["�",""];
keys[246] = ["�",""];
keys[247] = ["�",""];
keys[248] = ["�",""];
keys[249] = ["�",""];
keys[250] = ["�",""];
keys[251] = ["�",""];
keys[252] = ["�",""];
keys[253] = ["�",""];
keys[254] = ["�",""];
keys[255] = ["�",""];
keys[256] = ["F1", 0x70];
keys[257] = ["F2", 0x71];
keys[258] = ["F3", 0x72];
keys[259] = ["F4", 0x73];
keys[260] = ["F5", 0x74];
keys[261] = ["F6", 0x75];
keys[262] = ["F7", 0x76];
keys[263] = ["F8", 0x77];
keys[264] = ["F9", 0x78];
keys[265] = ["F10",0x79];
keys[266] = ["F11",0x7a];
keys[267] = ["F12",0x7b];
keys[268] = ["Esc",0x1b];
keys[269] = ["Tab",0x09];
keys[270] = ["End",0x23];
keys[271] = ["Enter",0x0d];
keys[272] = ["Home",0x24];
keys[273] = ["Page Up",0x21];
keys[274] = ["Page Down",0x22];
keys[275] = ["Insert",0x2d];
keys[276] = ["Delete",0x2e];
keys[277] = ["Num Lock",0x90];
keys[278] = ["Caps Lock",0x14];
keys[279] = ["Scroll Lock",0x91];
keys[280] = ["Print screen",0x2c];
keys[281] = ["Pause",0x13];
keys[282] = ["Middle Mouse",0x04];
keys[283] = ["Shift",0x10];
keys[284] = ["Ctrl",0x11];
keys[285] = ["Alt",0x12];
keys[286] = ["Win",0x5c];
keys[287] = ["Left",0x25];
keys[288] = ["Right",0x27];
keys[289] = ["Up",0x26];
keys[290] = ["Down",0x28];
keys[291] = ["Media",0xb5];
keys[292] = ["Play Pause",0xb3];
keys[293] = ["Next track",0xb0];
keys[294] = ["Previous track",0xb1];
keys[295] = ["Stop",0xb2];
keys[296] = ["Mode change",0x1f];
keys[297] = ["Volume up",0xaf];
keys[298] = ["Volume down",0xae];
keys[299] = ["Volume mute",0xad];
keys[300] = ["Browser Back",0xa6];
keys[301] = ["Browser Forward",0xa7];
keys[302] = ["Browser Favorites",0xab];
keys[303] = ["Browser Home",0xac];
keys[304] = ["Browser Refresh",0xa8];
keys[305] = ["Browser Search",0xaa];
keys[306] = ["Browser Stop",0xa9];

//http://www.kbdedit.com/manual/low_level_vk_list.html


var widget = null;
var wsh = new ActiveXObject('WScript.Shell');
var setting_optionsmenu_item = 0;
var shiftKeyActive = false;
var controlKeyActive = false;
var altKeyActive = false;
var winKeyActive = false;
var scrollModeActive = true;
var recentSwfPaths;
var recentSwfNames;
var recentDataPaths;
var recentDataNames;
var browsePath = "";
var swfExtentionFilter = ".swf";
var txtExtentionFilter = ".txt";


// Read settings for this script
try {
	try {
		var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
		if( settingsFileStream == null ) {
			// Write defaults
			ShowMessage("Writing default settings");
			writeSettings();
			settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
		}
	} catch (e) {
			writeSettings();
			settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	}
	var recentSwfPathLoop = false;
	var recentDataPathLoop = false;
	while( true ) {
		var propertyName = settingsFileStream.ReadLine();
		if( propertyName == "browser_path" ) {
			var propertyValue = settingsFileStream.ReadLine();
			browsePath = propertyValue;
		} else if (propertyName == "recent_swf_path") {
			recentSwfPathLoop = true;
			recentDataPathLoop = false;
			cleanRecentSwfFiles();
		} else if (propertyName == "recent_data_path") {
			recentSwfPathLoop = false;
			recentDataPathLoop = true;
			cleanRecentDataFiles();
		} else if (recentSwfPathLoop == true) {
			addRecentSwfFile(propertyName);
		} else if (recentDataPathLoop == true) {
			addRecentDataFile(propertyName);
		}
	}
} catch( e ) {
} finally {
	if( settingsFileStream != null ) settingsFileStream.Close();	
}
function cleanRecentSwfFiles() {
	recentSwfPaths = new Array();
	recentSwfNames = new Array();
	recentSwfPaths.push("");
	recentSwfNames.push("Wis recente bestandslijst");
}
function addRecentSwfFile(filePath) {
	recentSwfPaths.push(filePath);
	recentSwfNames.push(fso.GetFileName( filePath ));
}
function cleanRecentDataFiles() {
	recentDataPaths = new Array();
	recentDataNames = new Array();
	recentDataPaths.push("");
	recentDataNames.push("Wis recente bestandslijst");
}
function addRecentDataFile(filePath) {
	recentDataPaths.push(filePath);
	recentDataNames.push(fso.GetFileName( filePath ));
}
function writeSettings() {
	try {
		//create clean settings file
		var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );	// overwrite
		settingsFileStream.WriteLine( "browser_path" );
		settingsFileStream.WriteLine( browsePath );
		settingsFileStream.WriteLine( "recent_swf_path" );
		if (recentSwfPaths != null) {
			for (var i = 1; i < recentSwfPaths.length; i++) {
				settingsFileStream.WriteLine( recentSwfPaths[i] );
			}
		}
		settingsFileStream.WriteLine( "recent_data_path" );
		if (recentDataPaths != null) {
			for (var i = 1; i < recentDataPaths.length; i++) {
				settingsFileStream.WriteLine( recentDataPaths[i] );
			}
		}
		settingsFileStream.Close();
	} catch (e) {
			var errPopup = CreatePopupDialog( "");
			errPopup.textualContent = e.message;
			theTerminal.Push(errPopup);	
	}	finally {
		if (settingsFileStream != null) {
				settingsFileStream.Close();
		}
	}
}

launchWidget();

var leftDown = false;
var rightDown = false;
var leftLocked = false;
var rightLocked = false;
var acceleration_factor = 1;

function launchWidget() {
	//activateBrowser();
	showKeypad();
}
function showKeypad() {
	var widget = CreateKeypadScreen( "myKeypad_" );
	widget.name="myKeypad_";
	widget.title = "De Slimste Mens";
	if( theTerminal.supportsPen ) {
		row1 = widget.CreateRow("Scherm: muis - Menu: opties\nHelp (?): TAB", scCenter, scWrap, scSmall);
	} else {
		row1 = widget.CreateRow("Gebruik navigatietoetsen.", scCenter, scWrap, scSmall);
	}
	widget.sendsPenEvents = true;
	widget.keyRepeatInterval = 0.01;
	widget.keyRepeatDelay = 0.2;
	
	row2 = widget.CreateRow("", scCenter, scWrap, scSmall);
	row3 = widget.CreateRow("", scCenter, scWrap, scLarge);
	row4 = widget.CreateRow("", scCenter, scWrap, scSmall);
	row5 = widget.CreateRow("", scLeft, scWrap, scSmall);
	theTerminal.Push(widget);
}

function myKeypad_Exit(theScreen)
{
	if( leftDown ) {
		leftDown = false;
		SendMouseEvent(0, 0, 0, 1, 0);
	}
	if( rightDown ) {
		rightDown = false;
		SendMouseEvent(0, 0, 0, 0, 1);
	}
	if (switchScorePanel) {
		sendText("o", false);
		showHistory("<scorebord>",false);
		switchScorePanel = false;
	}
}

function showHistory(pressedButton, printButton) {
	row3text = "";
	row5text = row5.textualContent;
	if (shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
		row3text += (shiftKeyActive ? "Shift " : "") + (controlKeyActive ? "Ctrl " : "") + (altKeyActive ? "Alt " : "") + (winKeyActive ? "Win " : "") + "+ ";
	}
	if (pressedButton == " ") {
		row3text += "<space>";
	} else {		
		row3text += pressedButton;
	}
	if (printButton) {
		if (pressedButton == "<backspace>") {
			if(row5text.length > 0)
			{
				row5text = row5text.slice(0, row5.textualcontent.length - 1);
			}
		} else if (pressedButton == "<enter>") {
			row5text += "\n";
		} else if (pressedButton == "<scroll>") {
			
		} else {
			row5text += pressedButton;
		}
	} else {
		row5text = "";
	}
	row3.textualContent = row3text;
	if (shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
		row5.textualContent = "";
	}
	else {
		row5.textualContent = row5text;
	}	
}


function clearDeviceHomeScreen() {
	row2.textualContent = "";
	row3.textualContent = "";
	row4.textualContent = "";
	row5.textualContent = "";
	theTerminal.PopTo("myKeypad_");
}

function myKeypad_KeyDown(theScreen, theKey)
{
	 //  SendvirtualKeystroke (Code, Shift, Ctrl, Alt, Win)
	if (scrollModeActive && handleKeyMove( theKey )) {
		showHistory("<scroll>", true);
	} else if ( theKey == "^" ) { 
      //  Up
      SendVirtualKeystroke( 0x26, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );
      showHistory("<up>", false);
   } else if( theKey == "v" ) { 
      //  Down
      SendVirtualKeystroke( 0x28, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );
      showHistory("<down>", false);
   } else if( theKey == "<" ) { 
      //  Left
      SendVirtualKeystroke( 0x25, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive ); 
      showHistory("<left>", false);
   } else if( theKey == ">" ) { 
      //  Right
      SendVirtualKeystroke( 0x27, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive ); 
      showHistory("<right>", false);
   } else if( theKey == "0x0008" ) { 
      //  Backspace
      SendVirtualKeystroke( 0x08, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );
      showHistory("<backspace>", true);
   } else if( theKey == "0x002e" ) { 
      //  Delete
      SendVirtualKeystroke( 0x2e, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );
      showHistory("<delete>", false);
   } else if( theKey == "s" ) { 
      //  Enter
      SendVirtualKeystroke( 0x0d, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );
      showHistory("<enter>", true);
   } else if( theKey == "0x0009" ) { 
      //  Tab
      SendVirtualKeystroke( 0x09, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );  
      showHistory("<tab>", false);
   } else if( theKey == "0x0020" ) { 
      //  space
      SendVirtualKeystroke( 0x20, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );  
      showHistory(" ", true);
   } else  if ( theKey == "f") {
			showDsmMenu();
      /*
			//Left Click
			if( ! rightDown ) {
				rightDown = true;
			  // SendMouseEvent( X , Y , Scroll, Right , Left)
			  SendMouseEvent(0, 0, 0, 0, -1);
			  showHistory("<mouse>", false);
			}		*/
			if ( rightLocked ) {
				SendMouseEvent(0, 0, 0, 1, 0);
				rightLocked = false;
				rightDown = false;
				ShowMessage("Right button unlocked");			
			  	showHistory("<mouse>", false);
			}
			if ( leftLocked ) {
				SendMouseEvent(0, 0, 0, 1, 0);
				leftLocked = false;
				leftDown = false;
				ShowMessage("Left button unlocked");			
			 	showHistory("<mouse>", false);
			}
	} else if (theKey == ":help" || theKey == "#") {
		//see keyup actions
	} else {
		if (theKey.length == 3) {
			sendText(theKey.charAt(1),true);
		} else {
			sendText(theKey,true);
		}
		if(shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
  		ShowMessage((shiftKeyActive ? " Shift " : "") + (controlKeyActive ? " Ctrl " : "") + (altKeyActive ? " Alt " : "") + (winKeyActive ? " Win " : "") + "\n" + theKey.charAt(1));
  	}
	}
}

function myKeypad_KeyRepeat(theScreen, theKey)
{
	if( handleKeyMove( theKey ) ) {
		acceleration_factor += 0.05;
		return;
	}
	if( theKey == "s" || theKey == "5" ) {
		if( leftDown && ! leftLocked ) {
			leftLocked = true;
			ShowMessage("Left button locked");			
			showHistory("<mouse>", false);
		}
	} else if( theKey == "f" || theKey == "0" ) {
		if( rightDown && ! rightLocked ) {
			rightLocked = true;
			ShowMessage("Right button locked");			
			showHistory("<mouse>", false);
		}
	} 
}

function myKeypad_KeyUp(theScreen, theKey)
{
	acceleration_factor = 1;
	if( theKey == "s" || theKey == "5" ) {
		if( leftDown && ! leftLocked ) {
			leftDown = false;
			SendMouseEvent(0, 0, 0, 1, 0);
			showHistory("<mouse>", false);
		}
	} else if( theKey == "f" || theKey == "0" ) {
		if( rightDown && ! rightLocked ) {
			rightDown = false;
			SendMouseEvent(0, 0, 0, 0, 1);
			showHistory("<mouse>", false);
		}
	} else if (theKey == ":help" || theKey == "#") {
		if( theTerminal.supportsPen ) {
		  SendVirtualKeystroke( 0x09, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );  
		  showHistory("<tab>", false);
		} else {
			showHelp();
		}
	}
}

function myKeypad_PenTap(theScreen)
{
	if( leftLocked ) {
		SendMouseEvent(0, 0, 0, 1, 0);
		leftLocked = false;
		leftDown = false;
		ShowMessage("Left button unlocked");
		showHistory("<mouse>", false);			
	} else {
		if( ! leftDown ) {
			SendMouseEvent(0, 0, 0, -1, 0);
		}
		SendMouseEvent(0, 0, 0, 1, 0);
		showHistory("<mouse>", false);
		leftDown = false;
	}
}

function myKeypad_PenLock(theScreen)
{
	if( ! leftDown && ! leftLocked ) {
		SendMouseEvent(0, 0, 0, -1, 0);
		leftDown = true;
		leftLocked = true;
		ShowMessage("Left button locked");	
		showHistory("<mouse>", false);		
	}
}

function accelerate(v)
{
	if( v > 8 || v < -8 ) {
		return v*2.4
	} else if( v > 6 || v < -6 ) {
		return v*1.9
	} else if( v > 4 || v < -4 ) {
		return v*1.5
	} else if( v > 2 || v < -2 ) {
		return v*1.2
	}
	return v;
}

function myKeypad_PenMove(theScreen, dx, dy)
{
	dx = accelerate(dx);
	dy = accelerate(dy);
	SendMouseEvent(dx, dy, 0, 0, 0);
}

// Scrolling//
function handleKeyMove( theKey )
{
	var dx = 0;
	var dy = 0;
	var scroll = 0;
	
	if( theTerminal.supportsPen ) {
		if( theKey == ">" || theKey == "6" ) {
			dx = 1;
		} else if( theKey == "<" || theKey == "4" ) {
			dx = -1;
		} else if( theKey == "v" || theKey == "d" || theKey == "8" ) {
			scroll = -1;
		} else if( theKey == "^" || theKey == "u" || theKey == "2" ) {
			scroll = 1;
		} else if( theKey == "1" ) {
			dx = -1;
			dy = -1;
		} else if( theKey == "3" ) {
			dx = 1;
			dy = -1;
		} else if( theKey == "7" ) {
			dx = -1;
			dy = 1;
		} else if( theKey == "9" ) {
			dx = 1;
			dy = 1;
		} else {
			return false;
		}
	} else {
		if( theKey == ">" || theKey == "6" ) {
			dx = 1;
		} else if( theKey == "<" || theKey == "4" ) {
			dx = -1;
		} else if( theKey == "v" || theKey == "d" || theKey == "8" ) {
			dy = 1;
		} else if( theKey == "^" || theKey == "u" || theKey == "2" ) {
			dy = -1;
		} else if( theKey == "1" ) {
			dx = -1;
			dy = -1;
		} else if( theKey == "3" ) {
			dx = 1;
			dy = -1;
		} else if( theKey == "7" ) {
			dx = -1;
			dy = 1;
		} else if( theKey == "9" ) {
			dx = 1;
			dy = 1;
		} else {
			return false;
		}
	}
	
	if( dx != 0 || dy != 0 ) {
		SendMouseEvent(dx*acceleration_factor, dy*acceleration_factor, 0, 0, 0);
	}
	if( scroll != 0 ) {
		SendMouseEvent(0, 0, scroll, 0, 0);
	}
	
	return true;
}


function createBrowser() {
	browserObject = new ActiveXObject("InternetExplorer.Application");
	browserObject.Statusbar = false;
	//browserObject.FullScreen = true; switch with fullScreenBrowser function, F11
	browserObject.Toolbar = true;
	browserObject.Visible = true;
	browserObject.Statusbar = false;
}


function openSwf(swfPath) {
		createBrowser();
		browserObject.Navigate(swfPath);
/*	activateBrowser();
	SendVirtualKeystroke(0x4f, false, true, false, false); //send ctrl + o
	var i=0;	
	do { //wait
		i++
	} while (i<100)
	SendVirtualKeystroke(0x4e, false, false, true, false); //send alt + n
	sendText("*.swf", false);//send *.swf
	SendVirtualKeystroke(0x0d, false, false, false, false); //enter
	theTerminal.PopTo("myKeypad_");*/
}

function activateBrowserAndSwf() {
	activateBrowser();
	findWindowTimeout = 100;
	var browserContentWindow = 0;
	for (var i = 0; i < findWindowTimeout; i++) {
		browserContentWindow = FindWindow( browserContentClass, "");
		if( browserContentWindow != 0 ) {
			break;
		}		
	}
	if (browserContentWindow != 0) {
		ActivateWindow(browserContentWindow);
		return browserContentWindow;
	} else {
		ShowMessage("Not found");
		showDsmMenu();
	}
}

function activateBrowser() {
	var helper = new ActiveXObject("SCHelper.SECHelper");
	findWindowTimeout = 100;
	var browserWindow = 0;
	for (var i = 0; i < findWindowTimeout; i++) {
		browserWindow = FindWindow( browserClass, "");
		if( browserWindow != 0 ) {
			break;
		}		
	}
	if (browserWindow != 0) {
		ActivateWindow(browserWindow);
		return browserWindow;
	} else {
		browserObject = new ActiveXObject("InternetExplorer.Application");
	  browserObject.Visible = true;
	  return FindWindow( browserClass, "");
	}
}

function closeBrowser() {
	var widget = CreateQuestionDialog( "closeConfirmation_");
	widget.textualContent = "Sluit " + browserName + "?";
	theTerminal.Push(widget);
}
function fullScreenBrowser() {
	activateBrowser();
	SendVirtualKeystroke(0x7a,false,false,false,false); //F11	
}


function closeConfirmation_OK(w) {
	try {
		if (browserObject != null) {
			browserObject.quit;
		} else {
			browserWindow = activateBrowser();
			SendVirtualKeystroke(0x73,false,false,true,false); //Alt + F4
		}
	} catch (e) {
		browserWindow = activateBrowser();
		SendVirtualKeystroke(0x73,false,false,true,false); //Alt + F4
		browserOjbect = null;
	}
}

function openLink() {
		var openLinkField = CreateTextFieldDialog( "openLink_");
		
		openLinkField.name = "openLink_";
		openLinkField.maxLength = 500;
		openLinkField.prompt = "Link te openen:";
		openLinkField.value = "";  
		
		theTerminal.Push(openLinkField); 
}

function openLink_OK(textfield) {
	if (browserObject == null) {
		browserWindow = activateBrowser();
		SendVirtualKeystroke(0x44, false, false, true, false); //alt + d
		sendText(textfield.value,true);
		SendVirtualKeystroke(0x0d, false, false, false, false); //enter
		theTerminal.PopTo("myKeypad_");
	} else {
		browserObject.Navigate(textfield);
	}
}

function openLink_Cancel(textfield) {
}

function showDsmMenu()
{
	var dsmMenuItems = new Array();
	dsmMenuItems[0] = "Open / importeer quiz";
	dsmMenuItems[1] = "Algemeen - Speler namen";
	dsmMenuItems[2] = "Ronde selectie";
	dsmMenuItems[3] = " ";
	dsmMenuItems[4] = "Score aanpassen";
	dsmMenuItems[5] = "Context menu (rechter klik)";
	dsmMenuItems[6] = "Speciale toetsen";
	var dsmMenu = CreateListScreen( "dsmMenu_");
	dsmMenu.name = "dsmMenu_";
	dsmMenu.title = "De Slimste Mens";
	dsmMenu.selectedItem = 0;
	dsmMenu.itemLabels = dsmMenuItems;
	theTerminal.Push( dsmMenu );
}

function dsmMenu_ValueUpdated(theScreen, theProperty)
{
	if (theScreen.selectedItem == 0) {
		openGameDataMenu();
	} else if (theScreen.selectedItem == 1) {
		getPlayerNamesMenu();
	} else if (theScreen.selectedItem == 2) {
		showRoundsMenu();
	} else if (theScreen.selectedItem == 3) {
	} else if (theScreen.selectedItem == 4) {
		showPointCorrectionMenu();
	} else if (theScreen.selectedItem == 5) {
		SendMouseEvent(0, 0, 0, 0, -1);
		showHistory("<mouse>", false);
	} else if (theScreen.selectedItem == 6) {
		showMenu();
	}
}

function openGameDataMenu() {
	var gameDataMenuItems = new Array();
	gameDataMenuItems[0] = "Open swf quiz op pc";
	gameDataMenuItems[1] = "Sluit " + browserName;
	gameDataMenuItems[2] = "Wissel browser volledig scherm";
	gameDataMenuItems[3] = "Wissel browser statusbalk";
	gameDataMenuItems[4] = "Importeer quiz gegevens";
	var gameDataMenu = CreateListScreen( "gameDataMenu_");
	gameDataMenu.title = "Open quiz";        
	gameDataMenu.itemLabels = gameDataMenuItems;
	theTerminal.Push( gameDataMenu );
}
function gameDataMenu_ValueUpdated(theScreen, theProperty) {
	if (theScreen.selectedItem == 0) {
		showOpenSwfMenu();
	} else if (theScreen.selectedItem == 1) {
		closeBrowser();
	} else if (theScreen.selectedItem == 2) {
		fullScreenBrowser();
	} else if (theScreen.selectedItem == 3) {
		switchStatusBar();
	} else if (theScreen.selectedItem == 4) {
		showImportDsmDataMenu();
	}
}

function switchStatusBar() {
	SendVirtualKeystroke( 0x56, false, false, true, false ); //v
	for (var waitCounter = 0 ; waitCounter < 30; waitCounter ++) {
		ShowMessage("Even geduld");
	}
	SendVirtualKeystroke( 0x54, false, false, false, false ); //t
	for (var waitCounter = 0 ; waitCounter < 30; waitCounter ++) {
		ShowMessage("Even geduld");
	}
	SendVirtualKeystroke( 0x53, false, false, false, false ); //s	
}

function showOpenSwfMenu() {
	if( recentSwfPaths.length == 1 ) {
		//no recent paths, only clear history element
		menuSwfBrowser();
	} else {
		var optionList = CreateOptionListDialog( "menuOpenSwf_");
		optionList.title = "Open quiz (*.swf)";
		optionList.itemLabels = new Array("Recent gebruikt", "Navigeer naar map");
		optionList.value = 0;
		theTerminal.Push(optionList);	
	}
}
function menuOpenSwf_OK(theScreen) {
	if( theScreen.value == 0 ) {
		showRecentSwfFileSelector();
	} else if (theScreen.value == 1) {
		menuSwfBrowser();
	}
}

function menuSwfBrowser() {
	var browser = CreateListScreen( "swfBrowser_");	
	browser.name = "Navigeer";
	browser.title = "Navigeer";        
	browser.selectedItem = 0;
	browser.itemLabels = getFolderItems(swfExtentionFilter);
  theTerminal.Push( browser );
}
function swfBrowser_ValueUpdated(browser, property) {
	if (browser.selectedItem == 0 && (browser.itemLabels[browser.selectedItem]).slice(0,2) == "..") {
		pathItem = "..\\";
	} else {
		pathItem = browser.itemLabels[browser.selectedItem] + "\\";
	}

    var newPath = fso.BuildPath( browsePath, pathItem );
    newPath = fso.GetAbsolutePathName( newPath );
    if( newPath == browsePath ) {
			newPath = "";
    }
    
    if( fso.FileExists( newPath ) ) {
	  	addRecentSwfFile(newPath);
			writeSettings();
      openSwf(newPath);
	  	theTerminal.PopTo("gameDataMenu_");
      return false;
    } else {
      // Selected a folder
      browsePath = newPath;
			writeSettings();
    }
    
    browser.itemLabels = getFolderItems(swfExtentionFilter);
    browser.selectedItem = 0;
    
    // Don't pop browser from stack
    return true;
}
function getFolderItems(filterTypes) {
//filterTypes example: ".ppt" or ".ppt;.pps"
	var items = new Array();
	
	if( browsePath == "" ) {
		// Open Presentation
		var e = new Enumerator( fso.Drives );
		for( ; !e.atEnd(); e.moveNext() ) {
			var x = e.item();
			items.push( x.DriveLetter + ":" );
		}        
	} else {
		items.push(".. (" + browsePath + "\\..)");
		
	    var folder = null;
	    try {
			folder = fso.GetFolder( browsePath );
	    } catch( e ) {
			browsePath = "";
			return getFolderItems(filterTypes);
	    }
	    
		var e = new Enumerator( folder.SubFolders );
		for( ; !e.atEnd(); e.moveNext() ) {
			var x = e.item();
			items.push(x.Name);
		}        
	    
		e = new Enumerator( folder.files );
		var filterTypesArray = null;
		if (filterTypes != null && filterTypes.indexOf(";") > -1) {
			filterTypesArray = filterTypes.split(";");
		}
		for( ; !e.atEnd(); e.moveNext() ) {
			var file = e.item();
			var filename = file.Name;
			var fileext4 = filename.slice( filename.lastIndexOf(".")).toLowerCase();
			if (filterTypesArray != null) {
				for (var filterTypesArrayCounter = 0; filterTypesArrayCounter < filterTypesArray.length; filterTypesArrayCounter++) {
					if (filterTypesArray[filterTypesArrayCounter] == fileext4) {
						items.push( file.Name );
					}
				}
			} else if(filterTypes == null || filterTypes == "" || fileext4 == filterTypes) {
				items.push( file.Name );
			}
		}    
	}
	
	return items;
}

function showRecentSwfFileSelector() {
	var recentList = CreateListScreen( "recentSwfFiles_");
	recentList.title = "Selecteer recente quiz";        
	recentList.itemLabels = recentSwfNames;
	theTerminal.Push( recentList );
}
function recentSwfFiles_ValueUpdated(theScreen, property) {
	try
	{
		if (theScreen.selectedItem == 0) {
			cleanRecentSwfFiles();
			writeSettings();				
			theTerminal.PopTo("gameDataMenu_");
			return false;
		} else {
			openSwf(recentSwfPaths[theScreen.selectedItem]);
			return false;
		}
	} catch( e )
	{
		var errPopup = CreatePopupDialog( "");
		errPopup.textualContent = e.message;
		theTerminal.Push(errPopup);	
		browserObject == null;
	}
	return true;
}

function showImportDsmDataMenu() {
	if( recentDataPaths.length == 1 ) {
		//no recent history, only clear history element
		menuDataBrowser();
	} else {
		var optionList = CreateOptionListDialog( "menuOpenData_");
		optionList.title = "Open quiz data (*.txt)";
		optionList.itemLabels = new Array("Recent gebruikt", "Navigeer naar map");
		optionList.value = 0;
		theTerminal.Push(optionList);	
	}
}
function menuOpenData_OK(theScreen) {
	if( theScreen.value == 0 ) {
		showRecentDataFileSelector();
	} else if (theScreen.value == 1) {
		menuDataBrowser();
	}
}

function menuDataBrowser() {
	var browser = CreateListScreen( "dataBrowser_");	
	browser.name = "Navigeer";
	browser.title = "Navigeer";        
	browser.selectedItem = 0;
	browser.itemLabels = getFolderItems(txtExtentionFilter);
  theTerminal.Push( browser );
}
function dataBrowser_ValueUpdated(browser, property) {
	if (browser.selectedItem == 0 && (browser.itemLabels[browser.selectedItem]).slice(0,2) == "..") {
		pathItem = "..\\";
	} else {
		pathItem = browser.itemLabels[browser.selectedItem] + "\\";
	}

    var newPath = fso.BuildPath( browsePath, pathItem );
    newPath = fso.GetAbsolutePathName( newPath );
    if( newPath == browsePath ) {
			newPath = "";
    }
    
    if( fso.FileExists( newPath ) ) {
	  	addRecentDataFile(newPath);
	  	writeSettings();
      importDsmData(newPath);
	  	theTerminal.PopTo("gameDataMenu_");
      return false;
    } else {
      // Selected a folder
      browsePath = newPath;
		writeSettings();
    }
    
    browser.itemLabels = getFolderItems(txtExtentionFilter);
    browser.selectedItem = 0;
    
    // Don't pop browser from stack
    return true;
}

function showRecentDataFileSelector() {
	var recentList = CreateListScreen( "recentDataFiles_");
	recentList.title = "Selecteer recente quiz data";        
	recentList.itemLabels = recentDataNames;
	theTerminal.Push( recentList );
}
function recentDataFiles_ValueUpdated(theScreen, property) {
	try
	{
		if (theScreen.selectedItem == 0) {
			cleanRecentDataFiles();
			writeSettings();			
			theTerminal.PopTo("gameDataMenu_");
			return false;
		} else {
			importDsmData(recentDataPaths[theScreen.selectedItem]);
			return false;
		}
	} catch( e )
	{
		var errPopup = CreatePopupDialog("");
		errPopup.textualContent = e.message;
		theTerminal.Push(errPopup);	
		browserObject == null;
	}
	return true;
}
function importDsmData(dataPath) {
	DSMDataFileStream = fso.OpenTextFile(dataPath);
  var dataFile = fso.GetFile(dataPath);
	currentImageBaseFolder = dataFile.ParentFolder.Path;
	questions369 = new Array();
	openDourMovies = new Array();
	puzzels = new Array();
	galleries = new Array();
	collectiveMemories = new Array();
	finals = new Array();
	try {
		while (true)  {
			fileLine = DSMDataFileStream.Readline();
			if (fileLine.indexOf(";") != -1 )
			{
				var firstBracket = fileLine.indexOf("[");
				var firstClosingBracket = fileLine.indexOf("]");
				var fileLineItem = fileLine.slice(0,firstBracket);
				var fileLineItemNr = fileLine.slice(firstBracket + 1, firstClosingBracket);
				var secondBracket = firstClosingBracket + fileLine.slice(firstClosingBracket).indexOf("[");
				var lastClosingBracket = fileLine.lastIndexOf("]");
				var fileLineItemData = fileLine.slice(secondBracket+1,lastClosingBracket); 
				var fileLineItemDateArray = fileLineItemData.split("\"");
				var fileLineItemDateArrayFiltered = new Array();
				var fileLineItemDateArrayFilteredIndex = 0;
				for (var partNum = 0 ; partNum < fileLineItemDateArray.length; partNum ++) {
					if (fileLineItemDateArray[partNum] != "" && fileLineItemDateArray[partNum] != "," && fileLineItemDateArray[partNum] != ",[" && fileLineItemDateArray[partNum] != ", [") {
						fileLineItemDateArrayFiltered[fileLineItemDateArrayFilteredIndex++] = fileLineItemDateArray[partNum];
					}
				}
				//ShowMessage("fileLineItem:" + fileLineItem + "\nfileLineItemNr:" + fileLineItemNr +"\npartnum: " + 0 + fileLineItemDateArrayFiltered[0] + "\npartnum: " + 1  + fileLineItemDateArrayFiltered[1] + "\npartnum: " + 2  + fileLineItemDateArrayFiltered[2] + "\npartnum: " + 3 + fileLineItemDateArrayFiltered[3] + "\npartnum: " + 4  + fileLineItemDateArrayFiltered[4] + "\npartnum: " + 5  + fileLineItemDateArrayFiltered[5]);
				
				if (fileLineItem == "questions369") {
					questions369[fileLineItemNr] = [fileLineItemDateArrayFiltered[0], fileLineItemDateArrayFiltered[1]];
				} else if (fileLineItem == "openDourMovies") {
					openDourMovies[fileLineItemNr] = [fileLineItemDateArrayFiltered[0], fileLineItemDateArrayFiltered[1],[fileLineItemDateArrayFiltered[2],fileLineItemDateArrayFiltered[3], fileLineItemDateArrayFiltered[4], fileLineItemDateArrayFiltered[5]]];
				} else if (fileLineItem == "puzzels") {
					puzzels[fileLineItemNr] = [fileLineItemDateArrayFiltered[0], fileLineItemDateArrayFiltered[1],[fileLineItemDateArrayFiltered[2],fileLineItemDateArrayFiltered[3], fileLineItemDateArrayFiltered[4]]];
				} else if (fileLineItem == "galleries") {
					galleries[fileLineItemNr] = [fileLineItemDateArrayFiltered[0], [fileLineItemDateArrayFiltered[1],fileLineItemDateArrayFiltered[2],fileLineItemDateArrayFiltered[3], fileLineItemDateArrayFiltered[4], fileLineItemDateArrayFiltered[5], fileLineItemDateArrayFiltered[6], fileLineItemDateArrayFiltered[7], fileLineItemDateArrayFiltered[8], fileLineItemDateArrayFiltered[9], fileLineItemDateArrayFiltered[10]]];
				} else if (fileLineItem == "collectiveMemories") {
					collectiveMemories[fileLineItemNr] = [fileLineItemDateArrayFiltered[0], fileLineItemDateArrayFiltered[1], [fileLineItemDateArrayFiltered[2],fileLineItemDateArrayFiltered[3], fileLineItemDateArrayFiltered[4], fileLineItemDateArrayFiltered[5], fileLineItemDateArrayFiltered[6]]];
				} else if (fileLineItem == "finals") {
					finals[fileLineItemNr] = [fileLineItemDateArrayFiltered[0], fileLineItemDateArrayFiltered[1], [fileLineItemDateArrayFiltered[2],fileLineItemDateArrayFiltered[3], fileLineItemDateArrayFiltered[4], fileLineItemDateArrayFiltered[5], fileLineItemDateArrayFiltered[6]]];
				}
			} 
			else {
				ShowMessage("no match");
			}
		} 
	} catch (e) { }
	finally {
		if( DSMDataFileStream != null ) DSMDataFileStream.Close();	
	}
}

function showRoundsMenu() {
	if (questions369 == null) {
		showImportDsmDataMenu();
	} else {
		activePlayer = 0;
		var menuRoundsItems = new Array();
		menuRoundsItems[0] = "3-6-9";
		menuRoundsItems[1] = "Open Deur";
		menuRoundsItems[2] = "Puzzel";
		menuRoundsItems[3] = "De Galerij";
		menuRoundsItems[4] = "Het Collectief Geheugen";
		menuRoundsItems[5] = "De Finale";
		menuRoundsItems[6] = " ";
		menuRoundsItems[7] = "Volgend scherm";
		menuRoundsItems[8] = "Vorig scherm";
		menuRoundsItems[9] = "Score aanpassen";
		var menuRounds = CreateListScreen( "menuRounds_");
		menuRounds.name = "menuRounds_";
		menuRounds.title = "De Slimste Mens";
		menuRounds.selectedItem = 0;
		menuRounds.itemLabels = menuRoundsItems;
		theTerminal.Push( menuRounds );
	}
}
function menuRounds_ValueUpdated(theScreen, theProperty)
{
	if (theScreen.selectedItem == 0) {
		show369Menu();
		show369Info();
	} else if (theScreen.selectedItem == 1) {
		showOpenDourMenu();
		showOpenDourInfo();
	} else if (theScreen.selectedItem == 2) {
		showPuzzelPlayersMenu();
		showPuzzelInfo();
	} else if (theScreen.selectedItem == 3) {
		showGalleryMenu();
		showGalleryInfo();
	} else if (theScreen.selectedItem == 4) {
		showCollectiveMemoryMenu();
		showCollectiveMemoryInfo();
	} else if (theScreen.selectedItem == 5) {
		showFinalsMenu();
		showFinalsInfo();
	} else if (theScreen.selectedItem == 6) {
	} else if (theScreen.selectedItem == 7) {
		sendText("n",false);
	} else if (theScreen.selectedItem == 8) {
		sendText("b", false);
	} else if (theScreen.selectedItem == 9) {
		showPointCorrectionMenu();
	}
}


function showMoveToNextScreenQuestion(menuName) {
	var widget = CreateQuestionDialog( "moveToNextScreenQuestion_");
	widget.textualContent = "\nGa naar '" + menuName + "' scherm?\n\nYes:\nvolgend scherm\n+\ntoon " + menuName + " menu\n\nNo:\ntoon " + menuName + " menu";
	theTerminal.Push(widget);	
}
function moveToNextScreenQuestion_OK(textfield) {
	sendText("n",false);
}
function moveToNextScreenQuestion_Cancel(textfield) {
}

function showPointCorrectionMenu() {
		showPlayerPointsMenu();
		sendText("o",false);
		switchScorePanel = true;
		showKeypad();
		showHistory("-wijzig de punten per speler\nGroen: toevoegen\nRood: afhouden\n-klik op 'Back'-toets", true);
}
function showPlayerPointsMenu() {
	var menuPlayerPointsItems = new Array();
	for (var i = 1; i < 5; i++) {
		menuPlayerPointsItems[i-1] = "Speler " + i + ": " + playerNames[i][0] + " - " + playerNames[i][1] + "s";
	}
	var menuPlayerPoints = CreateListScreen( "menuPlayerPoints_");
	menuPlayerPoints.name = "menuPlayerPoints_";
	menuPlayerPoints.title = "Score aanpassen";
	menuPlayerPoints.selectedItem = 0;
	menuPlayerPoints.itemLabels = menuPlayerPointsItems;
	theTerminal.Push( menuPlayerPoints );
}
function menuPlayerPoints_ValueUpdated(theScreen, theProperty) {
	getScore(theScreen.selectedItem+1);
}
var playerScoreNumberRequest = 0;
function getScore(playerScoreNumber) {
		var nameField = CreateTextFieldDialog( "getScore_");		
		nameField.name = "getScore_";
		nameField.maxLength = 20;
		nameField.prompt = "Score Speler " + playerScoreNumber + ": " + playerNames[playerScoreNumber][0];
		nameField.value = playerNames[playerScoreNumber][1];  
		playerScoreNumberRequest = playerScoreNumber;
		theTerminal.Push(nameField); 
}

function getScore_OK(textfield) {
	playerNames[playerScoreNumberRequest][1] = parseInt(textfield.value);
}

//GENERAL
function selectPlayer(selectedPlayer,menuGetBack, translateSortedPlayerNumber) {
	if (translateSortedPlayerNumber) {
		//since players are sorted, translated selected player into actual player number
		selectedPlayer = translatePlayerSortedToActual(selectedPlayer);
	} 
	if (selectedPlayer == 0) {
		sendText(" ", false);
	} else {
		sendText("" + selectedPlayer, false);
	}
	//track timings
	if (activePlayer == 0 && selectedPlayer != 0) {
		//keep start time
		activePlayerTiming = new Date();
	} else if (activePlayer != 0) {
		//keep end time sinds active player was not empty
		currentTimeStamp = new Date();
		var diff = Math.abs(currentTimeStamp.getTime() - activePlayerTiming.getTime()) / 1000;
		if (menuGetBack != "show369Menu") {
			playerNames[activePlayer][1] = playerNames[activePlayer][1] - Math.round(diff + 0.80);
		}
		activePlayerTiming = new Date();
	}
	activePlayer = selectedPlayer;
	
	if (menuGetBack == "show369Menu") {
		theTerminal.PopTo("menuRounds_");
		show369Menu();
	} else if (menuGetBack == "showOpenDourPlayersMenu") {
		theTerminal.PopTo("menuOpenDours_");
		showOpenDourPlayersMenu();
	} else if (menuGetBack == "showOpenDourMenu") {
		theTerminal.PopTo("menuRounds_");
		showOpenDourMenu();
	} else if (menuGetBack == "showPuzzelPlayersMenu") {
		theTerminal.PopTo("menuRounds_");
		showPuzzelPlayersMenu();
	} else if (menuGetBack == "showPuzzelMenu") {
		theTerminal.PopTo("menuRounds_");
		showPuzzelMenu();
	} else if (menuGetBack == "showGalleryQuestion") {
		theTerminal.PopTo("menuGallery_");
		showGalleryQuestion();
	} else if (menuGetBack == "showGalleryPlayersMenu") {
		theTerminal.PopTo("menuGallery_");
		showGalleryPlayersMenu();
	} else if (menuGetBack == "showGalleryMenu") {
		theTerminal.PopTo("menuRounds_");
		showGalleryMenu();
	} else if (menuGetBack == "showGalleryPlayersMenu") {
		theTerminal.PopTo("menuGallery_");
		showGalleryPlayersMenu();
	} else if (menuGetBack == "showGallerySolution") {
		theTerminal.PopTo("menuRounds_");
		showGallerySolution();
	} else if (menuGetBack == "showRoundsMenu") {
		theTerminal.PopTo("dsmMenu_");
		showRoundsMenu();
	} else if (menuGetBack == "showCollectiveMemoryPlayersMenu") {
		theTerminal.PopTo("menuCollectiveMemory_");
		showCollectiveMemoryPlayersMenu();
	} else if (menuGetBack == "showCollectiveMemoryMenu") {
		theTerminal.PopTo("menuRounds_");
		showCollectiveMemoryMenu();
	} else if (menuGetBack == "showFinalsPlayersMenu") {
		theTerminal.PopTo("menuFinals_");
		showFinalsPlayersMenu();
	} 
}
function selectFinalPlayer(selectedPlayer,menuGetBack, translateSortedPlayerNumber) {
	if (translateSortedPlayerNumber) {
		//since players are sorted, translated selected player into actual player number
		selectedPlayerOrig = translateFinalPlayerSortedToOriginal(selectedPlayer);
		selectedPlayerActual = translateFinalPlayerSortedToActual(selectedPlayer);
	} 
	if (selectedPlayer == 0) {
		sendText(" ", false);
	} else {
		sendText("" + selectedPlayerActual, false);
	}
	//track timings
	if (activePlayer == 0 && selectedPlayerOrig != 0) {
		//keep start time
		activePlayerTiming = new Date();
	} else if (activePlayer != 0) {
		//keep end time sinds active player was not empty
		currentTimeStamp = new Date();
		var diff = Math.abs(currentTimeStamp.getTime() - activePlayerTiming.getTime()) / 1000;
		if (menuGetBack != "show369Menu") {
			playerNames[activePlayer][1] = playerNames[activePlayer][1] - Math.round(diff);
		}
		activePlayerTiming = new Date();
	}
	activePlayer = selectedPlayerOrig;
	
	if (menuGetBack == "showFinalsPlayersMenu") {
		theTerminal.PopTo("menuFinals_");
		showFinalsPlayersMenu();
	} 
}

//sortedPlayer is 0 based
//players is 1 based
//translatePlayerSortedToActual is 1 based
function translatePlayerSortedToActual(playerNumber) {
	if (sortedPlayerNames == null || playerNumber == 0) {
		return playerNumber;
	} else {
		return sortedPlayerNames[playerNumber-1][2];
	}
}
function getSortedPlayerNames() {
	var sortedPlayers = new Array();
	for (var i = 1; i < 5; i++) {
		sortedPlayers[i] = [playerNames[i][0],playerNames[i][1],playerNames[i][2]];
	}
	sortedPlayers.sort(function(a,b){return a[1] - b[1]});
	return sortedPlayers;
}
function getSortedFinalPlayerNames(finalPlayer1, finalPlayer2) {
	var sortedFinalPlayers = new Array();
	sortedFinalPlayers[1] = [playerNames[finalPlayer1][0],playerNames[finalPlayer1][1],1,finalPlayer1];
	sortedFinalPlayers[2] = [playerNames[finalPlayer2][0],playerNames[finalPlayer2][1],2,finalPlayer2];
	sortedFinalPlayers.sort(function(a,b){return a[1] - b[1]});
	return sortedFinalPlayers;
}
function translateFinalPlayerSortedToActual(playerNumber) {
	if (sortedFinalPlayerNames == null || playerNumber == 0) {
		return playerNumber;
	} else {
		return sortedFinalPlayerNames[playerNumber-1][2];
	}
}
function translateFinalPlayerSortedToOriginal(playerNumber) {
	if (sortedFinalPlayerNames == null || playerNumber == 0) {
		return playerNumber;
	} else {
		return sortedFinalPlayerNames[playerNumber-1][3];
	}
}


//FINALS
function showFinalsInfo() {
	showMoveToNextScreenQuestion("De Finale");
	if (!infoFinalsShown) {
		infoFinalsShown = true;
		var msgbox = CreateMessageboxDialog( "messagebox_");
		msgbox.title = "De Finale";
		msgbox.textualContent = "\n  De Finale\n\nBij iedere vraag horen 5 kernwoorden.\n\nVoor elk juist antwoord verliest de tegenstander 20sec.\n\nDe speler met het minst aantal punten mag beginnen antwoorden.\n\nDe speler die het eerst aan 0sec komt verliest de finale.";
		theTerminal.Push(msgbox);
	}
}
function showFinalsMenu() {
//0: player 1
//1: player 2
//2: player 3
//3: player 4
//4: Start Finale
//5: Vorig scherm
	activePlayer = 0;
	var menuFinalsItems = new Array();
	//ShowMessage("Player: "+sortedPlayerNames[0][2]+" played: " + playedOpenDour[sortedPlayerNames[0][2]-1]+"\nPlayer: "+sortedPlayerNames[1][2]+" played: " + playedOpenDour[sortedPlayerNames[1][2]-1]+"\nPlayer: "+sortedPlayerNames[2][2]+" played: " + playedOpenDour[sortedPlayerNames[2][2]-1]+"\nPlayer: "+sortedPlayerNames[3][2]+", played: " + playedOpenDour[sortedPlayerNames[3][2]-1] + "\ncurrentPlayer " + currentOpenDourMoviePlayer + "\ncurrentMovie "+ currentOpenDourMovie);
	for (var playerCounter = 1; playerCounter < 5; playerCounter++) {
		if (playerCounter == finalPlayer1) {
			menuFinalsItems[playerCounter - 1] = "1* Speler "+(playerCounter)+": " + playerNames[playerCounter][0] + " ("+ playerNames[playerCounter][1] + "s)";
		} else if (playerCounter == finalPlayer2) {
			menuFinalsItems[playerCounter - 1] = "2* Speler "+(playerCounter)+": " + playerNames[playerCounter][0] + " ("+ playerNames[playerCounter][1] + "s)";
		} else {
			menuFinalsItems[playerCounter - 1] = "Speler "+(playerCounter)+": " + playerNames[playerCounter][0] + " ("+ playerNames[playerCounter][1] + "s)";
		}
	}
	menuFinalsItems[4] = "Start finale";
	var menuFinals = CreateListScreen( "menuFinals_");
	menuFinals.name = "menuFinals_";
	menuFinals.title = "De Finale";
	menuFinals.selectedItem = 0;
	menuFinals.itemLabels = menuFinalsItems;
	theTerminal.Push( menuFinals );
}
function menuFinals_ValueUpdated(theScreen, theProperty)
{
	if (theScreen.selectedItem == 4) {
		if (finalPlayer1 != 0 && finalPlayer2 != 0) {
			//start final
			currentFinal = 0;
			showFinalsPlayersMenu();
			showKeypad();
			showHistory("Finalist 1: "+ playerNames[finalPlayer1][0] +"\nFinalist 2: "+ playerNames[finalPlayer2][0] + "\n", true);
			showHistory("-selecteer finalisten\n-start de finale\n-klik op 'Back'-toets", true);
		}
	} else if (theScreen.selectedItem < 4) {
		//store or remove content of finalPlayer1 and finalPlayer2
		if (finalPlayer1 == 0 && (finalPlayer2 != (theScreen.selectedItem + 1))) {
			finalPlayer1 = theScreen.selectedItem + 1;
		} else if (finalPlayer2 == 0 && (finalPlayer1 != (theScreen.selectedItem + 1))) {
			finalPlayer2 = theScreen.selectedItem + 1;
		} else if (finalPlayer1 == (theScreen.selectedItem + 1)) {
			finalPlayer1 = 0;
		} else if (finalPlayer2 == (theScreen.selectedItem + 1)) {
			finalPlayer2 = 0;
		}
		theTerminal.PopTo("menuRounds_");
		showFinalsMenu();
	}
}

function showFinalsPlayersMenu(finalsNumber) {
	if (finalsNumber != null) {
		currentFinal = finalsNumber;
	} else if (currentFinal > 27) {
		currentFinal = 0;
		activePlayer = 0;
	}	
	var menuFinalsItems = new Array();
	menuFinalsItems[0] = (activePlayer == 0 ? "-" : "") + "Stop / Geen speler";
	sortedFinalPlayerNames = getSortedFinalPlayerNames(finalPlayer1, finalPlayer2);
	if (playedFinals[(sortedFinalPlayerNames[0][2])-1] > 27) {
		menuFinalsItems[1] = (sortedFinalPlayerNames[0][3] == activePlayer ? "-" : "") + "(" + "Speler "+(sortedFinalPlayerNames[0][2])+": " + sortedFinalPlayerNames[0][0] + " ("+ sortedFinalPlayerNames[0][1] + "s))";
	} else {
		menuFinalsItems[1] = (sortedFinalPlayerNames[0][3] == activePlayer ? "-" : "") + "Speler "+(sortedFinalPlayerNames[0][2])+": " + sortedFinalPlayerNames[0][0] + " ("+ sortedFinalPlayerNames[0][1] + "s)";
	}
	if (playedFinals[(sortedFinalPlayerNames[1][2])-1] > 27) {
		menuFinalsItems[2] = (sortedFinalPlayerNames[1][3] == activePlayer ? "-" : "") + "(" + "Speler "+(sortedFinalPlayerNames[1][2])+": " + sortedFinalPlayerNames[1][0] + " ("+ sortedFinalPlayerNames[1][1] + "s))";
	} else {
		menuFinalsItems[2] = (sortedFinalPlayerNames[1][3] == activePlayer ? "-" : "") + "Speler "+(sortedFinalPlayerNames[1][2])+": " + sortedFinalPlayerNames[1][0] + " ("+ sortedFinalPlayerNames[1][1] + "s)";
	}
	menuFinalsItems[3] = "V" + (currentFinal + 1) + ": " + finals[currentFinal][1];
	for (var answerCounter = 0; answerCounter < 5; answerCounter++) {
		answerState = finalsAnswersFound[currentFinal][answerCounter];
		if (answerState) {
			menuFinalsItems[4 + answerCounter] = "(" + (answerCounter + 1) + ": " + finals[currentFinal][2][answerCounter] + ")";
		} else {
			menuFinalsItems[4 + answerCounter] = (answerCounter + 1) + ": " + finals[currentFinal][2][answerCounter];
		}
	}
	menuFinalsItems[9] = (activePlayer == 0 ? "-" : "") + "Stop / Geen speler";
	if (currentFinal < 27) {
		menuFinalsItems[10] = "Volgende vraag";
	} else {	
		menuFinalsItems[10] = "Ronde selectie";
	}
	menuFinalsItems[11] = "Selecteer vraag";
	menuFinalsItems[12] = "Score aanpassen";
	var menuFinalQuestion = CreateListScreen( "menuFinalQuestion_");
	menuFinalQuestion.name = "menuCollectiveMemory_";
	menuFinalQuestion.title = "De Finale " + (currentFinal + 1);
	menuFinalQuestion.selectedItem = 0;
	menuFinalQuestion.itemLabels = menuFinalsItems;
	theTerminal.Push( menuFinalQuestion );
}
function menuFinalQuestion_ValueUpdated(theScreen, theProperty)
{
	if (theScreen.selectedItem >= 0 && theScreen.selectedItem < 3) {
		if (firstTimeShowFinalsPlayerMenu) {
			sendText("12 ", false);//fix dsm bug in this specific round
			firstTimeShowFinalsPlayerMenu = false;
		}
		//player selected
		selectedPlayer = translateFinalPlayerSortedToActual(theScreen.selectedItem);
		if (playedFinals[selectedPlayer-1] < 27) {
			playedFinals[selectedPlayer-1] = (playedFinals[selectedPlayer-1] + 27);
		} 
		selectFinalPlayer(theScreen.selectedItem, "showFinalsPlayersMenu", true);
	} else if (theScreen.selectedItem == 3) {
		showFinalQuestionDetails(currentFinal);
	} else if (theScreen.selectedItem > 3 && theScreen.selectedItem < 9) {
		//answer selected
		answerState = finalsAnswersFound[currentFinal][theScreen.selectedItem-4];
		if (!answerState) {
			sendText(finalsSendKeys[theScreen.selectedItem-4], false);
			finalsAnswersFound[currentFinal][theScreen.selectedItem-4] = true;
			if (activePlayer != 0) {
				if (activePlayer == finalPlayer1) {
					//corret answer removed points from opponent
					playerNames[finalPlayer2][1] = playerNames[finalPlayer2][1] - 20;
				} else if (activePlayer == finalPlayer2) {
					//corret answer removed points from opponent
					playerNames[finalPlayer1][1] = playerNames[finalPlayer1][1] - 20;
				}
			}
			if (finalsAnswersFound[currentFinal][0] && finalsAnswersFound[currentFinal][1] && finalsAnswersFound[currentFinal][2] && finalsAnswersFound[currentFinal][3] && finalsAnswersFound[currentFinal][4]) {
				selectPlayer(0,"showFinalsPlayersMenu", false);
			} else {
				selectPlayer(activePlayer,"showFinalsPlayersMenu", false);
			}
		}			
	} else if (theScreen.selectedItem == 9) {
		//no player selected
		selectFinalPlayer(0, "showFinalsPlayersMenu", false);
	} else if (theScreen.selectedItem == 10) {
		if (currentFinal < 27) {
			SendVirtualKeystroke( 0x27, false, false, false, false ); //right
			currentFinal++;
			selectPlayer(0,"showFinalsPlayersMenu", false);
		} else {
			selectPlayer(0,"showRoundsMenu", false);
		}
	} else if (theScreen.selectedItem == 11) {
		selectFinalQuestion();
	} else if (theScreen.selectedItem == 12) {
		showPointCorrectionMenu();
	}
}
function showFinalQuestionDetails(finalQuestion) {
	var msgbox = CreateMessageboxDialog( "messagebox_");
	msgbox.title = "V" + finalQuestion+1;
	msgbox.textualContent = "\n\n" + finals[finalQuestion][1];
	theTerminal.Push(msgbox);	
}

function selectFinalQuestion() {
	var menuFinalQuestionsItems = new Array();
	for ( var counterQuestion = 0; counterQuestion < 27 ; counterQuestion++) {
		if (counterQuestion < currentFinal) {
			menuFinalQuestionsItems[counterQuestion] = "(" + (counterQuestion + 1) + ":" + finals[counterQuestion][1] + ")";
		} else {
			menuFinalQuestionsItems[counterQuestion] = (counterQuestion + 1) + ":" + finals[counterQuestion][1];
		}
	} 
	var menuFinalQuestions = CreateListScreen( "menuFinalQuestions_");
	menuFinalQuestions.name = "menuFinalQuestions_";
	menuFinalQuestions.title = "Finale Vragen";
	menuFinalQuestions.selectedItem = 0;
	menuFinalQuestions.itemLabels = menuFinalQuestionsItems;
	theTerminal.Push( menuFinalQuestions );
}

function menuFinalQuestions_ValueUpdated(theScreen, theProperty)
{
		theTerminal.PopTo("menuFinals_");
		showFinalsPlayersMenu(theScreen.selectedItem);
}

//COLLECTIVE MEMORY
function showCollectiveMemoryInfo() {
	showMoveToNextScreenQuestion("Het Collectief Geheugen");
	if (!infoCollectiveMemoryShown) {
		infoCollectiveMemoryShown = true;
		var msgbox = CreateMessageboxDialog( "messagebox_");
		msgbox.title = "Het Collectief Geheugen";
		msgbox.textualContent = "\n  Het Collectief Geheugen\n\nIedere speler krijgt een filmpje over een bepaalde gebeurtenis.\nDe speler moet hierbij 5 kernwoorden raden.\nDit levert 10sec tot het laatste antwoord 50sec op.\nAndere spelers mogen aanvullen,\ndeze met het minst aantal punten eerst.";
		theTerminal.Push(msgbox);
	}
}
function showCollectiveMemoryMenu() {
//0: player 1
//1: player 2
//2: player 3
//3: player 4
//4: CollectiveMemory 1
//5: CollectiveMemory 2
//6: CollectiveMemory 3
//7: CollectiveMemory 4
//8: Volgend scherm
//9: Vorig scherm
	activePlayer = 0;
	restorePlayedCollectiveMemory();
	var menuCollectiveMemoryItems = new Array();
	sortedPlayerNames = getSortedPlayerNames();
	//ShowMessage("Player: "+sortedPlayerNames[0][2]+" played: " + playedOpenDour[sortedPlayerNames[0][2]-1]+"\nPlayer: "+sortedPlayerNames[1][2]+" played: " + playedOpenDour[sortedPlayerNames[1][2]-1]+"\nPlayer: "+sortedPlayerNames[2][2]+" played: " + playedOpenDour[sortedPlayerNames[2][2]-1]+"\nPlayer: "+sortedPlayerNames[3][2]+", played: " + playedOpenDour[sortedPlayerNames[3][2]-1] + "\ncurrentPlayer " + currentOpenDourMoviePlayer + "\ncurrentMovie "+ currentOpenDourMovie);
	for (var playerCounter = 0; playerCounter < 4; playerCounter++) {
		if (sortedPlayerNames[playerCounter][2] == currentCollectiveMemoryPlayer) {
			menuCollectiveMemoryItems[playerCounter] = "* Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		} else if (playedCollectiveMemory[(sortedPlayerNames[playerCounter][2]-1)] > 0) {
			menuCollectiveMemoryItems[playerCounter] = "(Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s))";
		} else {
			menuCollectiveMemoryItems[playerCounter] = "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		}
	}
	for(var i = 0; i < 4; i++) {
		menuCollectiveMemoryItems[i+4] = (collectiveMemoryPlayed(i+1) ? "(" : "") + "Filmpje "+ (i+1) +": " + collectiveMemories[i][0] + (collectiveMemoryPlayed(i+1) ? ")" : "");
	}
	menuCollectiveMemoryItems[8] = "Volgend scherm";
	menuCollectiveMemoryItems[9] = "Vorig scherm";
	var menuCollectiveMemory = CreateListScreen( "menuCollectiveMemory_");
	menuCollectiveMemory.name = "menuCollectiveMemory_";
	menuCollectiveMemory.title = "Het Collectief Geheugen";
	menuCollectiveMemory.selectedItem = 0;
	menuCollectiveMemory.itemLabels = menuCollectiveMemoryItems;
	theTerminal.Push( menuCollectiveMemory );
}
function menuCollectiveMemory_ValueUpdated(theScreen, theProperty)
{
	if (theScreen.selectedItem == 8) {
		sendText("n", false);
	} else if (theScreen.selectedItem == 9) {
		sendText("b", false);
	} else if (theScreen.selectedItem > 3 && theScreen.selectedItem < 8) {
		currentCollectiveMemory = theScreen.selectedItem - 4;
		collectiveMemoryAnswerSolvedSequence = 1;
		showCollectiveMemoryQuestion();
	} else if (theScreen.selectedItem < 4) {
		restorePlayedCollectiveMemory();
		selectedPlayer = translatePlayerSortedToActual(theScreen.selectedItem+1);
		if (playedCollectiveMemory[selectedPlayer-1] == 0) {
			currentCollectiveMemoryPlayer = selectedPlayer;
		} else {
			currentCollectiveMemoryPlayer = 0;
		}
		theTerminal.PopTo("menuRounds_");
		showCollectiveMemoryMenu();
	}
}

function restorePlayedCollectiveMemory() {
	if (playedCollectiveMemory[0] > 4) {
		playedCollectiveMemory[0] = playedCollectiveMemory[0]-5;
	}
	if (playedCollectiveMemory[1] > 4) {
		playedCollectiveMemory[1] = playedCollectiveMemory[1]-5;
	}
	if (playedCollectiveMemory[2] > 4) {
		playedCollectiveMemory[2] = playedCollectiveMemory[2]-5;
	}
	if (playedCollectiveMemory[3] > 4) {
		playedCollectiveMemory[3] = playedCollectiveMemory[3]-5;
	}
}
function collectiveMemoryPlayed(movieNumber) {
	return (playedCollectiveMemory[0] == movieNumber || playedCollectiveMemory[1] == movieNumber || playedCollectiveMemory[2] == movieNumber || playedCollectiveMemory[3] == movieNumber);
}

function showCollectiveMemoryQuestion() {
	if (currentCollectiveMemoryPlayer != 0) {
		SendVirtualKeystroke( 0x27, false, false, false, false ); //right
		var widget = CreateQuestionDialog( "collectiveMemoryQuestion_");
		widget.textualContent = "\n\n" + collectiveMemories[currentCollectiveMemory][1] + "\n\nYes: antwoordenscherm, filmpje wordt gestopt\n\nNo: vorig scherm";
		theTerminal.Push(widget);	
	} 
}
function collectiveMemoryQuestion_OK(textfield) {
	playedCollectiveMemory[currentCollectiveMemoryPlayer-1] = currentCollectiveMemory+1;
	SendVirtualKeystroke( 0x27, false, false, false, false ); //right
	showCollectiveMemoryPlayersMenu();
}
function collectiveMemoryQuestion_Cancel(textfield) {
	playedCollectiveMemory[currentCollectiveMemoryPlayer-1] = 0;
	sendText("bn", false);
	showCollectiveMemoryMenu();
}

function showCollectiveMemoryPlayersMenu(movieNumber) {
	if (movieNumber != null) {
		currentCollectiveMemory = movieNumber;
	} else if (currentCollectiveMemory > 3) {
		currentCollectiveMemory = 0;
		activePlayer = 0;
	}	
	if (currentCollectiveMemory == 0 && currentCollectiveMemoryPlayer != 0) {
		sendText("1234 ", false);//fix dsm bug in this specific round
	}
	var menuCollectiveMemoryPlayerItems = new Array();
	menuCollectiveMemoryPlayerItems[0] = (activePlayer == 0 ? "-" : "") + "Stop / Geen speler";
	sortedPlayerNames = getSortedPlayerNames();
	//ShowMessage("Player: "+sortedPlayerNames[0][2]+" played: " + playedCollectiveMemory[sortedPlayerNames[0][2]-1]+"\nPlayer: "+sortedPlayerNames[1][2]+" played: " + playedCollectiveMemory[sortedPlayerNames[1][2]-1]+"\nPlayer: "+sortedPlayerNames[2][2]+" played: " + playedCollectiveMemory[sortedPlayerNames[2][2]-1]+"\nPlayer: "+sortedPlayerNames[3][2]+", played: " + playedCollectiveMemory[sortedPlayerNames[3][2]-1] + "\ncurrentPlayer " + currentCollectiveMemoryPlayer + "\ncurrentMovie "+ currentCollectiveMemory);
	for (var playerCounter = 0; playerCounter < 4; playerCounter++) {
		if (playedCollectiveMemory[(sortedPlayerNames[playerCounter][2])-1] > 4) {
			menuCollectiveMemoryPlayerItems[playerCounter+1] = (sortedPlayerNames[playerCounter][2] == activePlayer ? "-" : "") + "(" + "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s))";
		} else if (sortedPlayerNames[playerCounter][2] == currentCollectiveMemoryPlayer) {
			menuCollectiveMemoryPlayerItems[playerCounter+1] = (sortedPlayerNames[playerCounter][2] == activePlayer ? "-" : "") + "* " + "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		} else {
			menuCollectiveMemoryPlayerItems[playerCounter+1] = (sortedPlayerNames[playerCounter][2] == activePlayer ? "-" : "") + "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		}
	}
	for (var answerCounter = 0; answerCounter < 5; answerCounter++) {
		answerState = collectiveMemoryAnswersFound[currentCollectiveMemory][answerCounter];
		if (answerState) {
			menuCollectiveMemoryPlayerItems[5 + answerCounter] = "(" + (answerCounter + 1) + ": " + collectiveMemories[currentCollectiveMemory][2][answerCounter] + ")";
		} else {
			menuCollectiveMemoryPlayerItems[5 + answerCounter] = (answerCounter + 1) + ": " + collectiveMemories[currentCollectiveMemory][2][answerCounter];
		}
	}
	menuCollectiveMemoryPlayerItems[10] = (activePlayer == 0 ? "-" : "") + "Stop / Geen speler";
	if (currentCollectiveMemory < 3) {
		menuCollectiveMemoryPlayerItems[11] = "Volgend filmpje";
	} else {	
		menuCollectiveMemoryPlayerItems[11] = "Ronde selectie";
	}
	menuCollectiveMemoryPlayerItems[12] = "Score aanpassen";
	var menuCollectiveMemoryPlayers = CreateListScreen( "menuCollectiveMemoryPlayer_");
	menuCollectiveMemoryPlayers.name = "menuCollectiveMemoryPlayer_";
	menuCollectiveMemoryPlayers.title = "Het Collectief Geheugen " + (currentCollectiveMemory + 1);
	menuCollectiveMemoryPlayers.selectedItem = 0;
	menuCollectiveMemoryPlayers.itemLabels = menuCollectiveMemoryPlayerItems;
	theTerminal.Push( menuCollectiveMemoryPlayers );
}
function menuCollectiveMemoryPlayer_ValueUpdated(theScreen, theProperty)
{
	if (theScreen.selectedItem >= 0 && theScreen.selectedItem < 5) {
		//player selected
		selectedPlayer = translatePlayerSortedToActual(theScreen.selectedItem);
		if (playedCollectiveMemory[selectedPlayer-1] < 5) {
			playedCollectiveMemory[selectedPlayer-1] = (playedCollectiveMemory[selectedPlayer-1] + 5);
		} 
		currentCollectiveMemoryPlayer = 0;
		selectPlayer(theScreen.selectedItem, "showCollectiveMemoryPlayersMenu", true);
	} else if (theScreen.selectedItem > 4 && theScreen.selectedItem < 10) {
		//answer selected
		answerState = collectiveMemoryAnswersFound[currentCollectiveMemory][theScreen.selectedItem-5];
		if (!answerState) {
			sendText(collectiveMemorySendKeys[theScreen.selectedItem-5], false);
			collectiveMemoryAnswersFound[currentCollectiveMemory][theScreen.selectedItem-5] = true;
			if (activePlayer != 0) {
				playerNames[activePlayer][1] = playerNames[activePlayer][1] + 10 * collectiveMemoryAnswerSolvedSequence++;		
			}
			if (collectiveMemoryAnswersFound[currentCollectiveMemory][0] && collectiveMemoryAnswersFound[currentCollectiveMemory][1] && collectiveMemoryAnswersFound[currentCollectiveMemory][2] && collectiveMemoryAnswersFound[currentCollectiveMemory][3] && collectiveMemoryAnswersFound[currentCollectiveMemory][4]) {
				currentCollectiveMemoryPlayer = 0;
				selectPlayer(0,"showCollectiveMemoryPlayersMenu", false);
			} else {
				selectPlayer(activePlayer,"showCollectiveMemoryPlayersMenu", false);
			}
		}			
	} else if (theScreen.selectedItem == 10) {
		//no player selected
		currentCollectiveMemoryPlayer = 0;
		selectPlayer(0, "showCollectiveMemoryPlayersMenu", false);
	} else if (theScreen.selectedItem == 11) {
		if (currentCollectiveMemory < 3) {
			currentCollectiveMemoryPlayer = 0;
			sendText("n", false);
			selectPlayer(0,"showCollectiveMemoryMenu", false);
		} else {
			restorePlayedCollectiveMemory();
			currentCollectiveMemoryPlayer = 0;
			selectPlayer(0,"showRoundsMenu", false);
		}
	} else if (theScreen.selectedItem == 12) {
		showPointCorrectionMenu();
	}
}

//GALLERY
function showGalleryInfo() {
	showMoveToNextScreenQuestion("De Galerij");
	if (!infoGalleryShown) {
		infoGalleryShown = true;
		var msgbox = CreateMessageboxDialog( "messagebox_");
		msgbox.title = "De Galerij";
		msgbox.textualContent = "\n  De Galerij\n\nIedere speler krijgt een reeks van 10 afbeeldingen binnen een bepaald thema.\n\nDe speler moet het kernwoord van ieder beeld raden, ieder geraden woord levert 15sec op.\n\nDe andere spelers mogen kernwoorden aanvullen, deze met het minst aantal punten eerst.";
		theTerminal.Push(msgbox);
	}
}
function showGalleryMenu() {
//0: player 1
//1: player 2
//2: player 3
//3: palyer 4
//4: gallery 1
//5: gallery 2
//6: gallery 3
//7: gallery 4
//8: next picture
//9: previous picture
	activePlayer = 0;
	restorePlayedGallery();
	var menuGalleryItems = new Array();
	sortedPlayerNames = getSortedPlayerNames();
	//ShowMessage("Player: "+sortedPlayerNames[0][2]+" played: " + playedPuzzel[sortedPlayerNames[0][2]-1]+"\nPlayer: "+sortedPlayerNames[1][2]+" played: " + playedPuzzel[sortedPlayerNames[1][2]-1]+"\nPlayer: "+sortedPlayerNames[2][2]+" played: " + playedPuzzel[sortedPlayerNames[2][2]-1]+"\nPlayer: "+sortedPlayerNames[3][2]+", played: " + playedPuzzel[sortedPlayerNames[3][2]-1] + "\ncurrentPlayer " + currentPuzzelPlayer + "\ncurrentPuzzel "+ currentPuzzel);
	for (var playerCounter = 0; playerCounter < 4; playerCounter++) {
		if (sortedPlayerNames[playerCounter][2] == currentGalleryPlayer) {
			menuGalleryItems[playerCounter] = "* Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		} else if (playedGallery[(sortedPlayerNames[playerCounter][2]-1)] > 0) {
			menuGalleryItems[playerCounter] = "(Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s))";
		} else {
			menuGalleryItems[playerCounter] = "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		}
	}
	for (var i = 0; i < 4; i++) {
		menuGalleryItems[i+4] = (galleryPlayed(i+1) ? "(" : "") + "Galerij "+(i+1)+": " + galleries[i][0] + (galleryPlayed(i+1) ? ")" : "");
	}
	menuGalleryItems[8] = "Volgende afbeelding";
	menuGalleryItems[9] = "Vorige afbeelding";
	var menuGallery = CreateListScreen( "menuGallery_");
	menuGallery.name = "menuGallery_";
	menuGallery.title = "De Galerij";
	menuGallery.selectedItem = 0;
	menuGallery.itemLabels = menuGalleryItems;
	theTerminal.Push( menuGallery );
}
function menuGallery_ValueUpdated(theScreen, theProperty)
{
	if (theScreen.selectedItem == 8) {
		SendVirtualKeystroke( 0x27, false, false, false, false ); //right
	} else if (theScreen.selectedItem == 9) {
		SendVirtualKeystroke( 0x25, false, false, false, false ); //left
	} else if (theScreen.selectedItem > 3 && theScreen.selectedItem < 8) {
		currentGallery = theScreen.selectedItem - 4;
		currentGalleryImageNumber = 0;
		selectPlayer(currentGalleryPlayer, "showGalleryQuestion", false);
	} else if (theScreen.selectedItem < 4) {
		restorePlayedGallery();
		selectedPlayer = translatePlayerSortedToActual(theScreen.selectedItem+1);
		if (playedGallery[selectedPlayer-1] == 0) {
			currentGalleryPlayer = selectedPlayer;
		} else {
			currentGalleryPlayer = 0;
		}
		theTerminal.PopTo("menuRounds_");
		showGalleryMenu();
	}
}

function restorePlayedGallery() {
	if (playedGallery[0] > 4) {
		playedGallery[0] = playedGallery[0]-5;
	}
	if (playedGallery[1] > 4) {
		playedGallery[1] = playedGallery[1]-5;
	}
	if (playedGallery[2] > 4) {
		playedGallery[2] = playedGallery[2]-5;
	}
	if (playedGallery[3] > 4) {
		playedGallery[3] = playedGallery[3]-5;
	}
}
function galleryPlayed(galleryNumber) {
	return (playedGallery[0] == galleryNumber || playedGallery[1] == galleryNumber || playedGallery[2] == galleryNumber || playedGallery[3] == galleryNumber);
}

function showGallerySolution() {
	SendVirtualKeystroke( 0x27, false, false, false, false ); //right
	galleryMediaSolutionWidget = CreateMediaplayerScreen( "galleryMediaSolutionWidget_");
	slideRow = galleryMediaSolutionWidget.CreateRow("", scLeft, scClip, scLarge);
	playerRow = galleryMediaSolutionWidget.CreateRow("", scLeft, scWrap, scLarge);
	emptyRow = galleryMediaSolutionWidget.CreateRow("", scLeft, scWrap, scMedium);
	answerCommentRow = galleryMediaSolutionWidget.CreateRow("Antwoord: ", scLeft, scWrap, scMedium);
	answerRow = galleryMediaSolutionWidget.CreateRow("", scLeft, scWrap, scLarge);
	emptyRow2 = galleryMediaSolutionWidget.CreateRow("", scLeft, scWrap, scMedium);
	usageRow  = galleryMediaSolutionWidget.CreateRow((currentGalleryImageNumber >=9 ? "Galerij selectie" : "Volgende foto") + ": scherm beweging\nTerug naar menu: Menu of Help", scLeft, scWrap, scMedium);
	galleryMediaSolutionWidget.title = "Gallerij " + (currentGallery +1);
	galleryMediaSolutionWidget.name = "galleryMediaWidget_";
	galleryMediaSolutionWidget.imageStyle = scFloatRight;
	galleryMediaWidgetCurrentStartTime = new Date();
	galleryCorrectAnswers = 0;
	theTerminal.Push(galleryMediaSolutionWidget);
}
function galleryMediaSolutionWidget_Update(theScreen) {
	try {
		galleryMediaSolutionWidget.image = currentImageBaseFolder + "\\" + (((currentGallery+1) * 10) + currentGalleryImageNumber) + "asmall.jpg";
	} catch (e) {
		try {
			galleryMediaSolutionWidget.image = currentImageBaseFolder + "\\" + (((currentGallery+1) * 10) + currentGalleryImageNumber) + "a.jpg";
		} catch (e) {}
	}
	slideRow.textualContent = (currentGalleryImageNumber+1) + "/10";
	answerRow.textualContent = "\"" + galleries[currentGallery][1][currentGalleryImageNumber] + "\"";
	answerRow.overflow = scWrap;
	if (galleriesAnswersFound[currentGallery][currentGalleryImageNumber] != false && galleriesAnswersFound[currentGallery][currentGalleryImageNumber] > 0) {
		playerRow.textualContent = "\n\nGevonden door:\nSpeler " + playerNames[galleriesAnswersFound[currentGallery][currentGalleryImageNumber]][2] +": " + playerNames[galleriesAnswersFound[currentGallery][currentGalleryImageNumber]][0];
	} else {
		playerRow.textualContent = "\n\nNiet gevonden";
	}
	var now = new Date();
	theScreen.playerState = scPlaying;
}
function galleryMediaSolutionWidget_KeyDown(theScreen, theKey)
{	
	try {
		if( theKey == "^" || theKey == ">" || theKey == "u" ) {   
			//next
			if (currentGalleryImageNumber < 9) {
				currentGalleryImageNumber++;
			} else {
				selectPlayer(0, "showGalleryMenu", false);
			}
			SendVirtualKeystroke( 0x27, false, false, false, false ); //right
		} else if( theKey == "v" || theKey == "<" || theKey == "d" ) {
			//previous
			if (currentGalleryImageNumber < 9) {
				currentGalleryImageNumber++;
			} else {
				selectPlayer(0, "showGalleryMenu", false);
			}
			SendVirtualKeystroke( 0x27, false, false, false, false ); //right
		} else if( theKey == ":help" || theKey == "#" ) {
			//help
			selectPlayer(0, "showGalleryMenu", false);
		} else if (theKey == "f" || theKey == "*") {
			//menu
			selectPlayer(0, "showGalleryMenu", false);
		}
	} catch (e) {
		var errPopup = CreatePopupDialog( "");
		errPopup.textualContent = e.message;
		theTerminal.Push(errPopup);	
	}
	
	return true;	
}

function showGalleryQuestion() {
	if (activePlayer != 0) {
		SendVirtualKeystroke( 0x27, false, false, false, false ); //right
		playedGallery[currentGalleryPlayer-1] = currentGallery+1;
		if (playedGallery[currentGalleryPlayer-1] < 5) {
				playedGallery[currentGalleryPlayer-1] = (playedGallery[currentGalleryPlayer-1] + 5);
		}
		
		galleryMediaWidget = CreateMediaplayerScreen( "galleryMediaWidget_");
		slideRow = galleryMediaWidget.CreateRow("", scLeft, scClip, scLarge);
		playerRow = galleryMediaWidget.CreateRow("", scLeft, scWrap, scLarge);
		emptyRow = galleryMediaWidget.CreateRow("", scLeft, scWrap, scMedium);
		answerCommentRow = galleryMediaWidget.CreateRow("Antwoord: ", scLeft, scWrap, scMedium);
		answerRow = galleryMediaWidget.CreateRow("", scLeft, scWrap, scLarge);
		emptyRow2 = galleryMediaWidget.CreateRow("", scLeft, scWrap, scMedium);
		usageRow  = galleryMediaWidget.CreateRow("Correct antwoord: scherm beweging\nFoutief antwoord: Menu of Help", scLeft, scWrap, scMedium);
		galleryMediaWidget.title = "Gallerij " + (currentGallery +1);
		galleryMediaWidget.name = "galleryMediaWidget_";
		galleryMediaWidget.imageStyle = scFloatRight;
		galleryMediaWidgetCurrentStartTime = new Date();
		galleryCorrectAnswers = 0;
		theTerminal.Push(galleryMediaWidget);
	} else {
		selectPlayer(0, "showGalleryMenu", false);
	}
}
function galleryMediaWidget_Update(theScreen) {
  try {
  	galleryMediaWidget.image = currentImageBaseFolder + "\\" + (((currentGallery+1) * 10) + currentGalleryImageNumber) + "small.jpg";
  } catch (e) {
		try {
  		galleryMediaWidget.image = currentImageBaseFolder + "\\" + (((currentGallery+1) * 10) + currentGalleryImageNumber) + ".jpg";
		} catch (e) {}
  }
  slideRow.textualContent = (currentGalleryImageNumber+1) + "/10 (" + galleryCorrectAnswers + " gevonden)";
  answerRow.textualContent = "\"" + galleries[currentGallery][1][currentGalleryImageNumber] + "\"";
	answerRow.overflow = scWrap;
  playerRow.textualContent = "Speler " + playerNames[activePlayer][2] +": " + playerNames[activePlayer][0];
  var now = new Date();
	theScreen.mediaPosition = (now - galleryMediaWidgetCurrentStartTime) / 1000;
	theScreen.mediaLength = ((((galleryMediaWidgetCurrentStartTime/1000) + playerNames[activePlayer][1]) * 1000) - galleryMediaWidgetCurrentStartTime) / 1000;
	theScreen.playerState = scPlaying;
}
function galleryMediaWidget_KeyDown(theScreen, theKey)
{	
	try {
		if( theKey == "^" || theKey == ">" || theKey == "u" ) {   
			//next
			if (activePlayer != 0) {
				sendText("a",false);
				SendVirtualKeystroke( 0x27, false, false, false, false ); //right
				playerNames[activePlayer][1] = playerNames[activePlayer][1] + 15;	
				galleriesAnswersFound[currentGallery][currentGalleryImageNumber] = activePlayer;	
				if (currentGalleryImageNumber < 9) {
					currentGalleryImageNumber++;
					galleryCorrectAnswers++;
					galleryMediaWidgetCurrentStartTime = new Date();
				} else {
					selectPlayer(0, "showGalleryPlayersMenu", false);
				}
			} else {
				selectPlayer(0, "showGalleryMenu", false);
			}
		} else if( theKey == "v" || theKey == "<" || theKey == "d" ) {
			//previous
			if (activePlayer != 0) {
				sendText("a",false);
				SendVirtualKeystroke( 0x27, false, false, false, false ); //right
				playerNames[activePlayer][1] = playerNames[activePlayer][1] + 15;	
				galleriesAnswersFound[currentGallery][currentGalleryImageNumber] = activePlayer;	
				if (currentGalleryImageNumber < 9) {
					currentGalleryImageNumber++;
					galleryCorrectAnswers++;
					galleryMediaWidgetCurrentStartTime = new Date();
				} else {
					selectPlayer(0, "showGalleryPlayersMenu", false);
				}
			} else {
				selectPlayer(0, "showGalleryMenu", false);
			}
		} else if( theKey == ":help" || theKey == "#" ) {
			//help
			if (activePlayer != 0) {
				SendVirtualKeystroke( 0x27, false, false, false, false ); //right
				if (currentGalleryImageNumber < 9) {
					currentGalleryImageNumber++;
					galleryMediaWidgetCurrentStartTime = new Date();
				} else {
					selectPlayer(0, "showGalleryPlayersMenu", false);
				}
			} else {
				selectPlayer(0, "showGalleryMenu", false);
			}
		} else if (theKey == "f" || theKey == "*") {
			//menu
			if (activePlayer != 0) {
				SendVirtualKeystroke( 0x27, false, false, false, false ); //right
				if (currentGalleryImageNumber < 9) {
					currentGalleryImageNumber++;
					galleryMediaWidgetCurrentStartTime = new Date();
				} else {
					selectPlayer(0, "showGalleryPlayersMenu", false);
				}
			} else {
				selectPlayer(0, "showGalleryMenu", false);
			}
		}
	} catch (e) {
		var errPopup = CreatePopupDialog( "");
		errPopup.textualContent = e.message;
		theTerminal.Push(errPopup);	
	}
	
	return true;	
}


function showGalleryPlayersMenu(galleryNumber) {
	//0: Stop / Geen speler
	//1..10: afbeeldingen
	//11: Stop / Geen speler
	//12: speler 1
	//13: speler 2
	//14: speler 3
	//15: speler 4
	//16: doorloop afbeeldingen / volgende galerij
	//17: score aanpassen
	if (galleryNumber != null) {
		currentGallery = galleryNumber;
	} else if (currentGallery > 3) {
		currentGallery = 0;
		activePlayer = 0;
	}	
	var menuGalleryPlayerItems = new Array();
	menuGalleryPlayerItems[0] = (activePlayer == 0 ? "-" : "") + "Stop / Geen speler";
	for (var answerCounter = 0; answerCounter < 10; answerCounter++) {
		answerState = galleriesAnswersFound[currentGallery][answerCounter];
		if (answerState != false) {
			menuGalleryPlayerItems[answerCounter+1] = "(" + (answerCounter + 1) + ": " + galleries[currentGallery][1][answerCounter] + ")";
		} else {
			menuGalleryPlayerItems[answerCounter+1] = (answerCounter + 1) + ": " + galleries[currentGallery][1][answerCounter];
		}
	}
	menuGalleryPlayerItems[11] = (activePlayer == 0 ? "-" : "") + "Stop / Geen speler";
	sortedPlayerNames = getSortedPlayerNames();
	//ShowMessage("Player: "+sortedPlayerNames[0][2]+" played: " + playedGallery[sortedPlayerNames[0][2]-1]+"\nPlayer: "+sortedPlayerNames[1][2]+" played: " + playedGallery[sortedPlayerNames[1][2]-1]+"\nPlayer: "+sortedPlayerNames[2][2]+" played: " + playedGallery[sortedPlayerNames[2][2]-1]+"\nPlayer: "+sortedPlayerNames[3][2]+", played: " + playedGallery[sortedPlayerNames[3][2]-1] + "\ncurrentPlayer " + currentPuzzelPlayer + "\ncurrentPuzzel "+ currentPuzzel);
	for (var playerCounter = 0; playerCounter < 4; playerCounter++) {
		if (playedGallery[(sortedPlayerNames[playerCounter][2])-1] > 4) {
			menuGalleryPlayerItems[playerCounter+12] = (sortedPlayerNames[playerCounter][2] == activePlayer ? "-" : "") + "(" + "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s))";
		} else if (sortedPlayerNames[playerCounter][2] == currentGalleryPlayer) {
			menuGalleryPlayerItems[playerCounter+12] = (sortedPlayerNames[playerCounter][2] == activePlayer ? "-" : "") + "* " + "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		} else {
			menuGalleryPlayerItems[playerCounter+12] = (sortedPlayerNames[playerCounter][2] == activePlayer ? "-" : "") + "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		}
	}
	if (currentGallery < 3) {
		if (repeatImageGallery || repeatSameImageGallery) {
			menuGalleryPlayerItems[16] = "Doorloop afbeeldingen";
		} else {
			menuGalleryPlayerItems[16] = "Volgende galerij";
		}
	} else {	
		//last gallery
		if (repeatImageGallery || repeatSameImageGallery) {
			menuGalleryPlayerItems[16] = "Doorloop afbeeldingen";
		} else {
			menuGalleryPlayerItems[16] = "Ronde selectie";
		}
	}
	menuGalleryPlayerItems[17] = "Score aanpassen";
	var menuGalleryPlayers = CreateListScreen( "menuGalleryPlayer_");
	menuGalleryPlayers.name = "menuGalleryPlayer_";
	menuGalleryPlayers.title = "De Gallerij " + (currentGallery + 1);
	menuGalleryPlayers.selectedItem = 0;
	menuGalleryPlayers.itemLabels = menuGalleryPlayerItems;
	theTerminal.Push( menuGalleryPlayers );
}
function menuGalleryPlayer_ValueUpdated(theScreen, theProperty)
{
	if (theScreen.selectedItem == 0) {
		selectPlayer(0, "showGalleryPlayersMenu", false);
	} else if (theScreen.selectedItem > 10 && theScreen.selectedItem < 16) {	
		//player selected		
		selectedPlayer = translatePlayerSortedToActual(theScreen.selectedItem - 11);
		ShowMessage(selectedPlayer + " reel player selecter");
		if (playedGallery[selectedPlayer-1] < 5) {
			playedGallery[selectedPlayer-1] = (playedGallery[selectedPlayer-1] + 5);
		}
		currentGalleryPlayer = 0;
		selectPlayer(theScreen.selectedItem - 11, "showGalleryPlayersMenu", true);
	} else if (theScreen.selectedItem > 0 && theScreen.selectedItem < 11) {
		//answer selected
		answerState = galleriesAnswersFound[currentGallery][theScreen.selectedItem - 1];
		if (answerState == false) {
			sendText("a", false);
			galleriesAnswersFound[currentGallery][theScreen.selectedItem - 1] = activePlayer;
			if (activePlayer != 0) {
				playerNames[activePlayer][1] = playerNames[activePlayer][1] + 15;		
			}
			if (galleriesAnswersFound[currentGallery][0] && galleriesAnswersFound[currentGallery][1] && galleriesAnswersFound[currentGallery][2] && galleriesAnswersFound[currentGallery][3] && galleriesAnswersFound[currentGallery][4] && galleriesAnswersFound[currentGallery][5] && galleriesAnswersFound[currentGallery][6] && galleriesAnswersFound[currentGallery][7] && galleriesAnswersFound[currentGallery][8] && galleriesAnswersFound[currentGallery][9]) {
				currentGalleryPlayer = 0;
				selectPlayer(0,"showGalleryPlayersMenu", false);
			} else {
				selectPlayer(activePlayer,"showGalleryPlayersMenu", false);
			}
		}			
	} else if (theScreen.selectedItem == 16) {
		if (currentGallery < 3) {
			if (repeatImageGallery || repeatSameImageGallery) {
				restorePlayedGallery();
				currentGalleryPlayer = 0;
				currentGalleryImageNumber = 0;
				selectPlayer(0,"showGallerySolution", false);
			} else {
				restorePlayedGallery();
				activePlayer = 0;
				currentGalleryPlayer = 0;
				sendText("n", false);
				selectPlayer(0,"showGalleryMenu", false);
			}
		} else {
			if (repeatImageGallery || repeatSameImageGallery) {
				restorePlayedGallery();
				currentGalleryPlayer = 0;
				currentGalleryImageNumber = 0;
				selectPlayer(0,"showGallerySolution", false);
			} else {
				restorePlayedGallery();
				currentGalleryPlayer = 0;
				selectPlayer(0,"showRoundsMenu", false);
			}
		}
	} else if (theScreen.selectedItem == 17) {
		showPointCorrectionMenu();
	}
}


//PUZZEL
function showPuzzelInfo() {
	showMoveToNextScreenQuestion("Puzzel");
	if (!infoPuzzelShown) {
		infoPuzzelShown = true;
		var msgbox = CreateMessageboxDialog( "messagebox_");
		msgbox.title = "Puzzel";
		msgbox.textualContent = "\n  Puzzel\n\nIeder speler krijgt 12 woorden op het scherm, deze zijn per 4 gelinkt aan een kernwoord.\n\nVoor ieder gevonden link / kernwoord tussen de groep woorden wordt 30sec verdiend.\n\nAndere spelers mogen aanvullen,\neerst deze met het minst aantal punten.";
		theTerminal.Push(msgbox);	
	}
}
function showPuzzelMenu() {
//0: player 1
//1: player 2
//2: player 3
//3: player 4
//4: puzzel 1
//5: puzzel 2
//6: puzzel 3
//7: puzzel 4
//8: volgende puzzel
//9: vorige puzzel
	activePlayer = 0;
	restorePlayedPuzzel();
	var menuPuzzelItems = new Array();
	sortedPlayerNames = getSortedPlayerNames();
	//ShowMessage("Player: "+sortedPlayerNames[0][2]+" played: " + playedPuzzel[sortedPlayerNames[0][2]-1]+"\nPlayer: "+sortedPlayerNames[1][2]+" played: " + playedPuzzel[sortedPlayerNames[1][2]-1]+"\nPlayer: "+sortedPlayerNames[2][2]+" played: " + playedPuzzel[sortedPlayerNames[2][2]-1]+"\nPlayer: "+sortedPlayerNames[3][2]+", played: " + playedPuzzel[sortedPlayerNames[3][2]-1] + "\ncurrentPlayer " + currentPuzzelPlayer + "\ncurrentPuzzel "+ currentPuzzel);
	for (var playerCounter = 0; playerCounter < 4; playerCounter++) {
		if (sortedPlayerNames[playerCounter][2] == currentPuzzelPlayer) {
			menuPuzzelItems[playerCounter] = "* Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		} else if (playedPuzzel[(sortedPlayerNames[playerCounter][2]-1)] > 0) {
			menuPuzzelItems[playerCounter] = "(Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s))";
		} else {
			menuPuzzelItems[playerCounter] = "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		}
	}
	for (var i = 0; i < 4; i++) {
		menuPuzzelItems[i+4] = (puzzelPlayed(i+1) ? "(" : "") + "Puzzel "+(i+1)+": " + puzzels[i][0] + (puzzelPlayed(i+1) ? ")" : "");
	}
	menuPuzzelItems[8] = "Volgend puzzel scherm";
	menuPuzzelItems[9] = "Vorig puzzel scherm";
	var menuPuzzel = CreateListScreen( "menuPuzzels_");
	menuPuzzel.name = "menuPuzzels_";
	menuPuzzel.title = "Puzzel";
	menuPuzzel.selectedItem = 0;
	menuPuzzel.itemLabels = menuPuzzelItems;
	theTerminal.Push( menuPuzzel );
}
function menuPuzzels_ValueUpdated(theScreen, theProperty)
{
	if (theScreen.selectedItem == 8) {
		sendText("n", false);
	} else if (theScreen.selectedItem == 9) {
		sendText("b", false);
	} else if (theScreen.selectedItem > 3 && theScreen.selectedItem < 8) {
		currentPuzzel = theScreen.selectedItem - 4;
		showPuzzelQuestion();
	} else if (theScreen.selectedItem < 4) {
		restorePlayedPuzzel();
		selectedPlayer = translatePlayerSortedToActual(theScreen.selectedItem + 1);
		if (playedPuzzel[selectedPlayer-1] == 0) {
			currentPuzzelPlayer = selectedPlayer;
		} else {
			currentPuzzelPlayer = 0;
		}
		theTerminal.PopTo("menuRounds_");
		showPuzzelMenu();
	}
}

function restorePlayedPuzzel() {
	if (playedPuzzel[0] > 4) {
		playedPuzzel[0] = playedPuzzel[0]-5;
	}
	if (playedPuzzel[1] > 4) {
		playedPuzzel[1] = playedPuzzel[1]-5;
	}
	if (playedPuzzel[2] > 4) {
		playedPuzzel[2] = playedPuzzel[2]-5;
	}
	if (playedPuzzel[3] > 4) {
		playedPuzzel[3] = playedPuzzel[3]-5;
	}
}
function puzzelPlayed(puzzelNumber) {
	return (playedPuzzel[0] == puzzelNumber || playedPuzzel[1] == puzzelNumber || playedPuzzel[2] == puzzelNumber || playedPuzzel[3] == puzzelNumber);
}

function showPuzzelQuestion() {
	if (currentPuzzelPlayer != 0) {
		playedPuzzel[currentPuzzelPlayer-1] = currentPuzzel+1;
		showPuzzelPlayersMenu();
	}
}

function showPuzzelPlayersMenu(puzzelNumber) {
	if (puzzelNumber != null) {
		currentPuzzel = puzzelNumber;
	} else if (currentPuzzel > 3) {
		currentPuzzel = 0;
		activePlayer = 0;
	}	
	var menuPuzzelPlayerItems = new Array();
	menuPuzzelPlayerItems[0] = (activePlayer == 0 ? "-" : "") + "Stop / Geen speler";
	sortedPlayerNames = getSortedPlayerNames();
	//ShowMessage("Player: "+sortedPlayerNames[0][2]+" played: " + playedPuzzel[sortedPlayerNames[0][2]-1]+"\nPlayer: "+sortedPlayerNames[1][2]+" played: " + playedPuzzel[sortedPlayerNames[1][2]-1]+"\nPlayer: "+sortedPlayerNames[2][2]+" played: " + playedPuzzel[sortedPlayerNames[2][2]-1]+"\nPlayer: "+sortedPlayerNames[3][2]+", played: " + playedPuzzel[sortedPlayerNames[3][2]-1] + "\ncurrentPlayer " + currentPuzzelPlayer + "\ncurrentPuzzel "+ currentPuzzel);
	for (var playerCounter = 0; playerCounter < 4; playerCounter++) {
		if (playedPuzzel[(sortedPlayerNames[playerCounter][2])-1] > 4) {
			menuPuzzelPlayerItems[playerCounter+1] = (sortedPlayerNames[playerCounter][2] == activePlayer ? "-" : "") + "(" + "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s))";
		} else if (sortedPlayerNames[playerCounter][2] == currentPuzzelPlayer) {
			menuPuzzelPlayerItems[playerCounter+1] = (sortedPlayerNames[playerCounter][2] == activePlayer ? "-" : "") + "* " + "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		} else {
			menuPuzzelPlayerItems[playerCounter+1] = (sortedPlayerNames[playerCounter][2] == activePlayer ? "-" : "") + "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		}
	}
	for (var answerCounter = 0; answerCounter < 3; answerCounter++) {
		answerState = puzzelsAnswersFound[currentPuzzel][answerCounter];
		if (answerState) {
			menuPuzzelPlayerItems[5 + answerCounter] = "(" + (answerCounter + 1) + ": " + puzzels[currentPuzzel][2][answerCounter] + ")";
		} else {
			menuPuzzelPlayerItems[5 + answerCounter] = (answerCounter + 1) + ": " + puzzels[currentPuzzel][2][answerCounter];
		}
	}
	if (currentPuzzel < 3) {
		menuPuzzelPlayerItems[8] = "Volgende puzzel";	
	} else {	
		//last puzzel
		menuPuzzelPlayerItems[8] = "Ronde selectie";
	}
	menuPuzzelPlayerItems[9] = "Kies puzzel";	
	menuPuzzelPlayerItems[10] = "Score aanpassen";	
	var menuPuzzelPlayers = CreateListScreen( "menuPuzzelPlayer_");
	menuPuzzelPlayers.name = "menuPuzzelPlayer_";
	menuPuzzelPlayers.title = "Puzzel: " + puzzels[currentPuzzel][0];
	menuPuzzelPlayers.selectedItem = 0;
	menuPuzzelPlayers.itemLabels = menuPuzzelPlayerItems;
	theTerminal.Push( menuPuzzelPlayers );
}
function menuPuzzelPlayer_ValueUpdated(theScreen, theProperty)
{
	try {
		if (theScreen.selectedItem >= 0 && theScreen.selectedItem < 5) {
			//player selected
			selectedPlayer = translatePlayerSortedToActual(theScreen.selectedItem);
			if (playedPuzzel[selectedPlayer-1] < 5) {
				playedPuzzel[selectedPlayer-1] = (playedPuzzel[selectedPlayer-1] + 5);
			}
			currentPuzzelPlayer = 0;
			selectPlayer(theScreen.selectedItem, "showPuzzelPlayersMenu", true);
		} else if (theScreen.selectedItem > 4 && theScreen.selectedItem < 8) {
			//answer selected
			answerState = puzzelsAnswersFound[currentPuzzel][theScreen.selectedItem-5];
			if (!answerState) {
				sendText(puzzelSendKeys[theScreen.selectedItem-5], false);
				puzzelsAnswersFound[currentPuzzel][theScreen.selectedItem-5] = true;
				if (activePlayer != 0) {
					playerNames[activePlayer][1] = playerNames[activePlayer][1] + 30;		
				}
				if (puzzelsAnswersFound[currentPuzzel][0] && puzzelsAnswersFound[currentPuzzel][1] && puzzelsAnswersFound[currentPuzzel][2]) {
					currentPuzzelPlayer = 0;
					selectPlayer(0,"showPuzzelPlayersMenu", false);
				} else {
					selectPlayer(activePlayer,"showPuzzelPlayersMenu", false);
				}
			}			
		} else if (theScreen.selectedItem == 8) {
			if (currentPuzzel < 3) {
				restorePlayedPuzzel();
				activePlayer = 0;
				currentPuzzelPlayer = 0;
				sendText("n", false);
				theTerminal.PopTo("menuPuzzels_");
				showPuzzelPlayersMenu(currentPuzzel + 1);
			} else {
				restorePlayedPuzzel();
				activePlayer = 0;
				currentPuzzelPlayer = 0;
				theTerminal.PopTo("menuRounds_");
			}
		} else if (theScreen.selectedItem == 9) {
			currentPuzzelPlayer = 0;
			selectPlayer(0,"showPuzzelMenu", false);
		} else if (theScreen.selectedItem == 10) {
			showPointCorrectionMenu();
		}
	} catch( e ) {}
}

//OPEN DOUR
function showOpenDourInfo() {
	showMoveToNextScreenQuestion("Open Deur");
	if (!infoOpenDourShown) {
		infoOpenDourShown = true;
		var msgbox = CreateMessageboxDialog( "messagebox_");
		msgbox.title = "Open Dour";
		msgbox.textualContent = "\n  Open Deur\n\nElke speler kiest een filmpje (verliezer kiest eerst).\n\nOp het einde van het filmpje wordt een vraag gesteld met 4 antwoorden twv 20sec.\n\nIndien niet al de 4 antwoorden gevonden werden, mogen de andere spelers verder aanvullen,\nde speler met het minst aantal punten eerst.";
		theTerminal.Push(msgbox);	
	}
}
function showOpenDourMenu() {
//0: player 1
//1: player 2
//2: player 3
//3: player 4
//4: opendour 1
//5: opendour 2
//6: opendour 3
//7: opendour 4
//8: overview screen
	activePlayer = 0;
	restorePlayedOpenDour();
	var menuOpenDourItems = new Array();
	sortedPlayerNames = getSortedPlayerNames();
	//ShowMessage("Player: "+sortedPlayerNames[0][2]+" played: " + playedOpenDour[sortedPlayerNames[0][2]-1]+"\nPlayer: "+sortedPlayerNames[1][2]+" played: " + playedOpenDour[sortedPlayerNames[1][2]-1]+"\nPlayer: "+sortedPlayerNames[2][2]+" played: " + playedOpenDour[sortedPlayerNames[2][2]-1]+"\nPlayer: "+sortedPlayerNames[3][2]+", played: " + playedOpenDour[sortedPlayerNames[3][2]-1] + "\ncurrentPlayer " + currentOpenDourMoviePlayer + "\ncurrentMovie "+ currentOpenDourMovie);
	for (var playerCounter = 0; playerCounter < 4; playerCounter++) {
		if (sortedPlayerNames[playerCounter][2] == currentOpenDourMoviePlayer) {
			menuOpenDourItems[playerCounter] = "* Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		} else if (playedOpenDour[(sortedPlayerNames[playerCounter][2]-1)] > 0) {
			menuOpenDourItems[playerCounter] = "(Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s))";
		} else {
			menuOpenDourItems[playerCounter] = "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		}
	}
	for(var i = 0; i < 4; i++) {
		menuOpenDourItems[i+4] = (openDourMoviePlayed(i+1) ? "(" : "") + "Filmpje "+ (i+1) +": " + openDourMovies[i][0] + (openDourMoviePlayed(i+1) ? ")" : "");
	}
	menuOpenDourItems[8] = "Filmpjes overzicht scherm";
	var menuOpenDour = CreateListScreen( "menuOpenDours_");
	menuOpenDour.name = "menuOpenDours_";
	menuOpenDour.title = "Open Deur";
	menuOpenDour.selectedItem = 0;
	menuOpenDour.itemLabels = menuOpenDourItems;
	theTerminal.Push( menuOpenDour );
}
function menuOpenDours_ValueUpdated(theScreen, theProperty)
{
	if (theScreen.selectedItem == 8) {
		sendText("p", false);
	} else if (theScreen.selectedItem > 3 && theScreen.selectedItem < 8) {
		currentOpenDourMovie = theScreen.selectedItem - 4;
		showOpenDourQuestion();
	} else if (theScreen.selectedItem < 4) {
		restorePlayedOpenDour();
		selectedPlayer = translatePlayerSortedToActual(theScreen.selectedItem + 1);
		if (playedOpenDour[selectedPlayer-1] == 0) {
			currentOpenDourMoviePlayer = selectedPlayer;
		} else {
			currentOpenDourMoviePlayer = 0;
		}
		theTerminal.PopTo("menuRounds_");
		showOpenDourMenu();
	}
}

function restorePlayedOpenDour() {
	if (playedOpenDour[0] > 4) {
		playedOpenDour[0] = playedOpenDour[0]-5;
	}
	if (playedOpenDour[1] > 4) {
		playedOpenDour[1] = playedOpenDour[1]-5;
	}
	if (playedOpenDour[2] > 4) {
		playedOpenDour[2] = playedOpenDour[2]-5;
	}
	if (playedOpenDour[3] > 4) {
		playedOpenDour[3] = playedOpenDour[3]-5;
	}
}
function openDourMoviePlayed(movieNumber) {
	return (playedOpenDour[0] == movieNumber || playedOpenDour[1] == movieNumber || playedOpenDour[2] == movieNumber || playedOpenDour[3] == movieNumber);
}

function showOpenDourQuestion() {
	if (currentOpenDourMoviePlayer != 0) {
		sendText("" + (currentOpenDourMovie + 1), false);
		var msgbox = CreateQuestionDialog( "openDourQuestion_");
		msgbox.textualContent = "\n\n" + openDourMovies[currentOpenDourMovie][1] + "\n\nYes: antwoordenscherm, filmpje wordt gestopt\n\nNo: vorig scherm";
		theTerminal.Push(msgbox);	
	} 
}
function openDourQuestion_OK(textfield) {
	playedOpenDour[currentOpenDourMoviePlayer-1] = currentOpenDourMovie+1;
	sendText("n", false);
	showOpenDourPlayersMenu();
}
function openDourQuestion_Cancel(textfield) {
	playedOpenDour[currentOpenDourMoviePlayer-1] = 0;
	sendText("n", false);
	sendText("p", false);
	showOpenDourMenu();
}

function showOpenDourPlayersMenu(movieNumber) {
	if (movieNumber != null) {
		currentOpenDourMovie = movieNumber;
	} else if (currentOpenDourMovie > 3) {
		currentOpenDourMovie = 0;
		activePlayer = 0;
	}	
	var menuOpenDourPlayerItems = new Array();
	menuOpenDourPlayerItems[0] = (activePlayer == 0 ? "-" : "") + "Stop / Geen speler";
	sortedPlayerNames = getSortedPlayerNames();
	//ShowMessage("Player: "+sortedPlayerNames[0][2]+" played: " + playedOpenDour[sortedPlayerNames[0][2]-1]+"\nPlayer: "+sortedPlayerNames[1][2]+" played: " + playedOpenDour[sortedPlayerNames[1][2]-1]+"\nPlayer: "+sortedPlayerNames[2][2]+" played: " + playedOpenDour[sortedPlayerNames[2][2]-1]+"\nPlayer: "+sortedPlayerNames[3][2]+", played: " + playedOpenDour[sortedPlayerNames[3][2]-1] + "\ncurrentPlayer " + currentOpenDourMoviePlayer + "\ncurrentMovie "+ currentOpenDourMovie);
	for (var playerCounter = 0; playerCounter < 4; playerCounter++) {
		if (playedOpenDour[(sortedPlayerNames[playerCounter][2])-1] > 4) {
			menuOpenDourPlayerItems[playerCounter+1] = (sortedPlayerNames[playerCounter][2] == activePlayer ? "-" : "") + "(" + "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s))";
		} else if (sortedPlayerNames[playerCounter][2] == currentOpenDourMoviePlayer) {
			menuOpenDourPlayerItems[playerCounter+1] = (sortedPlayerNames[playerCounter][2] == activePlayer ? "-" : "") + "* " + "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		} else {
			menuOpenDourPlayerItems[playerCounter+1] = (sortedPlayerNames[playerCounter][2] == activePlayer ? "-" : "") + "Speler "+(sortedPlayerNames[playerCounter][2])+": " + sortedPlayerNames[playerCounter][0] + " ("+ sortedPlayerNames[playerCounter][1] + "s)";
		}
	}
	for (var answerCounter = 0; answerCounter < 4; answerCounter++) {
		answerState = openDourMoviesAnswersFound[currentOpenDourMovie][answerCounter];
		if (answerState) {
			menuOpenDourPlayerItems[5 + answerCounter] = "(" + (answerCounter + 1) + ": " + openDourMovies[currentOpenDourMovie][2][answerCounter] + ")";
		} else {
			menuOpenDourPlayerItems[5 + answerCounter] = (answerCounter + 1) + ": " + openDourMovies[currentOpenDourMovie][2][answerCounter];
		}
	}
	menuOpenDourPlayerItems[9] = "Filmpjes overzicht scherm";	
	menuOpenDourPlayerItems[10] = "Score aanpassen";	
	var menuOpenDourPlayers = CreateListScreen( "menuOpenDourPlayer_");
	menuOpenDourPlayers.name = "menuOpenDourPlayer_";
	menuOpenDourPlayers.title = "Open Deur: " + openDourMovies[currentOpenDourMovie][0];
	menuOpenDourPlayers.selectedItem = 0;
	menuOpenDourPlayers.itemLabels = menuOpenDourPlayerItems;
	theTerminal.Push( menuOpenDourPlayers );
}
function menuOpenDourPlayer_ValueUpdated(theScreen, theProperty)
{
	if (theScreen.selectedItem >= 0 && theScreen.selectedItem < 5) {
		//player selected
		selectedPlayer = translatePlayerSortedToActual(theScreen.selectedItem);
		if (playedOpenDour[selectedPlayer-1] < 5) {
			playedOpenDour[selectedPlayer-1] = (playedOpenDour[selectedPlayer-1] + 5);
		}
		currentOpenDourMoviePlayer = 0;
		selectPlayer(theScreen.selectedItem, "showOpenDourPlayersMenu", true);
	} else if (theScreen.selectedItem > 4 && theScreen.selectedItem < 9) {
		//answer selected
		answerState = openDourMoviesAnswersFound[currentOpenDourMovie][theScreen.selectedItem-5];
		if (!answerState) {
			sendText(openDourMoviesSendKeys[theScreen.selectedItem-5], false);
			openDourMoviesAnswersFound[currentOpenDourMovie][theScreen.selectedItem-5] = true;
			if (activePlayer != 0) {
				playerNames[activePlayer][1] = playerNames[activePlayer][1] + 20;		
			}
			if (openDourMoviesAnswersFound[currentOpenDourMovie][0] && openDourMoviesAnswersFound[currentOpenDourMovie][1] && openDourMoviesAnswersFound[currentOpenDourMovie][2] && openDourMoviesAnswersFound[currentOpenDourMovie][3]) {
				currentOpenDourMoviePlayer = 0;
				selectPlayer(0,"showOpenDourPlayersMenu", false);
			} else {
				selectPlayer(activePlayer,"showOpenDourPlayersMenu", false);
			}
		}			
	} else if (theScreen.selectedItem == 9) {
		currentOpenDourMoviePlayer = 0;
		sendText("p", false);
		selectPlayer(0,"showOpenDourMenu", false);
	} else if (theScreen.selectedItem == 10) {
		showPointCorrectionMenu();
	}
}


//3-6-9
function show369Info() {
	showMoveToNextScreenQuestion("3-6-9");
	if (!info369Shown) {
		info369Shown = true;
		var msgbox = CreateMessageboxDialog( "messagebox_");
		msgbox.title = "3-6-9";
		msgbox.textualContent = "\n  3-6-9\n\n9 of 15 vragen, waarbij om de 3 vragen 10 sec kan verdiend worden.\n\nZolang de speler juist antwoordt, blijft hij aan beurt.\n\nBij een fout antwoord mag de volgend speler in rij antwoorden.";
		theTerminal.Push(msgbox);	
	}
}
function show369Menu(questionNumber) {
	if (questionNumber != null) {
		current369QuestionNumber = questionNumber;
	} else if ((!short369 && current369QuestionNumber > 14) || (short369 && current369QuestionNumber > 8)) {
		current369QuestionNumber = 0;
		activePlayer = 0;
	}	
	var menu369Items = new Array();
	menu369Items[0] = (activePlayer == 0 ? "-" : "") + "Stop / Geen speler";
	//ShowMessage("played369[0]: " + played369[0] + ", current369QuestionNumber: "+ current369QuestionNumber + "\nlayed369[1]: " + played369[1] + "\nplayed369[2]: " + played369[2] + "\nplayed369[3]: " + played369[3]);
	for (var playerCounter = 1; playerCounter < 5; playerCounter++) {
		if (played369[playerCounter-1] >= (current369QuestionNumber + 1)) {
			menu369Items[playerCounter] = (playerCounter == activePlayer ? "-" : "") + "(Speler "+playerCounter+": " + playerNames[playerCounter][0] + " ("+ playerNames[playerCounter][1] + "s))";
		} else if (activePlayer == 0 && playerCounter == previousActive369Player) {
			menu369Items[playerCounter] = "* Speler "+playerCounter+": " + playerNames[playerCounter][0] + " ("+ playerNames[playerCounter][1] + "s)";
		} else {
			menu369Items[playerCounter] = (playerCounter == activePlayer ? "-" : "") + "Speler "+playerCounter+": " + playerNames[playerCounter][0] + " ("+ playerNames[playerCounter][1] + "s)";
		}
	}
	menu369Items[5] = "V" + (current369QuestionNumber+1) + ": " + questions369[current369QuestionNumber][0];
	menu369Items[6] = "A: " + questions369[current369QuestionNumber][1];
	if ((short369 && current369QuestionNumber > 7) || (!short369 && current369QuestionNumber > 13)) {
		if (activePlayer == 0) {
			menu369Items[7] = "Ronde selectie";
		} else {
			menu369Items[7] = "Juist - ronde selectie";
		}
	} else {
		if (activePlayer == 0) {
			menu369Items[7] = "Volgende vraag";
		} else {
			menu369Items[7] = "Juist - volgende vraag";
		}
	}
	menu369Items[8] = "Selecteer vraag";	
	menu369Items[9] = "Score aanpassen";	
	var menu369 = CreateListScreen( "menu369_");
	menu369.name = "menu369_";
	menu369.title = "3-6-9: " + (current369QuestionNumber + 1);
	menu369.selectedItem = 0;
	menu369.itemLabels = menu369Items;
	theTerminal.Push( menu369 );
}
function menu369_ValueUpdated(theScreen, theProperty)
{
	if (theScreen.selectedItem >= 0 && theScreen.selectedItem < 5) {
		if (played369[theScreen.selectedItem-1] < 15) {
			played369[theScreen.selectedItem-1] = 15 + current369QuestionNumber + 1;
		}
		if (theScreen.selectedItem == 0) {
			previousActive369Player = (activePlayer + 1) % 4;
		} else {
			prevousActive369Player = 0;
		}
		selectPlayer(theScreen.selectedItem,"show369Menu", false);
	} else if (theScreen.selectedItem == 5) {
		show369Question(current369QuestionNumber);
	} else if (theScreen.selectedItem == 6) {
		show369Answer(current369QuestionNumber);
	} else if (theScreen.selectedItem == 7) {
		restorePlayed369();
		if ((short369 && current369QuestionNumber > 8) || (!short369 && current369QuestionNumber > 14)) {
			current369QuestionNumber = 0;
			activePlayer = 0;
			theTerminal.PopTo("menuRounds_");
		} else {
			next369Question(current369QuestionNumber);
		}
	} else if (theScreen.selectedItem == 8) {
		select369Question();
	} else if (theScreen.selectedItem == 9) {
		showPointCorrectionMenu();
	}
}
function restorePlayed369() {
	if (played369[0] > 14) {
		played369[0] = played369[0]-15;
	}
	if (played369[1] > 14) {
		played369[1] = played369[1]-15;
	}
	if (played369[2] > 14) {
		played369[2] = played369[2]-15;
	}
	if (played369[3] > 14) {
		played369[3] = played369[3]-15;
	}
}

function select369Question() {
	restorePlayed369();
	var lastExecuted369Question = Math.max(played369[0],played369[1],played369[2],played369[3]);
	var menu369QuestionsItems = new Array();
	for ( var counter369 = 0; counter369 < 15 ; counter369++) {
		if (counter369 > lastExecuted369Question -1 ) {
			menu369QuestionsItems[counter369] = (counter369 + 1) + ":" + questions369[counter369][0];
		} else {
			menu369QuestionsItems[counter369] = "(" + (counter369 + 1) + ":" + questions369[counter369][0] + ")";
		}
	} 
	var menu369Questions = CreateListScreen( "menu369Questions_");
	menu369Questions.name = "menu369Questions_";
	menu369Questions.title = "3-6-9 Vragen";
	menu369Questions.selectedItem = 0;
	menu369Questions.itemLabels = menu369QuestionsItems;
	theTerminal.Push( menu369Questions );
}

function menu369Questions_ValueUpdated(theScreen, theProperty)
{
	try {
		theTerminal.PopTo("menuRounds_");
		show369Menu(theScreen.selectedItem);
	} catch( e ) {}
}

function show369Question(questionNumber) {
	var msgbox = CreateMessageboxDialog( "messagebox_");
	msgbox.title = "V" + questionNumber+1;
	msgbox.textualContent = "\n"+(activePlayer != 0 ? playerNames[activePlayer][0] + ",\n" : "") + questions369[questionNumber][0];
	theTerminal.Push(msgbox);	
}
function show369Answer(questionNumber) {
	var msgbox = CreateMessageboxDialog( "messagebox_");
	msgbox.title = "A" + questionNumber+1;
	msgbox.textualContent = "\nCorrect antwoord:\n\n"+questions369[questionNumber][1];
	theTerminal.Push(msgbox);	
}
function next369Question(questionNumber) {
	for (var i = 0; i <= questionNumber; i++) {
		sendText(questions369SendKeys[i], false);
	}
	if (activePlayer != 0 && ((questionNumber+1) % 3) == 0) {
		playerNames[activePlayer][1] = playerNames[activePlayer][1] + 10;
	}
	if (activePlayer != 0) {
		played369[activePlayer-1] = questionNumber + 2;
	}
	theTerminal.PopTo("menuRounds_");
	if ((!short369 && questionNumber < 15) || (short369 && questionNumber < 9)) {
		show369Menu(++questionNumber);
	}
}


//PLAYERS - GENERAL CONFIG
function getPlayerNamesMenu() {
	var playerNamesMenuItems = new Array();
	for (var playerCounter = 1;playerCounter < 5; playerCounter++) {
		if (playerNames[playerCounter][0] != "Speler "+ playerCounter) {
			playerNamesMenuItems[playerCounter-1] = "Speler "+playerCounter+": " + playerNames[playerCounter][0];
		} else {
			playerNamesMenuItems[playerCounter-1] = "Speler "+playerCounter;
		}
	}
	playerNamesMenuItems[4] = "Fotogalerij: " + (repeatSameImageGallery ? "zelfde herhalen" : (repeatImageGallery ? "herhalen" : "niet herhalen"));
	playerNamesMenuItems[5] = "3-6-9: " + (short369 ? "9 vragen" : "15 vragen");
	playerNamesMenuItems[6] = "Toon ronde info: " + (enableRoundInfoPanel ? "Aan" : "Uit");
	playerNamesMenuItems[7] = "Vul speler namen in op scherm";
	var playersMenu = CreateListScreen( "playersMenu_");
	playersMenu.name = "playersMenu_";
	playersMenu.title = "Spelers";
	playersMenu.selectedItem = 0;
	playersMenu.itemLabels = playerNamesMenuItems;
	theTerminal.Push( playersMenu );
}

function playersMenu_ValueUpdated(theScreen, theProperty)
{
	try {
			if (theScreen.selectedItem == 0) {
				getName(1);
			} else if (theScreen.selectedItem == 1) {
				getName(2);
			} else if (theScreen.selectedItem == 2) {
				getName(3);
			} else if (theScreen.selectedItem == 3) {
				getName(4);
			} else if (theScreen.selectedItem == 4) {
				requestRepeatImageGallery();
			} else if (theScreen.selectedItem == 5) {
				requestShort369();
			} else if (theScreen.selectedItem == 6) {
				enableRoundInfoPanel = !enableRoundInfoPanel;
				theTerminal.PopTo("dsmMenu_");
				getPlayerNamesMenu();
			} else if (theScreen.selectedItem == 7) {
				fillScreenNames();
			}
		} catch( e ) {}
}

function fillScreenNames() {
	activateBrowser();
	var widget = CreateQuestionDialog( "player1ActiveConfirmation_");
	widget.textualContent = "Is het veld van Speler 1 actief op het scherm?";
	theTerminal.Push(widget);
}
function player1ActiveConfirmation_OK(w) {
	fillScreenNamesFinal();
}
function player1ActiveConfirmation_Cancel(w) {
		showKeypad();
		showHistory("-selecteer het veld van 'Speler 1'\n-klik op 'Back'-toets", true);
}


function requestRepeatImageGallery() {
	var requestRepeatImageGalleryItems = new Array();
	requestRepeatImageGalleryItems[0] = "Galerij herhalen";
	requestRepeatImageGalleryItems[1] = "Galerij herhalen met zelfde foto's";
	requestRepeatImageGalleryItems[2] = "Galerij niet herhalen";
	var widget = CreateOptionListDialog( "requestRepeatImageGallery_");
	widget.name = "requestRepeatImageGallery_";
	widget.title = "Foto gallerij herhalen?";
  widget.value = (repeatSameImageGallery ? 1 : (repeatImageGallery ? 0 : 2));
	widget.itemLabels = requestRepeatImageGalleryItems;
	theTerminal.Push(widget);
}
function requestRepeatImageGallery_OK(widget) {
	if (widget.value == 0) {
		repeatImageGallery = true;
		repeatSameImageGallery = false;
	} else if (widget.value == 1) {
		repeatImageGallery = true;
		repeatSameImageGallery = true;
	} else {
		repeatImageGallery = false;
		repeatSameImageGallery = false;
	}
	theTerminal.PopTo("dsmMenu_");
	getPlayerNamesMenu();
}

function requestShort369() {
	var widget = CreateQuestionDialog( "short369_");
	widget.textualContent = "Korte 3-6-9 ronde?";
	theTerminal.Push(widget);
}

function short369_OK(w) {
	short369 = true;
	theTerminal.PopTo("dsmMenu_");
	getPlayerNamesMenu();
}
function short369_Cancel(w) {
	short369 = false;
	theTerminal.PopTo("dsmMenu_");
	getPlayerNamesMenu();
}

function fillScreenNamesFinal() {	
	ShowMessage("Speler namen worden ingevuld");
	SendVirtualKeystroke(0x24, false, false, false, false); //Home
	SendVirtualKeystroke(0x23, true, false, false, false); //Shift + end
	for (var playerCounter = 1; playerCounter < 5; playerCounter++) {
		sendText(playerNames[playerCounter][0], false);
		SendVirtualKeystroke(0x09, false, false, false, false); //Tab
	}
	if (repeatImageGallery) {
		SendVirtualKeystroke(0x20, false, false, false, false); //Space
	}
	SendVirtualKeystroke(0x09, false, false, false, false); //Tab
	if (repeatSameImageGallery) {
		SendVirtualKeystroke(0x20, false, false, false, false); //Space
	}
	SendVirtualKeystroke(0x09, false, false, false, false); //Tab
	if (short369) {
		SendVirtualKeystroke(0x20, false, false, false, false); //Space
	}
	SendVirtualKeystroke(0x09, false, false, false, false); //Tab
	SendVirtualKeystroke(0x20, false, false, false, false); //Space
	theTerminal.PopTo("dsmMenu_");
}

var playerNumberRequest = 0;
function getName(playerNumber) {
		var nameField = CreateTextFieldDialog( "getName_");		
		nameField.name = "getName_";
		nameField.maxLength = 20;
		nameField.prompt = "Geef de naam voor speler " + playerNumber;
		nameField.value = playerNames[playerNumber][0];  
		playerNumberRequest = playerNumber;
		theTerminal.Push(nameField); 
}

function getName_OK(textfield) {
	playerNames[playerNumberRequest][0] = textfield.value;
	theTerminal.PopTo("dsmMenu_");
	getPlayerNamesMenu();
}

//SPECIAL KEYS MENU
function showMenu()
{
	var optionsMenu = CreateListScreen( "optionsMenu_");
	optionsMenu.name = "optionsMenu_";
	optionsMenu.title = "Opties";
	optionsMenu.selectedItem = 0;
	optionsMenu.itemLabels = optionsMenuItems;
	theTerminal.Push( optionsMenu );
}

function optionsMenu_ValueUpdated(theScreen, theProperty)
{
/*
optionsMenuItems[0] = "Send long text (write on device)";
optionsMenuItems[1] = "Activate Shift key";
optionsMenuItems[2] = "Activate Ctrl key";
optionsMenuItems[3] = "Activate Alt key";
optionsMenuItems[4] = "Activate Win key";
optionsMenuItems[5] = "Send Function keys";
optionsMenuItems[6] = "Send Media keys";
optionsMenuItems[7] = "Send Combination keys";
optionsMenuItems[8] = "Send Special characters";
optionsMenuItems[9] = "Enable Scroll mode";
optionsMenuItems[10] = "Clear device home screen";
//optionsMenuItems[11] = "Send Ctrl + Alt + Delete";
*/
	try {
			if (theScreen.selectedItem == 0) {
				showLongText();
			} else if (theScreen.selectedItem == 1) {
				switchShift();
			} else if (theScreen.selectedItem == 2) {
				switchCtrl();
			} else if (theScreen.selectedItem == 3) {
				switchAlt();
			} else if (theScreen.selectedItem == 4) {
				switchWin();
			} else if (theScreen.selectedItem == 5) {
				showFkeysMenu();
			} else if (theScreen.selectedItem == 6) {
				showMediaKeysMenu();
			} else if (theScreen.selectedItem == 7) {
				showCombinationMenu();
			} else if (theScreen.selectedItem == 8) {
				showSpecialKeysMenu();
			} else if (theScreen.selectedItem == 9) {
				switchScrollMode();
			} else if (theScreen.selectedItem == 10) {
				clearDeviceHomeScreen();
			} else if (theScreen.selectedItem == 11) {
				sendCtrlAltDel();
			} 
		} catch( e ) {}
}

function switchScrollMode() {
	if (scrollModeActive) {
		ShowMessage("Scroll disabled");
		dsmMenuItems[0] = "Enable Scroll mode";
		optionsMenuItems[9] = "Enable Scroll mode";
	} else {
		ShowMessage("Scroll mode enabled");
		dsmMenuItems[0] = "Disable Scroll mode";
		optionsMenuItems[9] = "Disable Scroll mode";
	}
	scrollModeActive = !scrollModeActive;
	theTerminal.PopTo("myKeypad_");
}

function showScrollMenu()
{
/*	
scrollMenuItems[0] = "Scroll Up";
scrollMenuItems[1] = "Scroll Down";
scrollMenuItems[2] = "";
scrollMenuItems[3] = "Mouse Up (quick)";
scrollMenuItems[4] = "Mouse Up";
scrollMenuItems[5] = "Mouse Down (quick)";
scrollMenuItems[6] = "Mouse Down";
scrollMenuItems[7] = "Mouse Left (quick)";
scrollMenuItems[8] = "Mouse Left";
scrollMenuItems[9] = "Mouse Right (quick)";
scrollMenuItems[10] = "Mouse Right";
*/
	var scrollMenu = CreateListScreen( "scrollMenu_");
	scrollMenu.name = "scrollMenu_";
	scrollMenu.title = "Scroll";
	scrollMenu.selectedItem = 0;
	scrollMenu.itemLabels = scrollMenuItems;
	theTerminal.Push( scrollMenu );
}
function scrollMenu_ValueUpdated(theScreen, theProperty)
{
	try {
		if(shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
  		ShowMessage((shiftKeyActive ? " Shift " : "") + (controlKeyActive ? " Ctrl " : "") + (altKeyActive ? " Alt " : "") + (winKeyActive ? " Win " : "") + "\n" + scrollMenuItems[theScreen.selectedItem]);
  	} else {
			ShowMessage(scrollMenuItems[theScreen.selectedItem]);
		}
		showHistory("<" + scrollMenuItems[theScreen.selectedItem] + ">", false);
		if (theScreen.selectedItem == 0) {
			SendMouseEvent(0, 0, 2, 0, 0);
		} else if (theScreen.selectedItem == 1) {
			SendMouseEvent(0, 0, -2, 0, 0);
		} else if (theScreen.selectedItem == 2) {
		} else if (theScreen.selectedItem == 3) {
			SendMouseEvent(0, -11, 0, 0, 0);
		} else if (theScreen.selectedItem == 4) {
			SendMouseEvent(0, -3, 0, 0, 0);
		} else if (theScreen.selectedItem == 5) {
			SendMouseEvent(0, 11, 0, 0, 0);
		} else if (theScreen.selectedItem == 6) {
			SendMouseEvent(0, 3, 0, 0, 0);
		} else if (theScreen.selectedItem == 7) {
			SendMouseEvent(-11, 0, 0, 0, 0);
		} else if (theScreen.selectedItem == 8) {
			SendMouseEvent(-3, 0, 0, 0, 0);
		} else if (theScreen.selectedItem == 9) {
			SendMouseEvent(11, 0, 0, 0, 0);
		} else if (theScreen.selectedItem == 10) {
			SendMouseEvent(3, 0, 0, 0, 0);
		}
		//theTerminal.PopTo("optionsMenu_");
	} catch( e ) {}
}



function showMediaKeysMenu()
{
	var mediakeysMenu = CreateListScreen( "mediakeysMenu_");
	mediakeysMenu.name = "mediakeysMenu_";
	mediakeysMenu.title = "Media keys";
	mediakeysMenu.selectedItem = 0;
	mediakeysMenu.itemLabels = mediakeysMenuItems;
	theTerminal.Push( mediakeysMenu );
}
function mediakeysMenu_ValueUpdated(theScreen, theProperty)
{
	try {
		if(shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
  		ShowMessage((shiftKeyActive ? " Shift " : "") + (controlKeyActive ? " Ctrl " : "") + (altKeyActive ? " Alt " : "") + (winKeyActive ? " Win " : "") + "\n" + mediakeys[theScreen.selectedItem][0]);
  	} else {
			ShowMessage(mediakeys[theScreen.selectedItem][0]);
		}
		showHistory("<" + mediakeys[theScreen.selectedItem][0] + ">", false);
		SendVirtualKeystroke(mediakeys[theScreen.selectedItem][1], shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive);
		//theTerminal.PopTo("optionsMenu_");
	} catch( e ) {}
}

function showFkeysMenu()
{
	var fkeysMenu = CreateListScreen( "fkeysMenu_");
	fkeysMenu.name = "fkeysMenu_";
	fkeysMenu.title = "Function keys";
	fkeysMenu.selectedItem = 0;
	fkeysMenu.itemLabels = fkeysMenuItems;
	theTerminal.Push( fkeysMenu );
}
function fkeysMenu_ValueUpdated(theScreen, theProperty)
{
	try {
		if(shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
  		ShowMessage((shiftKeyActive ? " Shift " : "") + (controlKeyActive ? " Ctrl " : "") + (altKeyActive ? " Alt " : "") + (winKeyActive ? " Win " : "") + "\n" + functionkeys[theScreen.selectedItem][0]);
  	} else {
			ShowMessage(functionkeys[theScreen.selectedItem][0]);
		}
		SendVirtualKeystroke(functionkeys[theScreen.selectedItem][1], shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive);
		//theTerminal.PopTo("optionsMenu_");
		showHistory("<" + functionkeys[theScreen.selectedItem][0] + ">", false);
	} catch( e ) {}
}

function showSpecialKeysMenu()
{
	var spkeysMenu = CreateListScreen( "spkeysMenu_");
	spkeysMenu.name = "spkeysMenu_";
	spkeysMenu.title = "Special characters";
	spkeysMenu.selectedItem = 0;
	spkeysMenu.itemLabels = specialcharkeysMenuItems;
	theTerminal.Push( spkeysMenu );
}

function spkeysMenu_ValueUpdated(theScreen, theProperty)
{
	try {
		sendText(specialcharkeysMenuItems[ theScreen.selectedItem],true);
	} catch( e ) {}
}

function showCombinationMenu() {
	var combinationMenu = CreateListScreen( "combinationMenu_");
	combinationMenu.name = "combinationMenu_";
	combinationMenu.title = "Combinations";
	combinationMenu.selectedItem = 0;
	combinationMenu.itemLabels = combinationMenuItems;
	theTerminal.Push( combinationMenu );
}

var previousKey1 = "";
var previousVK1 = "";
var previousKey2 = "";
var previousVK2 = "";
function combinationMenu_ValueUpdated(theScreen, theProperty)
{
	Selection5 = theScreen.selectedItem;
	if(Selection5 == 0)
	{
		ClearKeyboardState();
		previousKey1 = "";
		previousKey2 = "";
		previousVK1 = "";
		previousVK2 = "";
	}
	else
	{
		TotalName = combinations[Selection5];
		endKey1 = TotalName.indexOf("+");
		endKey2 = TotalName.indexOf("[");
		key1 = new Array( TotalName.slice(0, endKey1 - 1), TotalName.slice(endKey2 + 1, endKey2 + 2));
		key2 = new Array( TotalName.slice(endKey1 + 2, endKey2 - 1), TotalName.slice(endKey2 + 3, endKey2 + 4));
		if ((key1[0] != previousKey1 || (key1[0] == previousKey1 && key1[1] != 2)) && previousKey1 != "")
		{
			SendVirtualKeyUp(previousVK1);
		}
		if ((key2[0] != previousKey2 || (key2[0] == previousKey2 && key2[1] != 2)) && previousKey2 != "")
		{
			SendVirtualKeyUp(previousVK2);
		}
		for(c1 = 32 ; c1 < keys.length ; c1 ++)
		{
			//ShowMessage(key1[0] + " " + keys[c1][0]);
			if(key1[0] == keys[c1][0])
			{
				if(key1[1] == "0")
				{
					SendVirtualKeyStroke(keys[c1][1], false, false, false, false);
				}
				else
				{
					SendVirtualKeyDown(keys[c1][1]);
				}
				break;
			}
		}
		for(c2 = 32 ; c2 < keys.length ; c2 ++)
		{
			if(key2[0] == keys[c2][0])
			{
				if(key2[1] == "0")
				{
					SendVirtualKeyStroke(keys[c2][1], false, false, false, false);
				}
				else
				{
					SendVirtualKeyDown(keyCodesVirtual[c2][1]);
				}
				break;
			}
		}
		if(key1[1] != "2")
		{
			SendVirtualKeyUp(keys[c1][1]);
			previousKey1 = "";
			previousVK1 = "";
		}
		else
		{
			previousKey1 = key1[0];
			previousVK1 = keys[c1][1];
		}
		if(key2[1] != "2")
		{
			SendVirtualKeyUp(keys[c2][1]);
			previousKey2 = "";
			previousVK2 = "";
		}
		else
		{
			previouskey2 = key2[0];
			previousVK2 = keys[c2][1];
		}
	}
}

function showLongText() {
		var textField = CreateTextFieldDialog( "showLongText_");
		
		textField.name = "showLongText_";
		textField.maxLength = 500;
		textField.prompt = "Text to type:";
		textField.value = "";  
		
		theTerminal.Push(textField); 
}

function showLongText_OK(textfield) {
	sendText(textfield.value);
}

function showLongText_Cancel(textfield) {
}

function sendText(textToSend, showHistoryOnScreen) {
	//ShowMessage(textToSend);
	for (var x = 0; x < textToSend.length; x++)
	{
		if (showHistoryOnScreen == null || showHistoryOnScreen) {
			showHistory(textToSend.charAt(x), true);
		}
		for (var y =32; y < keys.length; y++)
		{
			//ShowMessage(keys[y][0]);
			if (textToSend.charAt(x) == (keys[y][0])) {
				if (shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
					if (keys[y][1] == "") {
						SendUnicodeKeystroke(y);
					} else {
						SendVirtualKeystroke(keys[y][1], shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive);
					}
				} else {
					SendUnicodeKeystroke(y);
				}
				break;
			}
		}
	}
}


function sendCtrlAltDel() {
		//  SendvirtualKeystroke (Code, Shift, Ctrl, Alt, Win)
		ShowMessage("Ctrl + Alt + Delete");
		showHistory("<Ctrl + Alt + Delete>", false);
		//SendVirtualKeystroke(0x2e, false, true, true, false);
		SendVirtualKeyDown(0x11); //ctrl
		SendVirtualKeyDown(0x12); //alt
		//SendVirtualKeyDown(0x2e); //del
		//SendVirtualKeyUp(0x2e); //del
		SendVirtualKeystroke(0x2e, false, false, false, false); //del
		SendVirtualKeyUp(0x11); //ctrl
		SendVirtualKeyUp(0x12); //alt
		ClearKeyboardState();
}

function switchShift() {
	if (shiftKeyActive) {
		ShowMessage("Shift key deactivated");
		optionsMenuItems[1] = "Activate Shift key";
	} else {
		ShowMessage("Shift key activated");
		optionsMenuItems[1] = "Deactivate Shift key";
	}
	shiftKeyActive = !shiftKeyActive;
	theTerminal.PopTo("myKeypad_");
}

function switchCtrl() {
	if (controlKeyActive) {
		ShowMessage("Ctrl key deactivated");
		optionsMenuItems[2] = "Activate Ctrl key";
	} else {
		ShowMessage("Ctrl key activated");
		optionsMenuItems[2] = "Deactivate Ctrl key";
	}
	controlKeyActive = !controlKeyActive;
	theTerminal.PopTo("myKeypad_");
}

function switchAlt() {
	if (altKeyActive) {
		ShowMessage("Alt key deactivated");
		optionsMenuItems[3] = "Activate Alt key";
	} else {
		ShowMessage("Alt key activated");
		optionsMenuItems[3] = "Deactivate Alt key";
	}
	altKeyActive = !altKeyActive;
	theTerminal.PopTo("myKeypad_");
}

function switchWin() {
	if (winKeyActive) {
		ShowMessage("Win key deactivated");
		optionsMenuItems[4] = "Activate Win key";
	} else {
		ShowMessage("Win key activated");
		optionsMenuItems[4] = "Deactivate Win key";
	}
	winKeyActive = !winKeyActive;
	theTerminal.PopTo("myKeypad_");
}

function showHelp()
{
    var code = new Array();
    var title = new Array();
    var description = new Array();
    
    code[0] = new Array("s");
    title[0] = "LeftClick";
    description[0] = "MouseLeftClick. Hold to lock left button.";

    theTerminal.ShowKeypadHelp("Help", code, title, description);    

}