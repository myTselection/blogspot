var helper = new ActiveXObject("SCHelper.SECHelper");
var shouldReactivate = false;

function CallStatusChanged( theTerminal, theCallStatus, thePhoneNumber, theCallType, theCID )
{
	// Idle
	if( theCallStatus == 1 ) 
	{
		if( shouldReactivate == true )
		{
			if( helper.IsProcessRunning("MediaPortal.exe") ) 
			{
				SendKeystroke( 0x3D, false );
				SendVirtualKeystroke( 0x20, false, false, false, false );
			}
		}
	} 
	else if( theCallStatus == 2 || theCallStatus == 7 ) 
	{
		// Calling or Alerting
		var message = theTerminal.bluetoothName + "\r";
		if( thePhoneNumber != null && thePhoneNumber != "" ) 
		{
			message += "Incoming call from " + thePhoneNumber;
		} 
		else 
		{
			message += "Incoming call";
		}
		ShowMessage( message );
		
		shouldReactivate = false;
		if( helper.IsProcessRunning("MediaPortal.exe") ) 
		{
			shouldReactivate = true;
			SendVirtualKeystroke( 0x4D, false, false, false, false );
			SendVirtualKeystroke( 0x20, false, false, false, false );
		}
	}	    
}
