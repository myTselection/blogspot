// This script was originally created by graphiz. It has been edited a little bit to
// add more functions and easier use.


// Since Media Portal for some reason have been changing the registration key for the
// the install-path for every version, I have removed the auto-find-path which doesn't work
// if Team Media Portal edits the registration key on future versions, so now, the user(you)
// must type in the install-path yourself. That is all needed.
var keyRepeated = false;
var MediaPortalPath = null;

try
{
    var mph = new ActiveXObject('WScript.Shell');
// edit this line.
    MediaPortalPath = "C:/Programfiler/Team MediaPortal/MediaPortal/MediaPortal.exe";
}
catch( e )
{
    Log( "error = " + e.description );
}

// I removed a few functions, since I have added them to the keypad instead, and the DVD menu
// can be more easaly accessed by just pressing # on the cellphone, which brings up the
// context menu, and from there you can get to the dvd-menu. If you want to re-add the
// features, just remove the '//' in fromt of the 'moreMenuItem' which represents the
// feature. 

// Create more menu items listing
var moreMenuItems = new Array();
moreMenuItems[0] = "Next Page";
moreMenuItems[1] = "Previous Page";
moreMenuItems[2] = "Full Screen";                    // Movie Function
moreMenuItems[3] = "TV/PC";
moreMenuItems[4] = "Show Hide OSD";                    // Movie Function                        // General Function
moreMenuItems[5] = "Mute";                                    // General Function       // DVD Function
moreMenuItems[6] = "Switch Playlist-GUI";    // Photo Function
moreMenuItems[7] = "Delete selected image";        // Photo Function
moreMenuItems[8] = "Picture-Details";                // Photo Function
moreMenuItems[9] = "Quit";
moreMenuItems[10] = "Record this program"    // TV Function
//moreMenuItems[11] = "Play Pause";                            // Movie Function
//moreMenuItems[12] = "Stop Playing";
//moreMenuItems[13] = "Context Menu";                        // Movie Function
//moreMenuItems[14] = "Volume Up";                            // General Function
//moreMenuItems[15] = "Volume Down";
//moreMenuItems[16] = "DVD Menu";                            // DVD Function
//moreMenuItems[17] = "DVD - Next Chapter";                // DVD Function
//moreMenuItems[18] = "DVD - Previous Chapter";

// Check to see if the MediaPortal is already launched
var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("MediaPortal.exe")) 
{
	launchWidget();
}
else
{
	var widget = CreateQuestionDialog( "launcher_" );
    widget.textualContent = "Launch MediaPortal?";
    theTerminal.Push( widget );
	exit();
}

// Launcher function to Launch MediaPortal
function launcher_OK(w)
{
    new ActiveXObject("Shell.Application").ShellExecute( MediaPortalPath, "" );
	launchWidget();
}

// Create initial widget with Key controls
function launchWidget()
{
    var widget = CreateKeypadScreen( "mykeypad_" );
    widget.title = "MediaPortal";
    widget.CreateRow( "1:Play/Pause                6:Next", scLeft, scWrap, scMedium );
    widget.CreateRow( "2:Fullscreen              7:Rewind", scLeft, scWrap, scMedium );
    widget.CreateRow( "3:Stop        8:Mp Volume Down", scLeft, scWrap, scMedium );
    widget.CreateRow( "4:Previous       9:Fast Forward", scLeft, scWrap, scMedium );
    widget.CreateRow( "5:MP Volume Up        0:switch Audio", scLeft, scWrap, scMedium );
    widget.CreateRow( "*:Parent Folder#: Context Menu", scLeft, scWrap, scSmall );
    theTerminal.Push( widget );    
}

// Hard Button Mapping
function mykeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "WindowsForms10.Window.8.app.0.3ce0bb8", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
        case "s":
            SendVirtualKeystroke( 0x0D, false, false, false, false )    // VK_MEDIA_PLAY_PAUSE
        break;
        case "0":
// If 0 is pressed on the phone, Simulate 'A' for switching between audio channels when there
// are multiple audio channels. This requires the Haali Media Splitter or other programs that
// let you switch between audio channels by a key-combination. 
        SendVirtualKeystroke( 0x41, false, false, false, false );                                                               // Call the HELP function
        break;
        case "1":
// Simulate Space Bar for Play Pause Function
        SendVirtualKeystroke( 0x20, false, false, false, false );
        break;
        case "2":
// Sumulate uppercase-O for making a movie go fullscreen. This is very useful some times.
//This requires the My Keys-plugin which can be found at http://www.team-mediaportal.com/
        SendVirtualKeystroke( 0x4F, true, false, false, false );

        break;
        case "3":
// Simulate "B" for Stop Function
        SendVirtualKeystroke( 0x42, false, false, false, false );
		launchWidget();
        break;
        case "4":
// Previous Chapter - F8
        SendVirtualKeystroke( 0x77, false, false, false, false );
        break;
        case "5":
// Simulate = for adjusting the vilume upwards within Media Portal
        SendKeystroke( 0x3D, false)
        break;
        case "6":
// Next Chapter - F7
        SendVirtualKeystroke( 0x76, false, false, false, false );
        break;
        case "7":
// F5 for Rewind
        // F9
        SendVirtualKeystroke( 0x74, false, false, false, false );
        break;
        case "8":

// - for lowering the volume withing Media Portal
        SendVirtualKeystroke( 0x6D, false, false, false, false );
        break;
        case "9":
// F6 for Fast Forward
        SendVirtualKeystroke( 0x75, false, false, false, false );
        break;

// The next is just arrow keys.
        case ">":
            SendVirtualKeystroke( 0x27, false, false, false, false )    // VK_RIGHT   
        break;
        case "<":
            SendVirtualKeystroke( 0x25, false, false, false, false )    // VK_LEFT
        break;
        case "^":
            SendVirtualKeystroke( 0x26, false, false, false, false )    // VK_UP
        break;
        case "v":
            SendVirtualKeystroke( 0x28, false, false, false, false )    // VK_DOWN
        break;
        case "f":
           showMenu()                                                            // Call the MENU function
        break;
// This is the 'C' key on your phone. It may not work on all phones, but if you have
//any spare keys on your phone that you are not using, but you are not sure what code the key
//has, try just pressing it, and a message on your computer should show you the code. Then,
//just type in the code here, instead of '-8'
        case "-8":
//Escape - gets you back a level.
            SendVirtualKeystroke( 0x1B, false, false, false, false)        // VK_ESCAPE

        break;
        case "#":
// F9 for the context menu.
        // F9
        SendVirtualKeystroke( 0x78, false, false, false, false );
        break;
// This is the Volume Up key on your phone. It may not work on all phones, but if you have
//any spare keys on your phone that you are not using, but you are not sure what code the key
//has, try just pressing it, and a message on your computer should show you the code. Then,
//just type in the code here, instead of '-36'
        case "-36":

			setSysVolume(2500);
        break;
// This is the Volume Down key on your phone. It may not work on all phones, but if you have
//any spare keys on your phone that you are not using, but you are not sure what code the key
//has, try just pressing it, and a message on your computer should show you the code. Then,
//just type in the code here, instead of '-37'
        case "-37":

			setSysVolume(-2500);
        break;
        case "*":
            SendVirtualKeystroke( 0x55, false, false, false, false ) 
        break;
        default :
            ShowMessage( theKey );                                         // DISPLAYS THE KEY PRESSED ON SCREEN
    }
   // Keep the keypad active
   keyRepeated = false;
   return true;
}

// Use Back for continuous press of "More" Button
function mykeypad_KeyRepeat( theScreen, theKey )
{ 	
	if( theKey == "f" && !keyRepeated )
    {
		SendVirtualKeystroke( 0x1B, false, false, false, false)        // VK_ESCAPE
	}
	else if ( theKey == "v" && !keyRepeated )
	{
		SendVirtualKeystroke( 0x28, false, false, false, false )    // VK_DOWN
	}
	else if ( theKey == "^" && !keyRepeated )
	{
		SendVirtualKeystroke( 0x26, false, false, false, false )    // VK_DOWN
	}
   keyRepeated = true;
}

// Display more menu on Phone screen
function showMenu()
{
    var moreMenu = CreateListScreen( "moreMenu_");
    moreMenu.name = "More menu list";
    moreMenu.title = "More";
    moreMenu.selectedItem = 0;
    moreMenu.itemLabels = moreMenuItems;
    theTerminal.Push( moreMenu );
}

// Function to perform on hit of More Menu item
function moreMenu_ValueUpdated(theScreen, theProperty)
{
    var option = moreMenuItems[ theScreen.selectedItem];

    if( option == "Full Screen" )
    {
        // Simulate "X" key for Toggle Fullscreen Window
	SendVirtualKeystroke( 0x0D, false, false, true, false );
		launchWidget();
    }
    else if( option == "Next Page" )
    {
        // Simulate Space Bar for Play Pause Function
        SendVirtualKeystroke( 0x22, false, false, false, false );
    }
    else if( option == "Previous Page" )
    {
        // Simulate Space Bar for Play Pause Function
        SendVirtualKeystroke( 0x21, false, false, false, false );
    }
    else if( option == "Play Pause" )
    {
        // Simulate Space Bar for Play Pause Function
        SendVirtualKeystroke( 0x20, false, false, false, false );
    }

    else if( option == "TV/PC" )
    {
        // Simulate Space Bar for Play Pause Function
	SendVirtualKeystroke( 0x55, false, false, true, false );
    }
    else if( option == "Stop Playing" )
    {
        // Simulate "B" for Stop Function
        SendVirtualKeystroke( 0x42, false, false, false, false );
		launchWidget();
    }
    else if( option == "Show Hide OSD" )
    {
        // Space Bar
        SendVirtualKeystroke( 0x59, false, false, false, false );
    }
    else if( option == "Context Menu" )
    {
        // F9
        SendVirtualKeystroke( 0x78, false, false, false, false );
    }
    else if( option == "Volume Up" )
    {
        // =
        //SendVirtualKeystroke( 0xAF, false, false, false, false );
        SendKeystroke( 0x3D, false );
    }
    else if( option == "Volume Down" )
    {
        // -
        SendVirtualKeystroke( 0x6D, false, false, false, false );
    }
    else if( option == "Mute" )
    {
        // M
        SendVirtualKeystroke( 0x4D, false, false, false, false );
    }
    else if( option == "DVD Menu" )
    {
        // Show DVD Menu - D
        SendVirtualKeystroke( 0x44, false, false, false, false );
    }
    else if( option == "DVD - Next Chapter" )
    {
        // Next Chapter - F7
        SendVirtualKeystroke( 0x76, false, false, false, false );
    }
    else if( option == "DVD - Previous Chapter" )
    {
        // Previous Chapter - F8
        SendVirtualKeystroke( 0x77, false, false, false, false );
    }
    else if( option == "Switch Playlist-GUI" )
    {
        // Music Switch between Playlist/GUI - F1
        SendVirtualKeystroke( 0x70, false, false, false, false );
    }
    else if( option == "Delete selected image" )
    {
        // Simulate "0"
        SendVirtualKeystroke( 0x30, false, false, false, false );
    }
    else if( option == "Picture-Details" )
    {
        // Simulate "F3"
        SendVirtualKeystroke( 0x72, false, false, false, false );
    }
    else if( option == "Record current TV-program" )
    {
        // Simulate "R"
        SendVirtualKeystroke( 0x52, false, false, false, false );
    }
    else if( option == "Quit" )
    {
        // Quit - ALT+F4
        SendVirtualKeystroke( 0x73, false, false, true, false );    
		return false;
    }
    return true;
}

// Help - Needs to be updated
function showHelp()
{
    var code = new Array();
    var title = new Array();
    var description = new Array();
    
    code[0] = "s";
    title[0] = "Play Pause";
    description[0] = "Play Pause Running movie.";

    code[1] = new Array("v", "d");
    title[1] = "Move Down";
    description[1] = "Move Down.";

    code[2] = new Array("^", "u");
    title[2] = "Move Up";
    description[2] = "Move Up.";

    code[3] = new Array(">");
    title[3] = "Move Left";
    description[3] = "Move Left.";

    code[4] = new Array("<");
    title[4] = "Move Right";
    description[4] = "Move Right.";

    code[5] = new Array("f", "*");
    title[5] = "More";
    description[5] = "Other settings and commands";

    theTerminal.ShowKeypadHelp("MediaPortal Help", code, title, description);    
}

function setSysVolume(temp)
{   
    var soundVolume = helper.systemVolume + temp;
    
    if (soundVolume < 0) {
        soundVolume = 0;
    } else if (soundVolume > 65535) {
        soundVolume = 65535;
    }
    
    helper.systemVolume = soundVolume;

	if (soundVolume == 0) {
		ShowMessage("Volume", Mute, 0);
	} else {
		ShowMessage("Volume", Volume, helper.systemVolume/655);
	}
}