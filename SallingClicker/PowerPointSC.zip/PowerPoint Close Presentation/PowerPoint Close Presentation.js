
var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("powerpnt.exe")) {
    var ppt = new ActiveXObject("PowerPoint.Application");

	var success = false;
	
	try {     
		if( ppt.ActivePresentation != null ) {
			ppt.Visible = true;	    
			ppt.ActivePresentation.Close();
			success = true;

			var slideShowWindow = ppt.ActivePresentation.SlideShowWindow;
			if( slideShowWindow != null && slideShowWindow.View != null ) {
				slideShowWindow.Activate();
			}
		}
	} catch(e) {}
	
	if( ! success ){
		var errPopup = CreatePopupDialog( "");
		errPopup.textualContent = "No presentations open.";
		theTerminal.Push(errPopup);			
	} else {
	    theTerminal.PopTo("PowerPoint");	
	}
}
