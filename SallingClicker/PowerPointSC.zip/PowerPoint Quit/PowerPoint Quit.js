var helper = new ActiveXObject("SCHelper.SECHelper");
if( helper.IsProcessRunning("powerpnt.exe") ) {
    var ppt = new ActiveXObject("PowerPoint.Application");
    try {
        ppt.Quit();
    }
    catch (e) {}
}
