
var presentation = null;
var slideTitles = new Array();
var slideIndeces = new Array();
var helper = new ActiveXObject("SCHelper.SECHelper");

try {
    if( ! helper.IsProcessRunning("powerpnt.exe") ) {
        throw "Powerpoint not launched.";
    }
    
    var ppt = new ActiveXObject("PowerPoint.Application");
    ppt.Visible = true;
    
    if( ppt.Presentations.Count == 0 ) {
        throw "No open presentations.";
    }
    
    presentation = ppt.ActivePresentation;
        
	var currentSlide = 0;
	try {
		var slideShowWindow = presentation.SlideShowWindow;
		var currentSlideIndex = slideShowWindow.View.CurrentShowPosition;
	} catch( e ) {
	    throw "No active presentation.";
	}
        
    // Select slide
    
    try {
        for( var i = 1; i <= presentation.Slides.Count; i++ ) {
            var slide = presentation.Slides(i);
            if( slide.SlideShowTransition.Hidden ) {
                if( i <= currentSlideIndex ) {
                    currentSlideIndex--;
                }
            } else {
                var currentTitle = null;
                try {
                    var placeholders = slide.Shapes.Placeholders;
                    for (var t = 1; t <= placeholders.Count; t++) {
                        var shape = placeholders(t);
                        if( shape.PlaceholderFormat.Type == 1 ||     // ppPlaceholderTitle
                            shape.PlaceholderFormat.Type == 3 ) {    // ppPlaceholderCenterTitle
                            try {
                                currentTitle = shape.TextFrame.TextRange.Text;
                                if( currentTitle != null && currentTitle != "" ) break;
                            } catch(e) {}
                        }
                    }
                } catch(e) {}
                
            	if( currentTitle == null || currentTitle == "" ) {
                    currentTitle = "(no title)";
	            }

                slideTitles.push(currentTitle);
                slideIndeces.push(i);
            }
        }
    } catch( e ) {}
    
    var selectSlide = CreateListScreen( "selectSlide_");
    selectSlide.title = "Select Slide";
    selectSlide.itemLabels = slideTitles;
    selectSlide.selectedItem = currentSlideIndex-1;        
    theTerminal.Push(selectSlide);
} catch( e ) {
	var errPopup = CreatePopupDialog( "");
	errPopup.textualContent = e;
	theTerminal.Push(errPopup);	    
}



//
//
//

function selectSlide_ValueUpdated(list, property)
{
    if( ppt.SlideShowWindows.Count > 0 ) {
        var slideShowWindow = ppt.SlideShowWindows.Item(1);
        var slideIndex = slideIndeces[list.selectedItem];
        slideShowWindow.View.GotoSlide( slideIndex );
    }
}
