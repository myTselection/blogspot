var ppt = null

var currentPresentationID =  "";
var currentSlideIndex =  -1;

var keypad = null;
var slideRow = null;
var titleRow = null;
var notesRow = null;

// Initialize menus
var fullMenu_Labels = new Array();
var fullMenu_UUIDs = new Array();

fullMenu_Labels[0] = "Select Slide";
fullMenu_UUIDs[0] = "BF688C85-F920-4909-A154-C16C78CCF604"; 

fullMenu_Labels[1] = "Slide Notes...";         
fullMenu_UUIDs[1] = "showNotes";

fullMenu_Labels[2] = "Reset Elapsed";
fullMenu_UUIDs[2] = "resetTimer";                        

fullMenu_Labels[3] = "Finish Time...";
fullMenu_UUIDs[3] = "setTimer";                          

fullMenu_Labels[4] = "Open Presentation";         
fullMenu_UUIDs[4] = "728A609C-45E8-43a0-95E3-073668E680C9"; 

fullMenu_Labels[5] = "Mouse Pointing";
fullMenu_UUIDs[5] = "1da1f46f-151f-4387-8d04-74b431a99d07"; 

fullMenu_Labels[6] = "Close Presentation";
fullMenu_UUIDs[6] = "02533DF4-6754-4F81-94CD-C858791B74F2"; 

fullMenu_Labels[7] = "Quit PowerPoint";
fullMenu_UUIDs[7] = "EFAAAA4A-00AD-4eff-B829-2209598FEA64"; 

fullMenu_Labels[8] = "Thumbnail Preview...";
fullMenu_UUIDs[8] = "ThumbnailPreview";                     

var miniMenu_Labels = new Array();
var miniMenu_UUIDs = new Array();

miniMenu_Labels[0] = "Open Presentation...";         
miniMenu_UUIDs[0] = "728A609C-45E8-43a0-95E3-073668E680C9"; 

miniMenu_Labels[1] = "Quit PowerPoint";
miniMenu_UUIDs[1] = "EFAAAA4A-00AD-4eff-B829-2209598FEA64"; 

miniMenu_Labels[2] = "Thumbnail Preview...";
miniMenu_UUIDs[2] = "ThumbnailPreview";                     

//

var startTime = new Date();
var deadlineTime = null;
var time_checkpoint = null;
var last_channel = 0;
var keyWasRepeated = false;


// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_thumbnail = 0;
var setting_fullmenu_item = 0;
var setting_minimenu_item = 0;

// Read settings for this script
try {
	var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	if( settingsFileStream == null ) {
		// Write defaults
		writeSettings();
		settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	}
	while( true ) {
		var propertyName = settingsFileStream.ReadLine();
		var propertyValue = settingsFileStream.ReadLine();
		if( propertyName == "setting_thumbnail" ) {
			setting_thumbnail = parseInt( propertyValue );
		} else if( propertyName == "setting_fullmenu_item" ) {
			setting_fullmenu_item = parseInt( propertyValue );
		} else if( propertyName == "setting_minimenu_item" ) {
			setting_minimenu_item = parseInt( propertyValue );
		}
	}
} catch( e ) {
} finally {
	if( settingsFileStream != null ) settingsFileStream.Close();	
}


function writeSettings()
{
	try {
		var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );	// overwrite
		settingsFileStream.WriteLine( "setting_thumbnail" );
		settingsFileStream.WriteLine( setting_thumbnail );
		settingsFileStream.WriteLine( "setting_fullmenu_item" );
		settingsFileStream.WriteLine( setting_fullmenu_item );
		settingsFileStream.WriteLine( "setting_minimenu_item" );
		settingsFileStream.WriteLine( setting_minimenu_item );
		settingsFileStream.Close();
	} catch( e ) {}
}



//
// Kick things off by asking to launch PPT, if required
//

var helper = new ActiveXObject("SCHelper.SECHelper");
if( helper.IsProcessRunning("powerpnt.exe") ) {
	launchWidget();
} else {
	var launchQuestion = CreateQuestionDialog( "launch_");
	launchQuestion.textualContent = "Launch PowerPoint?";
	theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
	launchWidget();
}


// Deadline management

function askToSetDeadline()
{
    var deadlineQuestion = CreateQuestionDialog( "deadlinequery_");
    deadlineQuestion.textualContent = "Set finish time?";
    theTerminal.Push( deadlineQuestion );
}

function deadlinequery_OK(dialog)
{
	setDeadline();
}

function deadlinequery_Cancel(dialog)
{
	deadlineTime = null;
}

function setDeadline()
{
    var timeSelector = CreateTimeSelectorDialog( "deadline_");
    timeSelector.title = "Finish Time";
    var defaultDeadline = new Date();
    defaultDeadline.setMinutes( defaultDeadline.getMinutes() + 30 );
    timeSelector.value = defaultDeadline.getVarDate();
    theTerminal.Push(timeSelector);
}

function deadline_OK(dialog)
{
	deadlineTime = new Date( dialog.value );
    theTerminal.Popto("PowerPoint");	
}

function deadline_Cancel(dialog)
{
	deadlineTime = null;
}


// Create the main widget for this attraction

function launchWidget()
{
    try {
        ppt = new ActiveXObject("PowerPoint.Application");
    } catch( e ) {}
    if( ppt == null ) {
        var popup = CreatePopupDialog("popup");
        popup.textualContent = "Cannot connect to PowerPoint. Please install/repair.";
        theTerminal.Push( popup );
        return;
    }



    ppt.Visible = true;

	try {
		var slideShowWindow = ppt.ActivePresentation.SlideShowWindow;
		if( slideShowWindow != null && slideShowWindow.View != null ) {
			slideShowWindow.Activate();
		}
	} catch( e ) {}
		    
    keypad = CreateMediaplayerScreen( "keypad_");

	if( theTerminal.displaySize == scSmall ) {
		slideRow = keypad.CreateRow("", scLeft, scClip, scLarge);
		titleRow = keypad.CreateRow("", scLeft, scWrap, scMedium);
	} else if( theTerminal.displaySize == scMedium ) {
		slideRow = keypad.CreateRow("", scLeft, scClip, scLarge);
		titleRow = keypad.CreateRow("", scLeft, scClip, scMedium);
		notesRow = keypad.CreateRow("", scLeft, scWrap, scSmall);
	} else {
		slideRow = keypad.CreateRow("", scLeft, scClip, scLarge);
		titleRow = keypad.CreateRow("", scLeft, scWrap, scMedium);
		notesRow = keypad.CreateRow("", scLeft, scWrap, scSmall);
	}
    
    keypad.title = "PowerPoint";
    keypad.name = "PowerPoint";
    keypad.imageStyle = scFloatRight;
    
    theTerminal.Push(keypad);
}



// Main widget event handlers

function keypad_Update(theScreen)
{   
    var action_key = theTerminal.GetKeyName( "s" );
    if( action_key == null ) {
        action_key = "select/yes/ok"
    }
    	
	// No presentation open
    if( ! has_open_presentation() ) {
        setErrorState( theScreen, "No presentation", action_key + " = open" );
        return;
    }
    
	// No presentation active
    if( ! has_active_presentation() ) {
        setErrorState( theScreen, ppt.ActivePresentation.Name, action_key + " = start" );
        return;
    }

    var presentation = ppt.ActivePresentation;
    var slideShowWindow = presentation.SlideShowWindow;
    var slideShowView = slideShowWindow.View;
    
    var oldPresentationID = currentPresentationID;
    currentPresentationID = presentation.FullName;
    
	var oldSlideIndex = currentSlideIndex;
	currentSlideIndex = slideShowView.CurrentShowPosition;

    if( oldPresentationID != currentPresentationID ) {
		oldSlideIndex = -1;
    }
    
	try {    
        // Get expensive information if the slide has changed
        if( oldSlideIndex != currentSlideIndex ) {
        
            // Get the current slide image
            if( setting_thumbnail != 2 ) {
		        try {
			        var offset = 1;
			        if( setting_thumbnail == 1 ) {
			            offset = 0;
			        }
			        var nextSlide = presentation.Slides( currentSlideIndex+offset );
			        while( nextSlide.SlideShowTransition.Hidden ) {
				        offset++;
				        nextSlide = presentation.Slides( currentSlideIndex+offset );
			        }
        			
			        if( nextSlide != null ) {
				        var fso = new ActiveXObject("Scripting.FileSystemObject");
				        var tfolder = fso.GetSpecialFolder(2);
				        var tfile = tfolder + "\\PPTSlide.tmp"
				        nextSlide.Export( tfile, "JPG", theTerminal.displayWidth/2, theTerminal.displayWidth/2*3/4 );
				        keypad.image = tfile;
			        } else {
				        keypad.image = "";
			        }
		        } catch( e ) {
			        keypad.image = "";
		        }
            } else {
	            keypad.image = "";
	        }
    	    
	        // Other slide info
            if( slideRow != null ) {
                slideRow.textualContent = currentSlideIndex + " / " + presentation.Slides.Count;
            }

            if( titleRow != null ) {
		        titleRow.textualContent = get_slide_title();
		        titleRow.overflow = scWrap;
	        }
            if( notesRow != null ) {
                notesRow.textualContent = get_slide_note();
            }
        }
    	
        //
        
		var now = new Date();
		var pos = now - startTime;
		theScreen.mediaPosition = pos / 1000;
        if( deadlineTime != null ) {
			theScreen.mediaLength = (deadlineTime - startTime)/1000;
		} else {
		    theScreen.mediaLength = -1;
		}
		
		var pptState = slideShowView.State;
		if( pptState ==  1 ) {	// ppSlideShowRunning
			theScreen.playerState = scPlaying;		
		} else if( pptState == 2 ) {	// ppSlideShowPaused
			theScreen.playerState = scPaused;		
		} else if( pptState == 3 ) { // ppSlideShowBlackScreen
			theScreen.playerState = scPaused;		
		} else if( pptState == 4 ) { // ppSlideShowWhiteScreen
			theScreen.playerState = scPaused;		
		} else if( pptState == 5 ) { // ppSlideShowDone
			theScreen.playerState = scStopped;		
		} else {
			theScreen.playerState = scPlaying;		
		}
                
    } catch (e) {
        setErrorState( theScreen, "Slide info N/A", "" );
    }      
}

function keypad_KeyUp(theScreen, theKey)
{
	try {
		if( ! keyWasRepeated && theKey == "s" ) {
			var slideShowView = null;
			try {
				var slideShowWindow = ppt.ActivePresentation.SlideShowWindow;
				slideShowView = slideShowWindow.View;
			} catch( e ) {}
		
			if( slideShowView != null ) {
				var pptState = slideShowView.State;
				if( pptState ==  1 ) {	// ppSlideShowRunning
					slideShowView.State = 3;
				} else if( pptState == 2 ) {	// ppSlideShowPaused
					slideShowView.State = 1;
				} else if( pptState == 3 || pptState == 4 ) { // ppSlideShowBlackScreen, ppSlideShowWhiteScreen
					slideShowView.State = 1;		
				}
			} else {
				StartOrOpenPresentationIfNotStarted();
			}
					
		} else if( theKey == ":o" || theKey == ":c" ) {
			// Display the Notes
			showNotesBox();
			
		} else if( ! keyWasRepeated && (theKey == "f" || theKey == "*") ) {
			// Display the More menu			

 			var moreMenu;
            if( has_active_presentation() ) {
    			moreMenu = CreateListScreen( "fullMenu_" );
			    moreMenu.itemLabels = fullMenu_Labels;
    			moreMenu.selectedItem = setting_fullmenu_item;
            } else {
    			moreMenu = CreateListScreen( "miniMenu_" );
			    moreMenu.itemLabels = miniMenu_Labels;
    			moreMenu.selectedItem = setting_minimenu_item;
            }
    
			moreMenu.name = "More menu list";
			theTerminal.Push( moreMenu );
			
		}
	} catch ( e ) {}

    keyWasRepeated = false;
	
	return true;
}

		
function keypad_KeyDown(theScreen, theKey)
{	
    keyWasRepeated = false;
	var slideShowWindow = null;

	try {
		slideShowWindow = ppt.ActivePresentation.SlideShowWindow;
	} catch( e ) {}
	
	try {
		if( theKey == "^" || theKey == ">" || theKey == "u" ) {   
			if( slideShowWindow != null && slideShowWindow.View != null ) {
				try {
					slideShowWindow.View.Next();
					slideShowWindow.Activate();
				} catch( e ) {}
			}			
		} else if( theKey == "v" || theKey == "<" || theKey == "d" ) {
			if( slideShowWindow != null && slideShowWindow.View != null ) {
				slideShowWindow.View.Previous();
				slideShowWindow.Activate();
			}		
			
		} else if( theKey == ":help" || theKey == "#" ) {
	        showHelp();
	        
	    } else if( theKey == "0" ) {
			channel_key_pressed( 0 );
	    } else if( theKey == "1" ) {
			channel_key_pressed( 1 );
	    } else if( theKey == "2" ) {
			channel_key_pressed( 2 );
	    } else if( theKey == "3" ) {
			channel_key_pressed( 3 );
	    } else if( theKey == "4" ) {
			channel_key_pressed( 4 );
	    } else if( theKey == "5" ) {
			channel_key_pressed( 5 );
	    } else if( theKey == "6" ) {
			channel_key_pressed( 6 );
	    } else if( theKey == "7" ) {
			channel_key_pressed( 7 );
	    } else if( theKey == "8" ) {
			channel_key_pressed( 8 );
	    } else if( theKey == "9" ) {
			channel_key_pressed( 9 );
	    }	   
	} catch (e) {
		var errPopup = CreatePopupDialog( "");
		errPopup.textualContent = e.message;
		theTerminal.Push(errPopup);	
	}
	
	return true;	
}

function keypad_KeyRepeat(theScreen, theKey)
{
	try {
		if( theKey == "^" || theKey == ">" || theKey == "u" ) { 
    		var slideShowWindow = ppt.ActivePresentation.SlideShowWindow;		
        	if( slideShowWindow != null && slideShowWindow.View != null ) {
    			slideShowWindow.View.Last();
			    slideShowWindow.Activate();
			}
		} else if( theKey == "v" || theKey == "<" || theKey == "d" ) {
    		var slideShowWindow = ppt.ActivePresentation.SlideShowWindow;		
        	if( slideShowWindow != null && slideShowWindow.View != null ) {
    			slideShowWindow.View.First();
			    slideShowWindow.Activate();
			}
		} else if( ! keyWasRepeated && theKey == "s" ) {
		// Show notes shortcut
			showNotesBox();
		} else if( ! keyWasRepeated && (theKey == "f" || theKey == "*") ) {			    
		// Show slides shortcut
            theTerminal.ExecuteScript("BF688C85-F920-4909-A154-C16C78CCF604");	            
		}
	} catch( e ) {
	}
    keyWasRepeated = true;
}

function channel_key_pressed( num )
{
	try {
		var slideShowWindow = ppt.ActivePresentation.SlideShowWindow;

		if( slideShowWindow == null ) return;
		if( slideShowWindow.View == null ) return;

		var now = new Date();
		var offset = 100;
		if( time_checkpoint != null ) {
			offset = (now - time_checkpoint) / 1000;
		}
		time_checkpoint = now;
		if( offset < 2 && last_channel != 0 ) {
			last_channel = last_channel * 10 + num;
		} else {
			last_channel = num;
		}
		ShowMessage( "Go to slide " + last_channel );
		slideShowWindow.View.GotoSlide( last_channel );	
		slideShowWindow.Activate();
	} catch( e ) {}
}


function setErrorState( a_keypad, line_1, line_2 )
{
    if( slideRow != null ) {
        slideRow.textualContent = line_1;
        slideRow.overflow = scWrap;
    }
    
    if( titleRow != null ) {
        titleRow.textualContent = line_2;
        titleRow.overflow = scWrap;
	}

	if( notesRow != null ) {
	    notesRow.textualContent = "";
    }
    
	a_keypad.image = "";
	a_keypad.playerState = scStopped;
	a_keypad.mediaLength = -1;
	a_keypad.mediaPosition = -1;
	
	currentSlideIndex = -1; // force new info and recalc of thumbnail etc.	
}


//
// More menu handlers
//

function fullMenu_ValueUpdated( theScreen, theProperty )
{
	setting_fullmenu_item = theScreen.selectedItem;
	writeSettings();

	var uuid = fullMenu_UUIDs[theScreen.selectedItem];
	HandleMenuUUID( theScreen, uuid );
}

function miniMenu_ValueUpdated( theScreen, theProperty )
{
	setting_minimenu_item = theScreen.selectedItem;
	writeSettings();

	var uuid = miniMenu_UUIDs[theScreen.selectedItem];
	HandleMenuUUID( theScreen, uuid );
}
	
function HandleMenuUUID( theScreen, uuid )
{
    if( uuid == "setTimer" ) {   
		setDeadline();
    } else if( uuid == "resetTimer" ) {   
        startTime = new Date();
        theTerminal.Popto("PowerPoint");
    } else if( uuid == "showNotes" ) {   
		showNotesBox();
    } else if( uuid == "ThumbnailPreview" ) {   
		var previewoptions = CreateOptionListDialog( "ThumbnailPreview_");
		previewoptions.itemLabels = new Array("Show Next Slide","Show Current Slide","Off");
		previewoptions.title = "Thumbnail Preview";
		previewoptions.value = setting_thumbnail;
		theTerminal.Push( previewoptions );
    } else if( uuid != "") {
        theTerminal.ExecuteScript( uuid );
	}
}


function ThumbnailPreview_OK(dlg)
{
	setting_thumbnail = dlg.value;
	writeSettings();	
	
	currentSlideIndex = -1; // force recalc of thumbnail etc.
	
    theTerminal.Popto("PowerPoint");	
}



//
// Misc helper functions
//

function has_open_presentation()
{
    if( ppt.Presentations.Count == 0 ) return false;
    return true;
}


function has_active_presentation()
{
    try {
        var presentation = ppt.ActivePresentation;
	    var slideShowWindow = presentation.SlideShowWindow;
	    var slideShowView = slideShowWindow.View;
	    return true;
    } catch( e ) {}
    return false;
}

function showNotesBox()
{
    try {
        if( ! has_open_presentation() ) {
            throw "No open presentations.";
        }
    
        if( ! has_active_presentation() ) {
	        throw "No active presentation.";
        }
        
	    var notesBox = CreateMessageboxDialog( "" );
	    notesBox.title = "Notes";
	    notesBox.textualContent = get_slide_note();
	    theTerminal.Push( notesBox );
    } catch( e ) {
	    var errPopup = CreatePopupDialog( "" );
	    errPopup.textualContent = e;
	    theTerminal.Push(errPopup);	    
    }
}


function StartOrOpenPresentationIfNotStarted()
{    
	if (ppt.Presentations.Count == 0) {
        theTerminal.ExecuteScript("728A609C-45E8-43a0-95E3-073668E680C9"); // Open presentation
        return null;
	}	
	
    try {
		var slideShowWindow = ppt.ActivePresentation.SlideShowWindow;
		slideShowWindow.Activate();
    } catch (e) {
		ppt.ActivePresentation.SlideShowSettings.Run();
		startTime = new Date();
		currentSlideIndex = -1;
		askToSetDeadline();
    }
}

function get_slide_title()
{
    var presentation = ppt.ActivePresentation;
	var slideShowWindow = presentation.SlideShowWindow;
    var currentSlide = slideShowWindow.View.CurrentShowPosition;

    var currentTitle = null;
    
    try {
        var placeholders = presentation.Slides(currentSlide).Shapes.Placeholders;
        for (var i = 1; i <= placeholders.Count; i++) {
            var shape = placeholders(i);
            if( shape.PlaceholderFormat.Type == 1 ||     // ppPlaceholderTitle
                shape.PlaceholderFormat.Type == 3 ) {    // ppPlaceholderCenterTitle
                try {
                    currentTitle = shape.TextFrame.TextRange.Text;
                    if( currentTitle != null && currentTitle != "" ) break;
                } catch(e) {}
            }
        }
    } catch(e) {}
    
	if( currentTitle == null || currentTitle == "" ) {
        currentTitle = "(no title)";
	}
	return currentTitle;
}

function get_slide_note()
{
    var presentation = ppt.ActivePresentation;
	var slideShowWindow = presentation.SlideShowWindow;
    var currentSlide = slideShowWindow.View.CurrentShowPosition;

    var notesText = null;
    
    try {    
        var notesPage = presentation.Slides(currentSlide).NotesPage;
        var placeholders = notesPage.Shapes.Placeholders;
        for (var i = 1; i <= placeholders.Count; i++) {
            var shape = placeholders(i);
            if( shape.PlaceholderFormat.Type == 2 ) {    // ppPlaceholderBody        
                try {
                    notesText = shape.TextFrame.TextRange.Text;
                    break;
                } catch(e) {}
            }
        }
    } catch(e) {}
        
	if( notesText == null || notesText == "" ) {
        notesText = "No notes";
	}
	return notesText;
}


function showHelp()
{
    var code = new Array();
    var title = new Array();
    var description = new Array();
    
    code[0] = "s";
    title[0] = "Play/Pause";
    description[0] = "Toggles black screen. Hold to view full slide notes.";

    code[1] = new Array("v", "<", "d");
    title[1] = "Previous Slide";
    description[1] = "Moves to the previous slide";

    code[2] = new Array("^", ">", "u");
    title[2] = "Next Slide";
    description[2] = "Moves to the next slide";

    code[3] = new Array("f", "*");
    title[3] = "More";
    description[3] = "Other settings and commands. Hold to view slides list.";

    code[4] = new Array(":c", ":o");
    title[4] = "View Notes";
    description[4] = "Views full slide notes.";

    theTerminal.ShowKeypadHelp("PowerPoint Help", code, title, description);    
}