
var ppt = null;
var browsePath = "";
var paths = null;

var fso = new ActiveXObject("Scripting.FileSystemObject");

// Settings (persisted in txt file)
var setting_path = null;

// Read settings for this script
try {
	var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	if( settingsFileStream == null ) {
		// Write defaults
		writeSettings();
		settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	}
	while( true ) {
		var propertyName = settingsFileStream.ReadLine();
		var propertyValue = settingsFileStream.ReadLine();
		if( propertyName == "setting_path" ) {
			browsePath = propertyValue;
		}
	}
} catch( e ) {
} finally {
	if( settingsFileStream != null ) settingsFileStream.Close();	
}




var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("powerpnt.exe")) 
{
    launchWidget();
}
else 
{
    var launchQuestion = CreateQuestionDialog( "launch_");
    launchQuestion.textualContent = "Launch PowerPoint?";
    theTerminal.Push(launchQuestion);
}


function writeSettings()
{
	try {
		var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );	// overwrite
		settingsFileStream.WriteLine( "setting_path" );
		settingsFileStream.WriteLine( browsePath );
		settingsFileStream.Close();
	} catch( e ) {}
}


function launch_OK(w)
{
	launchWidget();
}

function launchWidget()
{
    ppt = new ActiveXObject("PowerPoint.Application");
    ppt.Visible = true;

	var optionList = CreateOptionListDialog( "option_");
    optionList.title = "Open Presentation";
    optionList.itemLabels = new Array("Recent", "Browse");
    optionList.value = 0;
	theTerminal.Push(optionList);	
}

function option_OK(widget)
{
	if( widget.value == 0 ) {
		show_recentfile_selector();
	} else {
		launchBrowser();
	}
}

function launchBrowser()
{
	var browser = CreateListScreen( "browser_");	
	browser.name = "More menu open presentation";
	browser.title = "Select File";        
	browser.selectedItem = 0;
	browser.itemLabels = getFolderItems();
	    
    theTerminal.Push( browser );
}

function show_recentfile_selector()
{
    var shell = new ActiveXObject("WScript.Shell");
    paths = new Array();
    var names = new Array();
	try
	{
		var num;
		for( num = 1; true; num++ )
		{
			var regKey = "HKCU\\Software\\Microsoft\\Office\\" + ppt.Version + "\\PowerPoint\\Recent File List\\File" + num;
			var path  = shell.RegRead(regKey);
			paths.push( path );
			names.push( fso.GetFileName( path ) );
		}
	} catch( e ) {}	// Catch end of list

	// Pull out MRU from Office 12 PowerPoint (2007)	
	try
	{
		var num;
		for( num = 1; true; num++ )
		{
			var regKey = "HKCU\\Software\\Microsoft\\Office\\" + ppt.Version + "\\PowerPoint\\File MRU\\Item " + num;
			var path  = shell.RegRead(regKey);
			var pathArray = path.split( "*" );
			pathArray.shift();
			path = pathArray.join( "*" );
			paths.push( path );
			names.push( fso.GetFileName( path ) );
		}
	} catch( e ) {}	// Catch end of list

	//
	
	if( paths.length == 0 ) {
		var errPopup = CreatePopupDialog( "");
		errPopup.textualContent = "No recent presentations.";
		theTerminal.Push( errPopup );	
	} else {
		var recentList = CreateListScreen( "recent_");
		recentList.title = "Select Recent";        
		recentList.itemLabels = names;
		theTerminal.Push( recentList );
	}
}

function recent_ValueUpdated(widget, property)
{
	try
	{
		ppt.Presentations.Open(paths[widget.selectedItem]);
	    theTerminal.PopTo("PowerPoint");
		return false;
	} catch( e )
	{
		var errPopup = CreatePopupDialog( "");
		errPopup.textualContent = e.message;
		theTerminal.Push(errPopup);	
	}
	return true;
}

function browser_ValueUpdated(browser, property)
{
    var path = browser.itemLabels[browser.selectedItem] + "\\";

    var newPath = fso.BuildPath( browsePath, path );
    newPath = fso.GetAbsolutePathName( newPath );
    if( newPath == browsePath ) {
		newPath = "";
    }
    
    if( fso.FileExists( newPath ) ) {
        // Selected a file
        ppt.Presentations.Open(newPath);
	    theTerminal.PopTo("PowerPoint");
        return false;
    } else {
        // Selected a folder
        browsePath = newPath;
		writeSettings();
    }
    
    browser.itemLabels = getFolderItems();
    browser.selectedItem = 0;
    
    // Don't pop browser from stack
    return true;
}

function getFolderItems()
{
	var items = new Array();
	
	if( browsePath == "" ) {
		// Open Presentation
		var e = new Enumerator( fso.Drives );
		for( ; !e.atEnd(); e.moveNext() ) {
			var x = e.item();
			items.push( x.DriveLetter + ":" );
		}        
	} else {
		items.push("..");
		
	    var folder = null;
	    try {
			folder = fso.GetFolder( browsePath );
	    } catch( e ) {
			browsePath = "";
			return getFolderItems();
	    }
	    
		var e = new Enumerator( folder.SubFolders );
		for( ; !e.atEnd(); e.moveNext() ) {
			var x = e.item();
			items.push(x.Name);
		}        
	    
		e = new Enumerator( folder.files );
		for( ; !e.atEnd(); e.moveNext() ) {
			var file = e.item();
			var filename = file.Name;
			var fileext4 = filename.substr( filename.lastIndexOf("."), 4 ).toLowerCase();
			if( fileext4 == ".ppt" || fileext4 == ".pps" ) {
				items.push( file.Name );
			}
		}    
	}
	
	return items;
}
