var msgbox = CreateMessageboxDialog( "messagebox_");

var man = theTerminal.manufacturer;
var mod = theTerminal.model;
var rev = theTerminal.revision;
var id = theTerminal.identification;

msgbox.title = "Device Info";
msgbox.textualContent = "Manufacturer:\n " + man + "\nModel:\n " + mod + "\nRevision:\n " + rev + "\nID:\n " + id;

theTerminal.Push(msgbox);
