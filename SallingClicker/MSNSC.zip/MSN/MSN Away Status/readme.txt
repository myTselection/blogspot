This script requires either:

For Windows Live Messenger users, Windows Plus! Live - http://www.msgplus.net
For users of older versions of MSN, Messenger Plus! - http://www.msgpluslive.net

All the script does is:
Send the Ctrl + Alt + Q keys when you leave
Send the Ctrl + Alt + E keys when you return
It's MSN Plus that does all the real work.

After installing the script and MSN Plus! Live you will need to configure MSN Plus! Live:
NOTE: These instructions are based on MSN Plus! Live.

1) Under the preferences, find 'Messenger Lock'.
2) Set 'Activate Messenger Lock with a system wide shortcut to 'Ctrl + Alt + Q' by selecting it and pressing those keys simultaneously.
3) Set 'Change my status' to 'Away'.
4) Set 'Unlock with a system wide shortcut to 'Ctrl + Alt + E' by selecting it and pressing those keys simultaneously.
5) Deselect 'Ask password to unlock'.
6) Press OK.





