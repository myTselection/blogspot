var widget = CreateQuestionDialog( "confirmation_");
widget.textualContent = "msn away ? "
theTerminal.Push(widget);

function confirmation_OK(w)
{
            SendVirtualKeystroke( 0x51, false, true, true, false );
}