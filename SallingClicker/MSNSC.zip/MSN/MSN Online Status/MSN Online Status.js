var widget = CreateQuestionDialog( "confirmation_");
widget.textualContent = "msn online ? "
theTerminal.Push(widget);

function confirmation_OK(w)
{
     SendVirtualKeystroke( 0x45, false, true, true, false );
}