//myT Mouse Keyboard control + Explorer + Zoomit control
//http://myTselection.blogspot.com
//Micorosft ZoomIt: http://technet.microsoft.com/en-us/sysinternals/bb897434
//UUID generator: http://www.famkruithof.net/uuid/uuidgen

//Zoom menu
var zoomMenuItems = new Array();
	zoomMenuItems[0] = "Zoom In";
	zoomMenuItems[1] = "Zoom Out";
	zoomMenuItems[2] = "Enable Zoom mode (std)";
	zoomMenuItems[3] = "Enable Live Zoom mode";
	zoomMenuItems[4] = "Enable Pen Draw mode";
	zoomMenuItems[5] = "Enable Timer mode";
	zoomMenuItems[6] = "Special keys menu";
	zoomMenuItems[7] = "Send Esc";
	zoomMenuItems[8] = "Key configuration";
	


var timerMenuItems = new Array();
	timerMenuItems[0] = "Exit Timer mode";
	timerMenuItems[1] = "Increase time";
	timerMenuItems[2] = "Decrease time";
	timerMenuItems[3] = "Red timer";
	timerMenuItems[4] = "Green timer";
	timerMenuItems[5] = "Blue timer";
	timerMenuItems[6] = "Orange timer";
	timerMenuItems[7] = "Yellow timer";
	timerMenuItems[8] = "Pink timer";

//Pen menu
var penMenuItems = new Array();
	penMenuItems[0] = "Type text";
	penMenuItems[1] = "Undo last drawing";
	penMenuItems[2] = "Undo all drawings";
	penMenuItems[3] = "Center Pen cursor";
	penMenuItems[4] = "Clear screen White";
	penMenuItems[5] = "Clear screen Black";
	penMenuItems[6] = "Exit Pen mode";
	penMenuItems[7] = "Pen Layout menu";
	penMenuItems[8] = "Pen Shapes menu";
	penMenuItems[9] = "Copy Pen screen";
	penMenuItems[10] = "Save Pen screen";

var penTextMenuItems = new Array();
	penTextMenuItems[0] = "Switch Typing mode";
	penTextMenuItems[1] = "Bigger font";
	penTextMenuItems[2] = "Smaller font";

var penLayoutMenuItems = new Array();
	penLayoutMenuItems[0] = "Wider Pen";
	penLayoutMenuItems[1] = "Smaller Pen";
	penLayoutMenuItems[2] = "Red Pen";
	penLayoutMenuItems[3] = "Green Pen";
	penLayoutMenuItems[4] = "Blue Pen";
	penLayoutMenuItems[5] = "Orange Pen";
	penLayoutMenuItems[6] = "Yellow Pen";
	penLayoutMenuItems[7] = "Pink Pen";

var penShapeMenuItems = new Array();
	penShapeMenuItems[0] = "Draw straight line";
	penShapeMenuItems[1] = "Draw rectangle";
	penShapeMenuItems[2] = "Draw ellipse";
	penShapeMenuItems[3] = "Draw arrow";
	penShapeMenuItems[4] = "Cancel special shapes drawing";

// Initialize options menu
var optionsMenuItems = new Array();
	optionsMenuItems[0] = "Open file";
	optionsMenuItems[1] = "Zoom screen";
	optionsMenuItems[2] = "Send long text (write on device)";
	optionsMenuItems[3] = "Activate Shift key";
	optionsMenuItems[4] = "Activate Ctrl key";
	optionsMenuItems[5] = "Activate Alt key";
	optionsMenuItems[6] = "Activate Win key";
	optionsMenuItems[7] = "Send Function keys";
	optionsMenuItems[8] = "Send Media keys";
	optionsMenuItems[9] = "Send Combination keys";
	optionsMenuItems[10] = "Send Special characters";
	optionsMenuItems[11] = "Enable Scroll mode";
	optionsMenuItems[12] = "Clear device home screen";
	optionsMenuItems[13] = "Show screenshot";
	optionsMenuItems[14] = "Exchange text";
	//optionsMenuItems[13] = "Send Ctrl + Alt + Delete";


var WSHShell = new ActiveXObject("WScript.Shell");
var favoriteLocationNames = new Array();
var favoriteLocationPaths = new Array();
	favoriteLocationNames[0] = "Start Menu (all users)";
	favoriteLocationPaths[0] = WSHShell.ExpandEnvironmentStrings("%programdata%") + "\\Microsoft\\Windows\\Start Menu\\Programs";
	favoriteLocationNames[1] = "Start Menu (current users)";
	favoriteLocationPaths[1] = WSHShell.ExpandEnvironmentStrings("%appdata%") + "\\Microsoft\\Windows\\Start Menu\\Programs";
	favoriteLocationNames[2] = "Start Menu (all users XP)";
	favoriteLocationPaths[2] = WSHShell.ExpandEnvironmentStrings("%allusersprofile%") + "\\Start Menu\\Programs";
	favoriteLocationNames[3] = "Start Menu (current users XP)";
	favoriteLocationPaths[3] = WSHShell.ExpandEnvironmentStrings("%userprofile%") + "\\Start Menu\\Programs";
	favoriteLocationNames[4] = "Desktop";
	favoriteLocationPaths[4] = WSHShell.ExpandEnvironmentStrings("%userprofile%") + "\\Desktop";
	favoriteLocationNames[5] = "My Documents";
	favoriteLocationPaths[5] = WSHShell.ExpandEnvironmentStrings("%userprofile%") + "\\My Documents";
	favoriteLocationNames[6] = "My Computer";
	favoriteLocationPaths[6] = "";
	favoriteLocationNames[7] = "IE Favorites";
	favoriteLocationPaths[7] = WSHShell.ExpandEnvironmentStrings("%userprofile%") + "\\Favorites";
	favoriteLocationNames[8] = "Temp";
	favoriteLocationPaths[8] = WSHShell.ExpandEnvironmentStrings("%temp%");
	favoriteLocationNames[9] = "Application data";
	favoriteLocationPaths[9] = WSHShell.ExpandEnvironmentStrings("%appdata%");
	favoriteLocationNames[10] = "Windows";
	favoriteLocationPaths[10] = WSHShell.ExpandEnvironmentStrings("%windir%");
	favoriteLocationNames[11] = "Program files";
	favoriteLocationPaths[11] = WSHShell.ExpandEnvironmentStrings("%programfiles%");
	favoriteLocationNames[12] = "User profile";
	favoriteLocationPaths[12] = WSHShell.ExpandEnvironmentStrings("%userprofile%");


var fkeysMenuItems = new Array();
	fkeysMenuItems[0] = "F1";
	fkeysMenuItems[1] = "F2";
	fkeysMenuItems[2] = "F3";
	fkeysMenuItems[3] = "F4";
	fkeysMenuItems[4] = "F5";
	fkeysMenuItems[5] = "F6";
	fkeysMenuItems[6] = "F7";
	fkeysMenuItems[7] = "F8";
	fkeysMenuItems[8] = "F9";
	fkeysMenuItems[9] = "F10";
	fkeysMenuItems[10] = "F11";
	fkeysMenuItems[11] = "F12";
	fkeysMenuItems[12] = "Esc";
	fkeysMenuItems[13] = "Tab";
	fkeysMenuItems[14] = "End";
	fkeysMenuItems[15] = "Home";
	fkeysMenuItems[16] = "Page Up";
	fkeysMenuItems[17] = "Page Down";
	fkeysMenuItems[18] = "Insert";
	fkeysMenuItems[19] = "Delete";
	fkeysMenuItems[20] = "Num Lock";
	fkeysMenuItems[21] = "Caps Lock";
	fkeysMenuItems[22] = "Scroll Lock";
	fkeysMenuItems[23] = "Print screen";
	fkeysMenuItems[24] = "Pause";
	fkeysMenuItems[25] = "Enter";
	fkeysMenuItems[26] = "Middle Mouse";
	fkeysMenuItems[27] = "Shift";
	fkeysMenuItems[28] = "Ctrl";
	fkeysMenuItems[29] = "Alt";
	fkeysMenuItems[30] = "Win";
	fkeysMenuItems[31] = "Left";
	fkeysMenuItems[32] = "Right";
	fkeysMenuItems[33] = "Up";
	fkeysMenuItems[34] = "Down";


var specialcharkeysMenuItems = new Array();
	specialcharkeysMenuItems[0] = "\\";
	specialcharkeysMenuItems[1] = "/";
	specialcharkeysMenuItems[2] = "$";
	specialcharkeysMenuItems[3] = "&";
	specialcharkeysMenuItems[4] = "@";
	specialcharkeysMenuItems[5] = "\'";
	specialcharkeysMenuItems[6] = "(";
	specialcharkeysMenuItems[7] = ")";
	specialcharkeysMenuItems[8] = "^";
	specialcharkeysMenuItems[9] = "\"";
	specialcharkeysMenuItems[10] = "!";
	specialcharkeysMenuItems[11] = "\{";
	specialcharkeysMenuItems[12] = "}";
	specialcharkeysMenuItems[13] = "[";
	specialcharkeysMenuItems[14] = "]";
	specialcharkeysMenuItems[15] = "(";
	specialcharkeysMenuItems[16] = ")";
	specialcharkeysMenuItems[17] = "_";
	specialcharkeysMenuItems[18] = "~";
	specialcharkeysMenuItems[19] = "=";
	specialcharkeysMenuItems[20] = "|";
	specialcharkeysMenuItems[21] = "�";
	specialcharkeysMenuItems[22] = "�";
	specialcharkeysMenuItems[23] = "�";
	specialcharkeysMenuItems[24] = "�";
	specialcharkeysMenuItems[25] = "�";
	specialcharkeysMenuItems[26] = "�";
	specialcharkeysMenuItems[27] = "�";
	specialcharkeysMenuItems[28] = "�";
	specialcharkeysMenuItems[29] = "�";
	specialcharkeysMenuItems[30] = "�";
	specialcharkeysMenuItems[31] = "�";
	specialcharkeysMenuItems[32] = "�";
	specialcharkeysMenuItems[33] = "�";
	specialcharkeysMenuItems[34] = "�";
	specialcharkeysMenuItems[35] = "�";
	specialcharkeysMenuItems[36] = "�";
	specialcharkeysMenuItems[37] = "�";
	specialcharkeysMenuItems[38] = "�";
	specialcharkeysMenuItems[39] = "�";
	specialcharkeysMenuItems[40] = "�";
	specialcharkeysMenuItems[41] = "�";
	specialcharkeysMenuItems[42] = "�";
	specialcharkeysMenuItems[43] = "�";
	specialcharkeysMenuItems[44] = "�";
	specialcharkeysMenuItems[45] = "�";
	specialcharkeysMenuItems[46] = "",
	specialcharkeysMenuItems[47] = "�";
	specialcharkeysMenuItems[48] = "�";
	specialcharkeysMenuItems[49] = "�";
	specialcharkeysMenuItems[50] = "�";
	specialcharkeysMenuItems[51] = "�";
	specialcharkeysMenuItems[52] = "�";
	specialcharkeysMenuItems[53] = "�";
	specialcharkeysMenuItems[54] = "�";
	specialcharkeysMenuItems[55] = "�";
	specialcharkeysMenuItems[56] = "�";
	specialcharkeysMenuItems[57] = "�";
	specialcharkeysMenuItems[58] = "�";
	specialcharkeysMenuItems[59] = "�";
	specialcharkeysMenuItems[60] = "�";
	specialcharkeysMenuItems[61] = "�";
	specialcharkeysMenuItems[62] = "�";
	specialcharkeysMenuItems[63] = "�";
	specialcharkeysMenuItems[64] = "�";
	specialcharkeysMenuItems[65] = "�";
	specialcharkeysMenuItems[66] = "�";
	specialcharkeysMenuItems[67] = "�";
	specialcharkeysMenuItems[68] = "�";
	specialcharkeysMenuItems[69] = "�";
	specialcharkeysMenuItems[70] = "�";
	specialcharkeysMenuItems[71] = "�";
	specialcharkeysMenuItems[72] = "�";
	specialcharkeysMenuItems[73] = "�";
	specialcharkeysMenuItems[74] = "�";
	specialcharkeysMenuItems[75] = "�";
	specialcharkeysMenuItems[76] = "�";
	specialcharkeysMenuItems[77] = "�";
	specialcharkeysMenuItems[78] = "�";
	specialcharkeysMenuItems[79] = "�";
	specialcharkeysMenuItems[80] = "�";
	specialcharkeysMenuItems[81] = "�";
	specialcharkeysMenuItems[82] = "�";
	specialcharkeysMenuItems[83] = "�";
	specialcharkeysMenuItems[84] = "�";
	specialcharkeysMenuItems[85] = "�";
	specialcharkeysMenuItems[86] = "�";
	specialcharkeysMenuItems[87] = "�";
	specialcharkeysMenuItems[88] = "�";
	specialcharkeysMenuItems[89] = "�";
	specialcharkeysMenuItems[90] = "�";
	specialcharkeysMenuItems[91] = "�";
	specialcharkeysMenuItems[92] = "�";
	specialcharkeysMenuItems[93] = "�";
	specialcharkeysMenuItems[94] = "�";
	specialcharkeysMenuItems[95] = "�";
	specialcharkeysMenuItems[96] = "�";
	specialcharkeysMenuItems[97] = "�";
	specialcharkeysMenuItems[98] = "�";
	specialcharkeysMenuItems[99] = "�";
	specialcharkeysMenuItems[100] = "�";
	specialcharkeysMenuItems[101] = "�";
	specialcharkeysMenuItems[102] = "�";
	specialcharkeysMenuItems[103] = "�";
	specialcharkeysMenuItems[104] = "�";
	specialcharkeysMenuItems[105] = "�";
	specialcharkeysMenuItems[106] = "�";
	specialcharkeysMenuItems[107] = "�";
	specialcharkeysMenuItems[108] = "�";
	specialcharkeysMenuItems[109] = "�";
	specialcharkeysMenuItems[110] = "�";
	specialcharkeysMenuItems[111] = "�";
	specialcharkeysMenuItems[112] = "�";
	specialcharkeysMenuItems[113] = "�";
	specialcharkeysMenuItems[114] = "�";
	specialcharkeysMenuItems[115] = "�";
	specialcharkeysMenuItems[116] = "�";
	specialcharkeysMenuItems[117] = "�";
	specialcharkeysMenuItems[118] = "�";
	specialcharkeysMenuItems[119] = "�";
	specialcharkeysMenuItems[120] = "�";
	specialcharkeysMenuItems[121] = "�";
	specialcharkeysMenuItems[122] = "�";
	specialcharkeysMenuItems[123] = "�";
	specialcharkeysMenuItems[124] = "�";
	specialcharkeysMenuItems[125] = "�";
	specialcharkeysMenuItems[126] = "�";
	specialcharkeysMenuItems[127] = "�";
	specialcharkeysMenuItems[128] = "�";
	specialcharkeysMenuItems[129] = "�";
	specialcharkeysMenuItems[130] = "�";
	specialcharkeysMenuItems[131] = "�";
	specialcharkeysMenuItems[132] = "�";
	specialcharkeysMenuItems[133] = "�";
	specialcharkeysMenuItems[134] = "�";
	specialcharkeysMenuItems[135] = "�";
	specialcharkeysMenuItems[136] = "�";
	specialcharkeysMenuItems[137] = "�";
	specialcharkeysMenuItems[138] = "�";
	specialcharkeysMenuItems[139] = "�";
	specialcharkeysMenuItems[140] = "�";
	specialcharkeysMenuItems[141] = "�";
	specialcharkeysMenuItems[142] = "�";
	specialcharkeysMenuItems[143] = "�";


var mediakeysMenuItems = new Array();
	mediakeysMenuItems[0] = "Media";
	mediakeysMenuItems[1] = "Play Pause";
	mediakeysMenuItems[2] = "Next track";
	mediakeysMenuItems[3] = "Previous track";
	mediakeysMenuItems[4] = "Stop";
	mediakeysMenuItems[5] = "Mode change";
	mediakeysMenuItems[6] = "Volume up";
	mediakeysMenuItems[7] = "Volume down";
	mediakeysMenuItems[8] = "Volume mute";
	mediakeysMenuItems[9] = "Browser Back";
	mediakeysMenuItems[10] = "Browser Forward";
	mediakeysMenuItems[11] = "Browser Favorites";
	mediakeysMenuItems[12] = "Browser Home";
	mediakeysMenuItems[13] = "Browser Refresh";
	mediakeysMenuItems[14] = "Browser Search";
	mediakeysMenuItems[15] = "Browser Stop";
	//mediakeysMenuItems[16] = "Zoom";


var scrollMenuItems = new Array();
	scrollMenuItems[0] = "Scroll Up";
	scrollMenuItems[1] = "Scroll Down";
	scrollMenuItems[2] = "";
	scrollMenuItems[3] = "Mouse Up (quick)";
	scrollMenuItems[4] = "Mouse Up";
	scrollMenuItems[5] = "Mouse Down (quick)";
	scrollMenuItems[6] = "Mouse Down";
	scrollMenuItems[7] = "Mouse Left (quick)";
	scrollMenuItems[8] = "Mouse Left";
	scrollMenuItems[9] = "Mouse Right (quick)";
	scrollMenuItems[10] = "Mouse Right";


var fso = new ActiveXObject( "Scripting.FileSystemObject" );
var localTempFolder = fso.GetSpecialFolder(2);
var ComboCount = 0;
var combinationMenuItems = new Array();
combinationMenuItems[0] = "Release All Keys";
var combinations = new Array ();
combinations[0] = "";

try {
	var combinationsFileStream = fso.OpenTextFile( resourcesPath + "\\Combinations.txt" );
	while(true) {
		ComboCount++;
		fullName = combinationsFileStream.Readline();
		if (fullName.indexOf("(") != -1 )	{
				combinationMenuItems[ComboCount] = ComboCount + ": " + fullName.slice(fullName.indexOf("(") + 1, fullName.length - 1);
				combinations[ComboCount] = fullName
		}
	}
} catch (e) {	}
finally {
	if( combinationsFileStream != null ) combinationsFileStream.Close();	
}

//supported characters to send:  !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~�����������������������������������������������������������������������������������������������
//characters that are not working (but configured): ���������������������������

var keys = new Array();
keys[32]  = [" ",""];
keys[33]  = ["!",""];
keys[34]  = ["\"",""];
keys[35]  = ["#",""];
keys[36]  = ["$",""];
keys[37]  = ["%",""];
keys[38]  = ["&",""];
keys[39]  = ["\'",""];
keys[40]  = ["(",""];
keys[41]  = [")",""];
keys[42]  = ["*",""];
keys[43]  = ["+",0x6b];
keys[44]  = [",",""];
keys[45]  = ["-",""];
keys[46]  = [".",0x6e];
keys[47]  = ["/",0x6f];
keys[48]  = ["0",0x30];
keys[49]  = ["1",0x31];
keys[50]  = ["2",0x32];
keys[51]  = ["3",0x33];
keys[52]  = ["4",0x34];
keys[53]  = ["5",0x35];
keys[54]  = ["6",0x36];
keys[55]  = ["7",0x37];
keys[56]  = ["8",0x38];
keys[57]  = ["9",0x39];
keys[58]  = [":",""];
keys[59]  = [";",""];
keys[60]  = ["<",""];
keys[61]  = ["=",""];
keys[62]  = [">",""];
keys[63]  = ["?",""];
keys[64]  = ["@",""];
keys[65]  = ["A",0x41];
keys[66]  = ["B",0x42];
keys[67]  = ["C",0x43];
keys[68]  = ["D",0x44];
keys[69]  = ["E",0x45];
keys[70]  = ["F",0x46];
keys[71]  = ["G",0x47];
keys[72]  = ["H",0x48];
keys[73]  = ["I",0x49];
keys[74]  = ["J",0x4a];
keys[75]  = ["K",0x4b];
keys[76]  = ["L",0x4c];
keys[77]  = ["M",0x4d];
keys[78]  = ["N",0x4e];
keys[79]  = ["O",0x4f];
keys[80]  = ["P",0x50];
keys[81]  = ["Q",0x51];
keys[82]  = ["R",0x52];
keys[83]  = ["S",0x53];
keys[84]  = ["T",0x54];
keys[85]  = ["U",0x55];
keys[86]  = ["V",0x56];
keys[87]  = ["W",0x57];
keys[88]  = ["X",0x58];
keys[89]  = ["Y",0x59];
keys[90]  = ["Z",0x5a];
keys[91]  = ["[",""];
keys[92]  = ["\\",""];
keys[93]  = ["]",""];
keys[94]  = ["^",""];
keys[95]  = ["_",""];
keys[96]  = ["`",""];
keys[97]  = ["a",0x41];
keys[98]  = ["b",0x42];
keys[99]  = ["c",0x43];
keys[100] = ["d",0x44];
keys[101] = ["e",0x45];
keys[102] = ["f",0x46];
keys[103] = ["g",0x47];
keys[104] = ["h",0x48];
keys[105] = ["i",0x49];
keys[106] = ["j",0x4a];
keys[107] = ["k",0x4b];
keys[108] = ["l",0x4c];
keys[109] = ["m",0x4d];
keys[110] = ["n",0x4e];
keys[111] = ["o",0x4f];
keys[112] = ["p",0x50];
keys[113] = ["q",0x51];
keys[114] = ["r",0x52];
keys[115] = ["s",0x53];
keys[116] = ["t",0x54];
keys[117] = ["u",0x55];
keys[118] = ["v",0x56];
keys[119] = ["w",0x57];
keys[120] = ["x",0x58];
keys[121] = ["y",0x59];
keys[122] = ["z",0x5a];
keys[123] = ["{",""];
keys[124] = ["|",""];
keys[125] = ["}",""];
keys[126] = ["~",""];
keys[127] = ["",""];
keys[128] = ["�",""];
keys[129] = ["",""];
keys[130] = ["�",""];
keys[131] = ["�",""];
keys[132] = ["�",""];
keys[133] = ["�",""];
keys[134] = ["�",""];
keys[135] = ["�",""];
keys[136] = ["�",""];
keys[137] = ["�",""];
keys[138] = ["�",""];
keys[139] = ["�",""];
keys[140] = ["�",""];
keys[141] = ["",""];
keys[142] = ["�",""];
keys[143] = ["",""];
keys[144] = ["",""];
keys[145] = ["�",""];
keys[146] = ["�",""];
keys[147] = ["�",""];
keys[148] = ["�",""];
keys[149] = ["�",""];
keys[150] = ["�",0x6d];
keys[151] = ["�",""];
keys[152] = ["�",""];
keys[153] = ["�",""];
keys[154] = ["�",""];
keys[155] = ["�",""];
keys[156] = ["�",""];
keys[157] = ["",""];
keys[158] = ["�",""];
keys[159] = ["�",""];
keys[160] = ["",""];
keys[161] = ["�",""];
keys[162] = ["�",""];
keys[163] = ["�",""];
keys[164] = ["�",""];
keys[165] = ["�",""];
keys[166] = ["�",""];
keys[167] = ["�",""];
keys[168] = ["�",""];
keys[169] = ["�",""];
keys[170] = ["�",""];
keys[171] = ["�",""];
keys[172] = ["�",""];
keys[173] = ["�",""];
keys[174] = ["�",""];
keys[175] = ["�",""];
keys[176] = ["�",""];
keys[177] = ["�",""];
keys[178] = ["�",""];
keys[179] = ["�",""];
keys[180] = ["�",""];
keys[181] = ["�",""];
keys[182] = ["�",""];
keys[183] = ["�",""];
keys[184] = ["�",""];
keys[185] = ["�",""];
keys[186] = ["�",""];
keys[187] = ["�",""];
keys[188] = ["�",""];
keys[189] = ["�",""];
keys[190] = ["�",""];
keys[191] = ["�",""];
keys[192] = ["�",""];
keys[193] = ["�",""];
keys[194] = ["�",""];
keys[195] = ["�",""];
keys[196] = ["�",""];
keys[197] = ["�",""];
keys[198] = ["�",""];
keys[199] = ["�",""];
keys[200] = ["�",""];
keys[201] = ["�",""];
keys[202] = ["�",""];
keys[203] = ["�",""];
keys[204] = ["�",""];
keys[205] = ["�",""];
keys[206] = ["�",""];
keys[207] = ["�",""];
keys[208] = ["�",""];
keys[209] = ["�",""];
keys[210] = ["�",""];
keys[211] = ["�",""];
keys[212] = ["�",""];
keys[213] = ["�",""];
keys[214] = ["�",""];
keys[215] = ["�",""];
keys[216] = ["�",""];
keys[217] = ["�",""];
keys[218] = ["�",""];
keys[219] = ["�",""];
keys[220] = ["�",""];
keys[221] = ["�",""];
keys[222] = ["�",""];
keys[223] = ["�",""];
keys[224] = ["�",""];
keys[225] = ["�",""];
keys[226] = ["�",""];
keys[227] = ["�",""];
keys[228] = ["�",""];
keys[229] = ["�",""];
keys[230] = ["�",""];
keys[231] = ["�",""];
keys[232] = ["�",""];
keys[233] = ["�",""];
keys[234] = ["�",""];
keys[235] = ["�",""];
keys[236] = ["�",""];
keys[237] = ["�",""];
keys[238] = ["�",""];
keys[239] = ["�",""];
keys[240] = ["�",""];
keys[241] = ["�",""];
keys[242] = ["�",""];
keys[243] = ["�",""];
keys[244] = ["�",""];
keys[245] = ["�",""];
keys[246] = ["�",""];
keys[247] = ["�",""];
keys[248] = ["�",""];
keys[249] = ["�",""];
keys[250] = ["�",""];
keys[251] = ["�",""];
keys[252] = ["�",""];
keys[253] = ["�",""];
keys[254] = ["�",""];
keys[255] = ["�",""];
keys[256] = ["F1", 0x70];
keys[257] = ["F2", 0x71];
keys[258] = ["F3", 0x72];
keys[259] = ["F4", 0x73];
keys[260] = ["F5", 0x74];
keys[261] = ["F6", 0x75];
keys[262] = ["F7", 0x76];
keys[263] = ["F8", 0x77];
keys[264] = ["F9", 0x78];
keys[265] = ["F10",0x79];
keys[266] = ["F11",0x7a];
keys[267] = ["F12",0x7b];
keys[268] = ["Esc",0x1b];
keys[269] = ["Tab",0x09];
keys[270] = ["End",0x23];
keys[271] = ["Enter",0x0d];
keys[272] = ["Home",0x24];
keys[273] = ["Page Up",0x21];
keys[274] = ["Page Down",0x22];
keys[275] = ["Insert",0x2d];
keys[276] = ["Delete",0x2e];
keys[277] = ["Num Lock",0x90];
keys[278] = ["Caps Lock",0x14];
keys[279] = ["Scroll Lock",0x91];
keys[280] = ["Print screen",0x2c];
keys[281] = ["Pause",0x13];
keys[282] = ["Middle Mouse",0x04];
keys[283] = ["Shift",0x10];
keys[284] = ["Ctrl",0x11];
keys[285] = ["Alt",0x12];
keys[286] = ["Win",0x5c];
keys[287] = ["Left",0x25];
keys[288] = ["Right",0x27];
keys[289] = ["Up",0x26];
keys[290] = ["Down",0x28];
keys[291] = ["Media",0xb5];
keys[292] = ["Play Pause",0xb3];
keys[293] = ["Next track",0xb0];
keys[294] = ["Previous track",0xb1];
keys[295] = ["Stop",0xb2];
keys[296] = ["Mode change",0x1f];
keys[297] = ["Volume up",0xaf];
keys[298] = ["Volume down",0xae];
keys[299] = ["Volume mute",0xad];
keys[300] = ["Browser Back",0xa6];
keys[301] = ["Browser Forward",0xa7];
keys[302] = ["Browser Favorites",0xab];
keys[303] = ["Browser Home",0xac];
keys[304] = ["Browser Refresh",0xa8];
keys[305] = ["Browser Search",0xaa];
keys[306] = ["Browser Stop",0xa9];

//http://www.kbdedit.com/manual/low_level_vk_list.html


var baseKeypadWidget = null;
var wsh = new ActiveXObject('WScript.Shell');
var setting_optionsmenu_item = 0;
var shiftKeyActive = false;
var controlKeyActive = false;
var altKeyActive = false;
var winKeyActive = false;
var ZoomIt = resourcesPath + "\\ZoomIt.exe";
var nirCmdPath = resourcesPath + "\\nircmd.exe";
var resizePath = resourcesPath + "\\PhotoResize.exe";
var zoomModeActive = false;
var stdZoomActive = false;
var liveZoomActive = false;
var penModeActive = false;
var penTextModeActive = false;
var timerModeActive = false;
var scrollModeActive = false;
var recentDataPaths;
var recentDataNames;
var browsePath = "";
var stdZoomKeyDefault = "Ctrl + &";
var liveZoomKeyDefault = "Ctrl + �";
var drawZoomKeyDefault = "Ctrl + \"";
var breakZoomKeyDefault = "Ctrl + \'";
var stdZoomKey = stdZoomKeyDefault;
var liveZoomKey = liveZoomKeyDefault;
var drawZoomKey = drawZoomKeyDefault;
var breakZoomKey = breakZoomKeyDefault;

// Read settings for this script
try {
	try {
		var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
		if( settingsFileStream == null ) {
			writeSettings();
			settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
		}
	} catch (e) {
			writeSettings();
			settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	}
	var recentDataPathLoop = false;
	while( true ) {
		var propertyName = settingsFileStream.ReadLine();
		if( propertyName == "browser_path" ) {
			var propertyValue = settingsFileStream.ReadLine();
			browsePath = propertyValue;
		} else if (propertyName == "recent_data_path") {
			recentSwfPathLoop = false;
			recentDataPathLoop = true;
			cleanRecentDataFiles();
		} else if (propertyName == "std_zoom_key") {
			var propertyValue = settingsFileStream.ReadLine();
			stdZoomKey = propertyValue;
		} else if (propertyName == "live_zoom_key") {
			var propertyValue = settingsFileStream.ReadLine();
			liveZoomKey = propertyValue;
		} else if (propertyName == "draw_zoom_key") {
			var propertyValue = settingsFileStream.ReadLine();
			drawZoomKey = propertyValue;
		} else if (propertyName == "break_zoom_key") {
			var propertyValue = settingsFileStream.ReadLine();
			breakZoomKey = propertyValue;
		} else if (recentDataPathLoop == true) {
			addRecentDataFile(propertyName);
		}
	}
} catch( e ) {
} finally {
	if( settingsFileStream != null ) settingsFileStream.Close();	
}
function cleanRecentDataFiles() {
	recentDataPaths = new Array();
	recentDataNames = new Array();
	recentDataPaths.push("");
	recentDataNames.push("Wis recente bestandslijst");
}
function addRecentDataFile(filePath) {
	recentDataPaths.push(filePath);
	recentDataNames.push(fso.GetFileName( filePath ));
}
function writeSettings() {
	try {
		//create clean settings file
		var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );	// overwrite
		settingsFileStream.WriteLine( "browser_path" );
		settingsFileStream.WriteLine( browsePath );
		settingsFileStream.WriteLine( "std_zoom_key" );
		settingsFileStream.WriteLine( stdZoomKey );
		settingsFileStream.WriteLine( "live_zoom_key" );
		settingsFileStream.WriteLine( liveZoomKey );
		settingsFileStream.WriteLine( "draw_zoom_key" );
		settingsFileStream.WriteLine( drawZoomKey );
		settingsFileStream.WriteLine( "break_zoom_key" );
		settingsFileStream.WriteLine( breakZoomKey );
		settingsFileStream.WriteLine( "recent_data_path" );
		if (recentDataPaths != null) {
			for (var i = 1; i < recentDataPaths.length; i++) {
				settingsFileStream.WriteLine( recentDataPaths[i] );
			}
		}
		settingsFileStream.Close();
	} catch (e) {
			var errPopup = CreatePopupDialog( "");
			errPopup.textualContent = e.message;
			theTerminal.Push(errPopup);	
	}	finally {
		if (settingsFileStream != null) {
				settingsFileStream.Close();
		}
	}
}

launchWidget();

var leftDown = false;
var rightDown = false;
var leftLocked = false;
var rightLocked = false;
var acceleration_factor = 1;

function launchWidget() {
	showKeypad();
	var helper = new ActiveXObject("SCHelper.SECHelper");
	if (! helper.IsProcessRunning("ZoomIt.exe")) {
			ShowMessage("Launching ZoomIt\n" + "\"" + ZoomIt + "\"");	
			wsh.Run( "\"" + ZoomIt + "\"" ),1;
			wsh.Quit;
	}
}
function showKeypad() {
	baseKeypadWidget = CreateKeypadScreen( "baseKeypadWidget_" );
	baseKeypadWidget.name="baseKeypadWidget_";
	baseKeypadWidget.title = "myT Mouse Keyboard";
	DateDisplay();
	row0 = baseKeypadWidget.CreateRow(dateDisplayString, scCenter, scClip, scSmall);
	if( theTerminal.supportsPen ) {
		row1 = baseKeypadWidget.CreateRow("Screen: trackpad - Menu: right-click\nHelp (?): options", scCenter, scWrap, scSmall);
	} else {
		row1 = baseKeypadWidget.CreateRow("Use the directional controls.", scCenter, scWrap, scSmall);
	}
	baseKeypadWidget.sendsPenEvents = true;
	baseKeypadWidget.keyRepeatInterval = 0.01;
	baseKeypadWidget.keyRepeatDelay = 0.2;
	
	row2 = baseKeypadWidget.CreateRow("", scCenter, scWrap, scSmall);
	row3 = baseKeypadWidget.CreateRow("", scCenter, scWrap, scLarge);
	row4 = baseKeypadWidget.CreateRow("", scCenter, scWrap, scSmall);
	row5 = baseKeypadWidget.CreateRow("", scLeft, scWrap, scSmall);
	theTerminal.Push(baseKeypadWidget);
}

function baseKeypadWidget_Exit(theScreen)
{
	if( leftDown ) {
		leftDown = false;
		SendMouseEvent(0, 0, 0, 1, 0);
	}
	if( rightDown ) {
		rightDown = false;
		SendMouseEvent(0, 0, 0, 0, 1);
	}
}

function showHistory(pressedButton, printButton) {
	row3text = "";
	row5text = row5.textualContent;
	if (shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
		row3text += (shiftKeyActive ? "Shift " : "") + (controlKeyActive ? "Ctrl " : "") + (altKeyActive ? "Alt " : "") + (winKeyActive ? "Win " : "") + "+ ";
	}
	if (pressedButton == " ") {
		row3text += "<space>";
	} else {		
		row3text += pressedButton;
	}
	if (printButton) {
		if (pressedButton == "<backspace>") {
			if(row5text.length > 0)
			{
				row5text = row5text.slice(0, row5.textualcontent.length - 1);
			}
		} else if (pressedButton == "<enter>") {
			row5text += "\n";
		} else if (pressedButton == "<scroll>") {
			
		} else {
			row5text += pressedButton;
		}
	} else {
		row5text = "";
	}
	row3.textualContent = row3text;
	if (shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
		row5.textualContent = "";
	}
	else {
		row5.textualContent = row5text;
	}	
}

function DateDisplay() {
   d = new Date();
   day = d.getDay();
   var weekDays=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
   dateDisplayString = weekDays[day] + " ";
   dateDisplayString += d.getDate() + "/";
   dateDisplayString += (d.getMonth() + 1) + "/";
   dateDisplayString += d.getYear() + " ";
   time = d.getHours();
   minu = d.getMinutes();
   sec = d.getSeconds();
   if (time < 10)
   {
      dateDisplayString += "0" + time;
   }
   else {
      dateDisplayString += time;
   }
   if (minu < 10)
   {
      dateDisplayString += ":0" + minu;
   }
   else
   {
      dateDisplayString += ":" + minu;
   }
   if (sec < 10)
   {
      dateDisplayString += ":0" + sec;
   }
   else
   {
      dateDisplayString += ":" + sec;
   }
}

function baseKeypadWidget_Update(theScreen) {
	DateDisplay();
	row0.textualContent = dateDisplayString;
}

function clearDeviceHomeScreen() {
	row2.textualContent = "";
	row3.textualContent = "";
	row4.textualContent = "";
	row5.textualContent = "";
	baseKeypadWidget.image = "";	
	theTerminal.PopTo("baseKeypadWidget_");
	return true;
}

function baseKeypadWidget_KeyDown(theScreen, theKey)
{
	 //  SendvirtualKeystroke (Code, Shift, Ctrl, Alt, Win)
	if (scrollModeActive && handleKeyMove( theKey )) {
		showHistory("<scroll>", true);
	} else if ( theKey == "^" ) { 
      //  Up
      SendVirtualKeystroke( 0x26, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );
      showHistory("<up>", false);
   } else if( theKey == "v" ) { 
      //  Down
      SendVirtualKeystroke( 0x28, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );
      showHistory("<down>", false);
   } else if( theKey == "<" ) { 
      //  Left
      SendVirtualKeystroke( 0x25, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive ); 
      showHistory("<left>", false);
   } else if( theKey == ">" ) { 
      //  Right
      SendVirtualKeystroke( 0x27, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive ); 
      showHistory("<right>", false);
   } else if( theKey == "0x0008" ) { 
      //  Backspace
      SendVirtualKeystroke( 0x08, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );
      showHistory("<backspace>", true);
   } else if( theKey == "0x002e" ) { 
      //  Delete
      SendVirtualKeystroke( 0x2e, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );
      showHistory("<delete>", false);
   } else if( theKey == "s" ) { 
      //  Enter
      SendVirtualKeystroke( 0x0d, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );
      showHistory("<enter>", true);
   } else if( theKey == "0x0009" ) { 
      //  Tab
      SendVirtualKeystroke( 0x09, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );  
      showHistory("<tab>", false);
   } else if( theKey == "0x0020" ) { 
      //  space
      SendVirtualKeystroke( 0x20, shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive );  
      showHistory(" ", true);
   } else  if ( theKey == "f") {
   		if (penTextModeActive) {
   			switchPenTextMode(false);
   		} else if (stdZoomActive) {
   			switchStandardZoomMode();
   		} else if (timerModeActive) {
   			switchTimerMode();
   		}
			//Left Click
			if( ! rightDown ) {
				rightDown = true;
			  // SendMouseEvent( X , Y , Scroll, Right , Left)
			  SendMouseEvent(0, 0, 0, 0, -1);
			  showHistory("<mouse>", false);
			}		
			if ( rightLocked ) {
				SendMouseEvent(0, 0, 0, 1, 0);
				rightLocked = false;
				rightDown = false;
				ShowMessage("Right button unlocked");			
			  	showHistory("<mouse>", false);
			}
			if ( leftLocked ) {
				SendMouseEvent(0, 0, 0, 1, 0);
				leftLocked = false;
				leftDown = false;
				ShowMessage("Left button unlocked");			
			 	showHistory("<mouse>", false);
			}
	} else if (theKey == ":help" || theKey == "#") {
		//see keyup actions
	} else {
		if (theKey.length == 3) {
			sendText(theKey.charAt(1));
		} else {
			sendText(theKey);
		}
		if(shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
  		ShowMessage((shiftKeyActive ? " Shift " : "") + (controlKeyActive ? " Ctrl " : "") + (altKeyActive ? " Alt " : "") + (winKeyActive ? " Win " : "") + "\n" + theKey.charAt(1));
  	}
	}
}

function baseKeypadWidget_KeyRepeat(theScreen, theKey)
{
	if( handleKeyMove( theKey ) ) {
		acceleration_factor += 0.05;
		return;
	}
	if( theKey == "s" || theKey == "5" ) {
		if( leftDown && ! leftLocked ) {
			leftLocked = true;
			ShowMessage("Left button locked");			
			showHistory("<mouse>", false);
		}
	} else if( theKey == "f" || theKey == "0" ) {
		if( rightDown && ! rightLocked ) {
			rightLocked = true;
			ShowMessage("Right button locked");			
			showHistory("<mouse>", false);
		}
	} 
}

function baseKeypadWidget_KeyUp(theScreen, theKey)
{
	acceleration_factor = 1;
	if( theKey == "s" || theKey == "5" ) {
		if( leftDown && ! leftLocked ) {
			leftDown = false;
			SendMouseEvent(0, 0, 0, 1, 0);
			showHistory("<mouse>", false);
		}
	} else if( theKey == "f" || theKey == "0" ) {
		if( rightDown && ! rightLocked ) {
			rightDown = false;
			SendMouseEvent(0, 0, 0, 0, 1);
			showHistory("<mouse>", false);
		}
	} else if (theKey == ":help" || theKey == "#") {
		if( theTerminal.supportsPen ) {
			if (penModeActive) {
				showPenMenu();
			} else if (timerModeActive) {
				showTimerMenu();
			} else if (zoomModeActive) {
				showZoomItMenu();
			} else {
				showMenu();
			}
		} else {
			showHelp();
		}
	}
}

function baseKeypadWidget_PenTap(theScreen)
{
	if( leftLocked ) {
		SendMouseEvent(0, 0, 0, 1, 0);
		leftLocked = false;
		leftDown = false;
		ShowMessage("Left button unlocked");
		showHistory("<mouse>", false);			
	} else {
		if( ! leftDown ) {
			SendMouseEvent(0, 0, 0, -1, 0);
		}
		SendMouseEvent(0, 0, 0, 1, 0);
		showHistory("<mouse>", false);
		leftDown = false;
	}
}

function baseKeypadWidget_PenLock(theScreen)
{
	if( ! leftDown && ! leftLocked ) {
		SendMouseEvent(0, 0, 0, -1, 0);
		leftDown = true;
		leftLocked = true;
		ShowMessage("Left button locked");	
		showHistory("<mouse>", false);		
	}
}

function accelerate(v)
{
	if( v > 8 || v < -8 ) {
		return v*2.4
	} else if( v > 6 || v < -6 ) {
		return v*1.9
	} else if( v > 4 || v < -4 ) {
		return v*1.5
	} else if( v > 2 || v < -2 ) {
		return v*1.2
	}
	return v;
}

function baseKeypadWidget_PenMove(theScreen, dx, dy)
{
	dx = accelerate(dx);
	dy = accelerate(dy);
	SendMouseEvent(dx, dy, 0, 0, 0);
}

// Scrolling//
function handleKeyMove( theKey )
{
	var dx = 0;
	var dy = 0;
	var scroll = 0;
	
	if( theTerminal.supportsPen ) {
		if( theKey == ">" || theKey == "6" ) {
			dx = 1;
		} else if( theKey == "<" || theKey == "4" ) {
			dx = -1;
		} else if( theKey == "v" || theKey == "d" || theKey == "8" ) {
			scroll = -1;
		} else if( theKey == "^" || theKey == "u" || theKey == "2" ) {
			scroll = 1;
		} else if( theKey == "1" ) {
			dx = -1;
			dy = -1;
		} else if( theKey == "3" ) {
			dx = 1;
			dy = -1;
		} else if( theKey == "7" ) {
			dx = -1;
			dy = 1;
		} else if( theKey == "9" ) {
			dx = 1;
			dy = 1;
		} else {
			return false;
		}
	} else {
		if( theKey == ">" || theKey == "6" ) {
			dx = 1;
		} else if( theKey == "<" || theKey == "4" ) {
			dx = -1;
		} else if( theKey == "v" || theKey == "d" || theKey == "8" ) {
			dy = 1;
		} else if( theKey == "^" || theKey == "u" || theKey == "2" ) {
			dy = -1;
		} else if( theKey == "1" ) {
			dx = -1;
			dy = -1;
		} else if( theKey == "3" ) {
			dx = 1;
			dy = -1;
		} else if( theKey == "7" ) {
			dx = -1;
			dy = 1;
		} else if( theKey == "9" ) {
			dx = 1;
			dy = 1;
		} else {
			return false;
		}
	}
	
	if( dx != 0 || dy != 0 ) {
		SendMouseEvent(dx*acceleration_factor, dy*acceleration_factor, 0, 0, 0);
	}
	if( scroll != 0 ) {
		SendMouseEvent(0, 0, scroll, 0, 0);
	}
	
	return true;
}

function createBrowser() {
	browserObject = new ActiveXObject("InternetExplorer.Application");
	browserObject.Statusbar = false;
	//browserObject.FullScreen = true; switch with fullScreenBrowser function, F11
	browserObject.Toolbar = true;
	browserObject.Visible = true;
	browserObject.Statusbar = false;
}


function activateBrowser() {
	var helper = new ActiveXObject("SCHelper.SECHelper");
	findWindowTimeout = 100;
	var browserWindow = 0;
	for (var i = 0; i < findWindowTimeout; i++) {
		browserWindow = FindWindow( browserClass, "");
		if( browserWindow != 0 ) {
			break;
		}		
	}
	if (browserWindow != 0) {
		ActivateWindow(browserWindow);
		return browserWindow;
	} else {
		browserObject = new ActiveXObject("InternetExplorer.Application");
	  browserObject.Visible = true;
	  return FindWindow( browserClass, "");
	}
}

function closeBrowser() {
	var closeBrowserWidget = CreateQuestionDialog( "closeConfirmation_");
	closeBrowserWidget.textualContent = "Close " + browserName + "?";
	theTerminal.Push(closeBrowserWidget);
}
function fullScreenBrowser() {
	activateBrowser();
	SendVirtualKeystroke(0x7a,false,false,false,false); //F11	
}


function closeConfirmation_OK(w) {
	try {
		if (browserObject != null) {
			browserObject.quit;
		} else {
			browserWindow = activateBrowser();
			SendVirtualKeystroke(0x73,false,false,true,false); //Alt + F4
		}
	} catch (e) {
		browserWindow = activateBrowser();
		SendVirtualKeystroke(0x73,false,false,true,false); //Alt + F4
		browserOjbect = null;
	}
}

function openLink() {
		var openLinkField = CreateTextFieldDialog( "openLink_");
		
		openLinkField.name = "openLink_";
		openLinkField.maxLength = 500;
		openLinkField.prompt = "Link to open:";
		openLinkField.value = "";  
		
		theTerminal.Push(openLinkField); 
}

function openLink_OK(textfield) {
	if (browserObject == null) {
		browserWindow = activateBrowser();
		SendVirtualKeystroke(0x44, false, false, true, false); //alt + d
		sendText(textfield.value,true);
		SendVirtualKeystroke(0x0d, false, false, false, false); //enter
		theTerminal.PopTo("baseKeypadWidget_");
	} else {
		browserObject.Navigate(textfield);
	}
}

function openLink_Cancel(textfield) {
}

function getFolderItems(filterTypes) {
//filterTypes example: ".ppt" or ".ppt;.pps"
	var items = new Array();
	
	if( browsePath == "" ) {
		// Open Presentation
		var e = new Enumerator( fso.Drives );
		for( ; !e.atEnd(); e.moveNext() ) {
			var x = e.item();
			items.push( x.DriveLetter + ":" );
		}        
	} else {
		items.push(".. (" + browsePath + "\\..)");
		
	    var folder = null;
	    try {
			folder = fso.GetFolder( browsePath );
	    } catch( e ) {
			browsePath = "";
			return getFolderItems(filterTypes);
	    }
	    
		var e = new Enumerator( folder.SubFolders );
		for( ; !e.atEnd(); e.moveNext() ) {
			var x = e.item();
			items.push(x.Name);
		}        
	    
		e = new Enumerator( folder.files );
		var filterTypesArray = null;
		if (filterTypes != null && filterTypes.indexOf(";") > -1) {
			filterTypesArray = filterTypes.split(";");
		}
		for( ; !e.atEnd(); e.moveNext() ) {
			var file = e.item();
			var filename = file.Name;
			var fileext4 = filename.slice( filename.lastIndexOf(".")).toLowerCase();
			if (filterTypesArray != null) {
				for (var filterTypesArrayCounter = 0; filterTypesArrayCounter < filterTypesArray.length; filterTypesArrayCounter++) {
					if (filterTypesArray[filterTypesArrayCounter] == fileext4) {
						items.push( file.Name );
					}
				}
			} else if(filterTypes == null || filterTypes == "" || fileext4 == filterTypes) {
				items.push( file.Name );
			}
		}    
	}
	
	return items;
}


function showDataMenu() {
		var optionList = CreateOptionListDialog( "menuOpenData_");
		optionList.title = "Open file";
	if( recentDataPaths.length == 1 ) {
		//no recent history, only clear history element
		optionList.itemLabels = new Array("Navigate to folder", "Favorite locations");
	} else {
		optionList.itemLabels = new Array("Recently used", "Navigate to folder", "Favorite locations");
	}
	optionList.value = 0;
	theTerminal.Push(optionList);	
}
function menuOpenData_OK(theScreen) {
	if( recentDataPaths.length == 1 ) {
		if( theScreen.value == 0 ) {
			menuDataBrowser();
		} else if (theScreen.value == 1) {
			menuDataFavoriteLocationsBrowser();
		}
	} else {
		if( theScreen.value == 0 ) {
			showRecentDataFileSelector();
		} else if (theScreen.value == 1) {
			menuDataBrowser();
		} else if (theScreen.value == 2) {
			menuDataFavoriteLocationsBrowser();
		}
	}
}

function menuDataFavoriteLocationsBrowser() {
	var browser = CreateListScreen( "dataFavoriteLocationsBrowser_");	
	browser.name = "Favorite locations";
	browser.title = "Favorite locations";        
	browser.selectedItem = 0;
	browser.itemLabels = favoriteLocationNames;
  theTerminal.Push( browser );
}
function dataFavoriteLocationsBrowser_ValueUpdated(browser, property) {
	//ShowMessage("BrowsePath: " + favoriteLocationPaths[browser.selectedItem]);
	browsePath = favoriteLocationPaths[browser.selectedItem];
	theTerminal.PopTo("dataFavoriteLocationsBrowser_");
	menuDataBrowser();
}

function menuDataBrowser() {
	var browser = CreateListScreen( "dataBrowser_");	
	browser.name = "Navigate";
	browser.title = "Navigate";        
	browser.selectedItem = 0;
	browser.itemLabels = getFolderItems();
  theTerminal.Push( browser );
}
function dataBrowser_ValueUpdated(browser, property) {
		var pathItem = "";
		if (browser.selectedItem == 0 && (browser.itemLabels[browser.selectedItem]).slice(0,2) == "..") {
			pathItem = "..\\";
		} else {
    	pathItem = browser.itemLabels[browser.selectedItem] + "\\";
    }

    var newPath = fso.BuildPath( browsePath, pathItem );
    newPath = fso.GetAbsolutePathName( newPath );
    if( newPath == browsePath ) {
			newPath = "";
    }
    
    if( fso.FileExists( newPath ) ) {
	  	addRecentDataFile(newPath);
	  	writeSettings();
      openDataFile(newPath);
	  	theTerminal.PopTo("optionsMenu_");
      return false;
    } else {
      // Selected a folder
      browsePath = newPath;
			writeSettings();
    }
    
    browser.itemLabels = getFolderItems();
    browser.selectedItem = 0;
    
    // Don't pop browser from stack
    return true;
}

function showRecentDataFileSelector() {
	var recentList = CreateListScreen( "recentDataFiles_");
	recentList.title = "Select a recent file";        
	recentList.itemLabels = recentDataNames;
	theTerminal.Push( recentList );
}
function recentDataFiles_ValueUpdated(theScreen, property) {
	try
	{
		if (theScreen.selectedItem == 0) {
			cleanRecentDataFiles();
			writeSettings();				
			theTerminal.PopTo("optionsMenu_");
			return false;
		} else {
			openDataFile(recentDataPaths[theScreen.selectedItem]);
			return false;
		}
	} catch( e )
	{
		var errPopup = CreatePopupDialog( "");
		errPopup.textualContent = e.message;
		theTerminal.Push(errPopup);	
		browserObject == null;
	}
	return true;
}

function openDataFile(fullPath) {
	var wsh = new ActiveXObject('WScript.Shell');
	wsh.Run( "\"" + fullPath + "\"" ),1;
	wsh.Quit;
}


function showZoomItMenu()
{
	//theTerminal.PopTo("baseKeypadWidget_");
	var zoomitMenu = CreateListScreen( "zoomitMenu_");
	zoomitMenu.name = "zoomitMenu_";
	zoomitMenu.title = "ZoomIt";
	zoomitMenu.selectedItem = 0;
	zoomitMenu.itemLabels = zoomMenuItems;
	theTerminal.Push( zoomitMenu );
}


function zoomitMenu_ValueUpdated(theScreen, theProperty)
{
/*
	zoomMenuItems[0] = "Zoom In";
	zoomMenuItems[1] = "Zoom Out";
	zoomMenuItems[2] = "Enable Zoom mode (std)";
	zoomMenuItems[3] = "Enable Live Zoom mode";
	zoomMenuItems[4] = "Enable Pen Draw mode";
	zoomMenuItems[5] = "Enable Timer mode";
	zoomMenuItems[6] = "Special keys menu";
	zoomMenuItems[7] = "Send Esc";
	zoomMenuItems[8] = "Key configuration";
*/
//	try {
			if (theScreen.selectedItem == 0) {
				checkAndChangeZoom(1);
			} else if (theScreen.selectedItem == 1) {
				checkAndChangeZoom(-1);
			} else if (theScreen.selectedItem == 2) {
				switchStandardZoomMode();
			} else if (theScreen.selectedItem == 3) {
				switchLiveZoomMode();
			} else if (theScreen.selectedItem == 4) {
				switchPenMode();
			} else if (theScreen.selectedItem == 5) {
				switchTimerMode();
			} else if (theScreen.selectedItem == 6) {
				showMenu();
			} else if (theScreen.selectedItem == 7) {
				SendVirtualKeystroke(0x1b, false, false, false, false ); //esc
			} else if (theScreen.selectedItem == 8) {
				showZoomItKeyConfigurationMenu();
			} 
	//	} catch( e ) {}
}

function showZoomItKeyConfigurationMenu() {
	var keyConfigurationMenuItems = new Array();
	keyConfigurationMenuItems[0] = "Standard zoom: " + stdZoomKey;
	keyConfigurationMenuItems[1] = "Live zoom: " + liveZoomKey;
	keyConfigurationMenuItems[2] = "Draw: " + drawZoomKey;
	keyConfigurationMenuItems[3] = "Break: " + breakZoomKey;
	keyConfigurationMenuItems[4] = "Reset to default keys";
	var keyConfigurationMenu = CreateListScreen( "keyConfigurationMenu_");
	keyConfigurationMenu.name = "keyConfigurationMenu_";
	keyConfigurationMenu.title = "ZoomIt Keys";
	keyConfigurationMenu.selectedItem = 0;
	keyConfigurationMenu.itemLabels = keyConfigurationMenuItems;
	theTerminal.Push( keyConfigurationMenu );
}
function keyConfigurationMenu_ValueUpdated(theScreen, theProperty) {
	//try {
		if (theScreen.selectedItem == 0) {
			setZoomItStandardZoomKey();
		} else if (theScreen.selectedItem == 1) {
			setZoomItLiveZoomKey();
		} else if (theScreen.selectedItem == 2) {
			setZoomItDrawKey();
		} else if (theScreen.selectedItem == 3) {
			setZoomItBreakKey();
		} else if (theScreen.selectedItem == 4) {
			setZoomItDefaultKeys();
		} 
	//} catch( e ) {}
}
function setZoomItStandardZoomKey() {
	var keyField = CreateTextFieldDialog( "getStdZoomKey_");		
	keyField.name = "getStdZoomKey_";
	keyField.maxLength = 20;
	keyField.prompt = "Standard ZoomIt (default: " +stdZoomKeyDefault + "):";
	keyField.value = stdZoomKey;  
	theTerminal.Push(keyField); 
}
function getStdZoomKey_OK(textfield) {
	stdZoomKey = textfield.value;
	writeSettings();
	theTerminal.PopTo("zoomitMenu_");
	showZoomItKeyConfigurationMenu();
}
function setZoomItLiveZoomKey() {
	var keyField = CreateTextFieldDialog( "getLiveZoomKey_");		
	keyField.name = "getLiveZoomKey_";
	keyField.maxLength = 20;
	keyField.prompt = "Live ZoomIt (default: " + liveZoomKeyDefault + "):";
	keyField.value = liveZoomKey;  
	theTerminal.Push(keyField); 
}
function getLiveZoomKey_OK(textfield) {
	liveZoomKey = textfield.value;
	writeSettings();
	theTerminal.PopTo("zoomitMenu_");
	showZoomItKeyConfigurationMenu();
}
function setZoomItDrawKey() {
	var keyField = CreateTextFieldDialog( "getDrawZoomItKey_");		
	keyField.name = "getDrawZoomItKey_";
	keyField.maxLength = 20;
	keyField.prompt = "ZoomIt draw (default: " + drawZoomKeyDefault + "):";
	keyField.value = drawZoomKey;  
	theTerminal.Push(keyField); 
}
function getDrawZoomItKey_OK(textfield) {
	drawZoomKey = textfield.value;
	writeSettings();
	theTerminal.PopTo("zoomitMenu_");
	showZoomItKeyConfigurationMenu();
}
function setZoomItBreakKey() {
	var keyField = CreateTextFieldDialog( "getBreakZoomItKey_");		
	keyField.name = "getBreakZoomItKey_";
	keyField.maxLength = 20;
	keyField.prompt = "ZoomIt break (default: " + breakZoomKeyDefault + "):";
	keyField.value = breakZoomKey;  
	theTerminal.Push(keyField); 
}
function getBreakZoomItKey_OK(textfield) {
	breakZoomKey = textfield.value;
	writeSettings();
	theTerminal.PopTo("zoomitMenu_");
	showZoomItKeyConfigurationMenu();
}
function setZoomItDefaultKeys() {
	stdZoomKey = stdZoomKeyDefault;
	liveZoomKey = liveZoomKeyDefault;
	drawZoomKey = drawZoomKeyDefault;
	breakZoomKey = breakZoomKeyDefault;
	writeSettings();
	theTerminal.PopTo("zoomitMenu_");
	showZoomItKeyConfigurationMenu();
}


function restoreZoomMenu() {
	var stdZoomActive = false;
	var liveZoomActive = false;
	var penModeActive = false;
	var penTextModeActive = false;
	var timerModeActive = false;
	zoomMenuItems[0] = "Zoom In";
	zoomMenuItems[1] = "Zoom Out";
	zoomMenuItems[2] = "Enable Zoom mode (std)";
	zoomMenuItems[3] = "Enable Live Zoom mode";
	zoomMenuItems[4] = "Enable Pen Draw mode";
	zoomMenuItems[5] = "Enable Timer mode";
	zoomMenuItems[6] = "Special keys menu";
	zoomMenuItems[7] = "Send Esc";
	zoomMenuItems[8] = "Key configuration";
}

function switchTimerMode() {
	if (timerModeActive) {
		zoomModeActive = false;
		zoomMenuItems[5] = "Enable Timer mode";
	} else {
		zoomModeActive = true;
		zoomMenuItems[5] = "Disable Timer mode";
	}
	if (timerModeActive) {
	sendSpecialKey("Esc", false, [false,false,false,false]);
  	//SendVirtualKeystroke(0x1b, false, false, false, false ); //esc
	} else {
	sendCombinationKey("Ctrl + \"", false);
  	//SendVirtualKeystroke(0x33, false, true, false, false ); // ctrl + "
	}
	timerModeActive = !timerModeActive;
	theTerminal.PopTo("baseKeypadWidget_");
}

function switchPenMode() {
	if (penModeActive) {
		zoomModeActive = false;
		zoomMenuItems[4] = "Enable Pen Draw mode";
	} else {
		zoomModeActive = true;
		zoomMenuItems[4] = "Disable Pen Draw mode";
	}
	if (stdZoomActive) {
		if (penModeActive) {
			// SendMouseEvent( X , Y , Scroll, Right , Left)
			SendMouseEvent(0, 0, 0, 0, -1); //right click
		} else {
			SendMouseEvent(0, 0, 0, -1, 0); //left click
		}
	} else {
		if (penModeActive) {
	  	sendSpecialKey("Esc", false, [false,false,false,false]);
		//SendVirtualKeystroke(0x1b, false, false, false, false );  //esc
	  	if (penTextModeActive) {
	  		switchPenTextMode(true);
	  	}
		} else {
		sendCombinationKey("Ctrl + �", false);
	  	//SendVirtualKeystroke(0x32, false, true, false, false ); //�
		}
	}
	penModeActive = !penModeActive;
	theTerminal.PopTo("baseKeypadWidget_");
}

function showPenMenu()
{
	//theTerminal.PopTo("baseKeypadWidget_");
	var penMenu = CreateListScreen( "penMenu_");
	penMenu.name = "penMenu_";
	penMenu.title = "Pen Draw Mode";
	penMenu.selectedItem = 0;
	penMenu.itemLabels = penMenuItems;
	theTerminal.Push( penMenu );
}

function penMenu_ValueUpdated(theScreen, theProperty)
{
/*
penMenuItems[0] = "Type text";
penMenuItems[1] = "Undo last drawing";
penMenuItems[2] = "Undo all drawings";
penMenuItems[3] = "Center Pen cursor";
penMenuItems[4] = "Clear screen White";
penMenuItems[5] = "Clear screen Black";
penMenuItems[6] = "Exit Pen mode";
penMenuItems[7] = "Pen Layout menu";
penMenuItems[8] = "Pen Shapes menu";
penMenuItems[9] = "Copy Pen screen";
penMenuItems[10] = "Save Pen screen";
*/
	try {
			if (theScreen.selectedItem == 0) {
				switchPenTextMode(true);
				theTerminal.PopTo("baseKeypadWidget_");
			} else if (theScreen.selectedItem == 1) {
				sendCombinationKey("Ctrl + z", false);
				//SendVirtualKeystroke( 0x5a, false, true, false, false ); //ctrl + Z
				theTerminal.PopTo("baseKeypadWidget_");
			} else if (theScreen.selectedItem == 2) {
				sendSpecialKey("e", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x45, false, false, false, false ); //e
				theTerminal.PopTo("baseKeypadWidget_");
			} else if (theScreen.selectedItem == 3) {
				sendSpecialKey(" ", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x20, false, false, false, false ); //space
				theTerminal.PopTo("baseKeypadWidget_");
			} else if (theScreen.selectedItem == 4) {
				sendSpecialKey("w", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x57, false, false, false, false ); //w
				theTerminal.PopTo("baseKeypadWidget_");
			} else if (theScreen.selectedItem == 5) {
				sendSpecialKey("k", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x4b, false, false, false, false ); //k
				theTerminal.PopTo("baseKeypadWidget_");
			} else if (theScreen.selectedItem == 6) {
				switchPenMode();
			} else if (theScreen.selectedItem == 7) {
				showPenLayoutMenu();
			} else if (theScreen.selectedItem == 8) {
				showPenShapesMenu();
			} else if (theScreen.selectedItem == 9) {
				sendCombinationKey("Ctrl + c", false);
				//SendVirtualKeystroke( 0x43, false, true, false, false ); //ctrl + c
				theTerminal.PopTo("baseKeypadWidget_");
			} else if (theScreen.selectedItem == 10) {
				sendCombinationKey("Ctrl + s", false);
				//SendVirtualKeystroke( 0x53, false, true, false, false ); //ctrl + s
				theTerminal.PopTo("baseKeypadWidget_");
			} 
		} catch( e ) {}
}

function switchPenTextMode(sendKey) {
	if (penTextModeActive) {
		penMenuItems[0] = "Enable Pen Text mode";
  	if (sendKey) {
		sendSpecialKey("Esc", false, [false,false,false,false]);
  		//SendVirtualKeystroke(0x1b, false, false, false, false );  //esc
  	}
	} else {
		penMenuItems[0] = "Disable Pen Text mode";
  	if (sendKey) {
		sendSpecialKey("t", false, [false,false,false,false]);
  		//SendVirtualKeystroke(0x54, false, false, false, false ); //t
  	}
	}
	penTextModeActive = !penTextModeActive;
	theTerminal.PopTo("baseKeypadWidget_");
}

function showPenLayoutMenu()
{
	//theTerminal.PopTo("baseKeypadWidget_");
	var penLayoutMenu = CreateListScreen( "penLayoutMenu_");
	penLayoutMenu.name = "penLayoutMenu_";
	penLayoutMenu.title = "Pen Draw Mode";
	penLayoutMenu.selectedItem = 0;
	penLayoutMenu.itemLabels = penLayoutMenuItems;
	theTerminal.Push( penLayoutMenu );
}

function penLayoutMenu_ValueUpdated(theScreen, theProperty)
{
/*
penLayoutMenuItems[0] = "Wider Pen";
penLayoutMenuItems[1] = "Smaller Pen";
penLayoutMenuItems[2] = "Red Pen";
penLayoutMenuItems[3] = "Green Pen";
penLayoutMenuItems[4] = "Blue Pen";
penLayoutMenuItems[5] = "Orange Pen";
penLayoutMenuItems[6] = "Yellow Pen";
penLayoutMenuItems[7] = "Pink Pen";
*/
	try {
			if (theScreen.selectedItem == 0) {
				changeZoom(1);
			} else if (theScreen.selectedItem == 1) {
				changeZoom(-1);
			} else if (theScreen.selectedItem == 2) {
				sendSpecialKey("r", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x52, false, false, false, false ); //r
			} else if (theScreen.selectedItem == 3) {
				sendSpecialKey("g", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x47, false, false, false, false ); //g
			} else if (theScreen.selectedItem == 4) {
				sendSpecialKey("b", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x42, false, false, false, false ); //b
			} else if (theScreen.selectedItem == 5) {
				sendSpecialKey("o", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x4f, false, false, false, false ); //o
			} else if (theScreen.selectedItem == 6) {
				sendSpecialKey("y", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x59, false, false, false, false ); //y
			} else if (theScreen.selectedItem == 7) {
				sendSpecialKey("p", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x50, false, false, false, false ); //p
			}
		} catch( e ) {}
}


function showPenShapesMenu()
{
	//theTerminal.PopTo("baseKeypadWidget_");
	var penShapesMenu = CreateListScreen( "penShapesMenu_");
	penShapesMenu.name = "penShapesMenu_";
	penShapesMenu.title = "Pen Draw Mode";
	penShapesMenu.selectedItem = 0;
	penShapesMenu.itemLabels = penShapeMenuItems;
	theTerminal.Push( penShapesMenu );
}

function penShapesMenu_ValueUpdated(theScreen, theProperty)
{
/*
penShapeMenuItems[0] = "Draw straight line";
penShapeMenuItems[1] = "Draw rectangle";
penShapeMenuItems[2] = "Draw ellipse";
penShapeMenuItems[3] = "Draw arrow";
penShapeMenuItems[4] = "Cancel special shapes drawing";
*/
	try {
			if (theScreen.selectedItem == 0) {
				SendVirtualKeyDown(0x10);		
				SendMouseEvent(0, 0, 0, -1, 0);
				SendVirtualKeyUp(0x10);		
			} else if (theScreen.selectedItem == 1) {
				SendVirtualKeyDown(0x11);
				SendMouseEvent(0, 0, 0, -1, 0);
				SendVirtualKeyUp(0x11);		
			} else if (theScreen.selectedItem == 2) {
				SendVirtualKeyDown(0x09);
				SendMouseEvent(0, 0, 0, -1, 0);
				SendVirtualKeyUp(0x09);		
			} else if (theScreen.selectedItem == 3) {
				SendVirtualKeyDown(0x10);
				SendVirtualKeyDown(0x11);
				SendMouseEvent(0, 0, 0, -1, 0);
				SendVirtualKeyUp(0x10);
				SendVirtualKeyUp(0x11);
			} else if (theScreen.selectedItem == 4) {
				ClearKeyboardState();
			} 
		} catch( e ) {}
		theTerminal.PopTo("baseKeypadWidget_");
}


function showTimerMenu()
{
	//theTerminal.PopTo("baseKeypadWidget_");
	var timerMenu = CreateListScreen( "timerMenu_");
	timerMenu.name = "timerMenu_";
	timerMenu.title = "Timer Mode";
	timerMenu.selectedItem = 0;
	timerMenu.itemLabels = timerMenuItems;
	theTerminal.Push( timerMenu );
}

function timerMenu_ValueUpdated(theScreen, theProperty)
{
/*
timerMenuItems[0] = "Exit Timer mode";
timerMenuItems[1] = "Increase time";
timerMenuItems[2] = "Decrease time";
timerMenuItems[3] = "Red timer";
timerMenuItems[4] = "Green timer";
timerMenuItems[5] = "Blue timer";
timerMenuItems[6] = "Orange timer";
timerMenuItems[7] = "Yellow timer";
timerMenuItems[8] = "Pink timer";
*/
	try {
			if (theScreen.selectedItem == 0) {
				switchTimerMode();
			} else if (theScreen.selectedItem == 1) {
				sendSpecialKey("Up", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x26, false, false, false, false );//up
			} else if (theScreen.selectedItem == 2) {
				sendSpecialKey("Down", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x28, false, false, false, false );//down
			} else if (theScreen.selectedItem == 3) {
				sendSpecialKey("r", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x52, false, false, false, false ); //r
			} else if (theScreen.selectedItem == 4) {
				sendSpecialKey("g", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x47, false, false, false, false ); //g
			} else if (theScreen.selectedItem == 5) {
				sendSpecialKey("b", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x42, false, false, false, false ); //b
			} else if (theScreen.selectedItem == 6) {
				sendSpecialKey("o", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x4f, false, false, false, false ); //o
			} else if (theScreen.selectedItem == 7) {
				sendSpecialKey("y", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x59, false, false, false, false ); //y
			} else if (theScreen.selectedItem == 8) {
				sendSpecialKey("p", false, [false,false,false,false]);
				//SendVirtualKeystroke( 0x50, false, false, false, false ); //p
			}
		} catch( e ) {}
}


function switchStandardZoomMode() {
	if (penModeActive || timerModeActive) { //escape other mode first
		stdZoomActiveOldState = stdZoomActive;
  	sendSpecialKey("Esc", false, [false,false,false,false]);
  	restoreZoomMenu();
		stdZoomActive = stdZoomActiveOldState;
		ClearKeyboardState();
  }		
	if (liveZoomActive) { //escape other mode first
		stdZoomActiveOldState = stdZoomActive;
  	sendSpecialKey("Esc", false, [false,false,false,false]);
	sendCombinationKey("Ctrl + \'", false);
	//SendVirtualKeystroke(0x34, false, true, false, false );  //ctrl + '
  	restoreZoomMenu();
		stdZoomActive = stdZoomActiveOldState;
  }	
  sendCombinationKey("Ctrl + &", false); 
  //SendVirtualKeystroke(0x31, false, true, false, false );  //ctrl + &
	if (stdZoomActive) {
		zoomModeActive = false;
		ShowMessage("Exit standard Zoom mode");
		zoomMenuItems[2] = "Enable Zoom mode (std)";
	} else {
		zoomModeActive = true;
		ShowMessage("Standard Zoom mode enabled");
		zoomMenuItems[2] = "Disable Zoom mode (std)";
	}
	stdZoomActive = !stdZoomActive;
	theTerminal.PopTo("baseKeypadWidget_");
}

function switchLiveZoomMode() {
	if (stdZoomActive || penModeActive || timerModeActive) { //escape other mode first
		liveZoomActiveOldState = liveZoomActive;
	sendSpecialKey("Esc", false, [false,false,false,false]);
  	//SendVirtualKeystroke(0x1b, false, false, false, false ); //Esc
  	restoreZoomMenu();
  	liveZoomActive = liveZoomActiveOldState;
		ClearKeyboardState();
  }		
  SendVirtualKeystroke(0x34, false, true, false, false ); 
	if (liveZoomActive) {
		zoomModeActive = false;
		ShowMessage("Exit Live Zoom mode");
		zoomMenuItems[3] = "Enable Live Zoom mode";
	} else {
		zoomModeActive = true;
		ShowMessage("Live Zoom mode enabled");
		zoomMenuItems[3] = "Disable Live Zoom mode";
	}
	liveZoomActive = !liveZoomActive;
	theTerminal.PopTo("baseKeypadWidget_");
}

function checkAndChangeZoom(level) {
	if (! stdZoomActive && ! liveZoomActive) {
		switchLiveZoomMode();
	}
	changeZoom(level);
}

function changeZoom(level) {
	if (level == 1) {
		sendCombinationKey("Ctrl + Up", false);
		//SendVirtualKeystroke( 0x26, false, true, false, false ); //ctrl + up
	} else {
		sendCombinationKey("Ctrl + Down", false);
		//SendVirtualKeystroke( 0x28, false, true, false, false ); //ctrl + down
	}
}

function showMenu()
{
	var optionsMenu = CreateListScreen( "optionsMenu_");
	optionsMenu.name = "optionsMenu_";
	optionsMenu.title = "Options";
	optionsMenu.selectedItem = 0;
	optionsMenu.itemLabels = optionsMenuItems;
	theTerminal.Push( optionsMenu );
}

function optionsMenu_ValueUpdated(theScreen, theProperty)
{
	try {
			if (theScreen.selectedItem == 0) {
				showDataMenu();
			} else if (theScreen.selectedItem == 1) {
				showZoomItMenu();
			} else if (theScreen.selectedItem == 2) {
				showLongText();
			} else if (theScreen.selectedItem == 3) {
				switchShift();
			} else if (theScreen.selectedItem == 4) {
				switchCtrl();
			} else if (theScreen.selectedItem == 5) {
				switchAlt();
			} else if (theScreen.selectedItem == 6) {
				switchWin();
			} else if (theScreen.selectedItem == 7) {
				showFkeysMenu();
			} else if (theScreen.selectedItem == 8) {
				showMediaKeysMenu();
			} else if (theScreen.selectedItem == 9) {
				showCombinationMenu();
			} else if (theScreen.selectedItem == 10) {
				showSpecialKeysMenu();
			} else if (theScreen.selectedItem == 11) {
				switchScrollMode();
			} else if (theScreen.selectedItem == 12) {
				return clearDeviceHomeScreen();
			} else if (theScreen.selectedItem == 13) {
				showScreenShot();
			} else if (theScreen.selectedItem == 14) {
				pcClipboardToDevice();
			} else if (theScreen.selectedItem == 15) {
				sendCtrlAltDel();
			} 
		} catch( e ) {}
}

function pcClipboardToDevice() {
	var tfile = localTempFolder + "\\deviceTextToPc.txt";
	var wsh = new ActiveXObject('WScript.Shell');
	var pcClipboardCommand = " clipboard writefile ";
	//ShowMessage("\"" + nirCmdPath + "\"" + pcClipboardCommand + "\"" + tfile + "\" ; ");
	wsh.Run( "\"" + nirCmdPath + "\"" + pcClipboardCommand + "\"" + tfile + "\" ; "),1;
	wsh.Quit;
	var pcClipboardText = "";
	var pcClipboardFileStream;
	for (var waitCounter = 0 ; waitCounter < 50; waitCounter ++) {
		ShowMessage("Please wait");
	}
	try {
		pcClipboardFileStream = fso.OpenTextFile( tfile);
		while(true) {
			//TODO fix
			pcClipboardText += pcClipboardFileStream.Readline();
		}
	} catch (e) {	}
	finally {
		if( pcClipboardFileStream != null ) pcClipboardFileStream.Close();	
	}
	if (pcClipboardText == "") {
		pcClipboardText = "Type text to send to PC clipboard";
	}
	//		var msgbox = CreateMessageboxDialog( "messagebox_");
	//	msgbox.title = "";
	//	msgbox.textualContent =
	var pcClipboard = CreateTextFieldDialog( "pcClipboardField_");		
	pcClipboard.name = "pcClipboardField_";
	pcClipboard.maxLength = 500;
	pcClipboard.prompt = "PC clipboard:";
	pcClipboard.value = pcClipboardText;  
	theTerminal.Push(pcClipboard); 
}
function pcClipboardField_OK(textfield) {
	var tfile = localTempFolder + "\\deviceTextToPc.txt";
	var wsh = new ActiveXObject('WScript.Shell');
	var echoCmd = "cmd /c echo "
	wsh.Run( echoCmd + textfield.value + "> \"" + tfile + "\""),1;
	
	for (var waitCounter = 0 ; waitCounter < 50; waitCounter ++) {
		ShowMessage("Please wait");
	}
	wsh.Quit;
	wsh = new ActiveXObject('WScript.Shell');
	var deviceTextToPcCommand = " clipboard readfile ";
	wsh.Run( "\"" + nirCmdPath + "\"" + deviceTextToPcCommand + "\"" + tfile + "\""),1;
	wsh.Quit;
}

function showScreenShot() {
	var screenshotCommand = " savescreenshot  ";
	var tfile = localTempFolder + "\\screenshot.jpg"
	var wsh = new ActiveXObject('WScript.Shell');
	//ShowMessage("\"" + nirCmdPath + "\"" + screenshotCommand + "\"" + tfile + "\"");
	wsh.Run( "\"" + nirCmdPath + "\"" + screenshotCommand + "\"" + tfile + "\" ; "),1;
	wsh.Quit;
	for (var waitCounter = 0 ; waitCounter < 2000000; waitCounter ++) {
		var wait = 234 % 5;
	}
	for (var waitCounter = 0 ; waitCounter < 50; waitCounter ++) {
		ShowMessage("Please wait");
	}
	var wsh = new ActiveXObject('WScript.Shell');
	var resizeCommand = " -o -w200";
	//ShowMessage("\"" + resizePath + "\"" + resizeCommand + " \"" + tfile + "-W200\"");
	wsh.Run( "\"" + resizePath + "\"" + resizeCommand + " \"" + tfile + "-W200\""),1;
	wsh.Quit;
	for (var waitCounter = 0 ; waitCounter < 50; waitCounter ++) {
		ShowMessage("Please wait");
	}
	try {	
		baseKeypadWidget.imageStyle = scFit;
		baseKeypadWidget.image = tfile;
	} catch (e) {
	}
	showHistory("<loading screenshot>", false);
	theTerminal.PopTo("baseKeypadWidget_");	
}

function switchScrollMode() {
	if (scrollModeActive) {
		ShowMessage("Scroll disabled");
		optionsMenuItems[11] = "Enable Scroll mode";
	} else {
		ShowMessage("Scroll mode enabled");
		optionsMenuItems[11] = "Disable Scroll mode";
	}
	scrollModeActive = !scrollModeActive;
	theTerminal.PopTo("baseKeypadWidget_");
}

function showScrollMenu()
{
/*	
scrollMenuItems[0] = "Scroll Up";
scrollMenuItems[1] = "Scroll Down";
scrollMenuItems[2] = "";
scrollMenuItems[3] = "Mouse Up (quick)";
scrollMenuItems[4] = "Mouse Up";
scrollMenuItems[5] = "Mouse Down (quick)";
scrollMenuItems[6] = "Mouse Down";
scrollMenuItems[7] = "Mouse Left (quick)";
scrollMenuItems[8] = "Mouse Left";
scrollMenuItems[9] = "Mouse Right (quick)";
scrollMenuItems[10] = "Mouse Right";
*/
	var scrollMenu = CreateListScreen( "scrollMenu_");
	scrollMenu.name = "scrollMenu_";
	scrollMenu.title = "Scroll";
	scrollMenu.selectedItem = 0;
	scrollMenu.itemLabels = scrollMenuItems;
	theTerminal.Push( scrollMenu );
}
function scrollMenu_ValueUpdated(theScreen, theProperty)
{
	try {
		if(shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
  		ShowMessage((shiftKeyActive ? " Shift " : "") + (controlKeyActive ? " Ctrl " : "") + (altKeyActive ? " Alt " : "") + (winKeyActive ? " Win " : "") + "\n" + scrollMenuItems[theScreen.selectedItem]);
  	} else {
			ShowMessage(scrollMenuItems[theScreen.selectedItem]);
		}
		showHistory("<" + scrollMenuItems[theScreen.selectedItem] + ">", false);
		if (theScreen.selectedItem == 0) {
			SendMouseEvent(0, 0, 2, 0, 0);
		} else if (theScreen.selectedItem == 1) {
			SendMouseEvent(0, 0, -2, 0, 0);
		} else if (theScreen.selectedItem == 2) {
		} else if (theScreen.selectedItem == 3) {
			SendMouseEvent(0, -11, 0, 0, 0);
		} else if (theScreen.selectedItem == 4) {
			SendMouseEvent(0, -3, 0, 0, 0);
		} else if (theScreen.selectedItem == 5) {
			SendMouseEvent(0, 11, 0, 0, 0);
		} else if (theScreen.selectedItem == 6) {
			SendMouseEvent(0, 3, 0, 0, 0);
		} else if (theScreen.selectedItem == 7) {
			SendMouseEvent(-11, 0, 0, 0, 0);
		} else if (theScreen.selectedItem == 8) {
			SendMouseEvent(-3, 0, 0, 0, 0);
		} else if (theScreen.selectedItem == 9) {
			SendMouseEvent(11, 0, 0, 0, 0);
		} else if (theScreen.selectedItem == 10) {
			SendMouseEvent(3, 0, 0, 0, 0);
		}
		//theTerminal.PopTo("optionsMenu_");
	} catch( e ) {}
}



function showMediaKeysMenu()
{
	var mediakeysMenu = CreateListScreen( "mediakeysMenu_");
	mediakeysMenu.name = "mediakeysMenu_";
	mediakeysMenu.title = "Media keys";
	mediakeysMenu.selectedItem = 0;
	mediakeysMenu.itemLabels = mediakeysMenuItems;
	theTerminal.Push( mediakeysMenu );
}
function mediakeysMenu_ValueUpdated(theScreen, theProperty)
{
	try {
	if(shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
		ShowMessage((shiftKeyActive ? " Shift " : "") + (controlKeyActive ? " Ctrl " : "") + (altKeyActive ? " Alt " : "") + (winKeyActive ? " Win " : "") + "\n" + mediakeysMenuItems[theScreen.selectedItem]);
	} else {
		ShowMessage(mediakeysMenuItems[theScreen.selectedItem]);
	}
	sendSpecialKey(mediakeysMenuItems[theScreen.selectedItem], false);
	} catch( e ) {}
}

function showFkeysMenu()
{
	var fkeysMenu = CreateListScreen( "fkeysMenu_");
	fkeysMenu.name = "fkeysMenu_";
	fkeysMenu.title = "Function keys";
	fkeysMenu.selectedItem = 0;
	fkeysMenu.itemLabels = fkeysMenuItems;
	theTerminal.Push( fkeysMenu );
}
function fkeysMenu_ValueUpdated(theScreen, theProperty)
{
	try {
		if(shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
			ShowMessage((shiftKeyActive ? " Shift " : "") + (controlKeyActive ? " Ctrl " : "") + (altKeyActive ? " Alt " : "") + (winKeyActive ? " Win " : "") + "\n" + fkeysMenuItems[theScreen.selectedItem]);
		} else {
			ShowMessage(fkeysMenuItems[theScreen.selectedItem]);
		}
		sendSpecialKey(fkeysMenuItems[theScreen.selectedItem], false);
	} catch( e ) {}
}

function showSpecialKeysMenu()
{
	var spkeysMenu = CreateListScreen( "spkeysMenu_");
	spkeysMenu.name = "spkeysMenu_";
	spkeysMenu.title = "Special characters";
	spkeysMenu.selectedItem = 0;
	spkeysMenu.itemLabels = specialcharkeysMenuItems;
	theTerminal.Push( spkeysMenu );
}

function spkeysMenu_ValueUpdated(theScreen, theProperty)
{
	try {
		sendText(specialcharkeysMenuItems[ theScreen.selectedItem]);
	} catch( e ) {}
}

function showCombinationMenu() {
	var combinationMenu = CreateListScreen( "combinationMenu_");
	combinationMenu.name = "combinationMenu_";
	combinationMenu.title = "Combinations";
	combinationMenu.selectedItem = 0;
	combinationMenu.itemLabels = combinationMenuItems;
	theTerminal.Push( combinationMenu );
}

var previousKey1 = "";
var previousVK1 = "";
var previousKey2 = "";
var previousVK2 = "";
function combinationMenu_ValueUpdated(theScreen, theProperty)
{
	Selection5 = theScreen.selectedItem;
	if(Selection5 == 0)
	{
		ClearKeyboardState();
		previousKey1 = "";
		previousKey2 = "";
		previousVK1 = "";
		previousVK2 = "";
	}
	else
	{
		TotalName = combinations[Selection5];
		endKey1 = TotalName.indexOf("+");
		endKey2 = TotalName.indexOf("[");
		key1 = new Array( TotalName.slice(0, endKey1 - 1), TotalName.slice(endKey2 + 1, endKey2 + 2));
		key2 = new Array( TotalName.slice(endKey1 + 2, endKey2 - 1), TotalName.slice(endKey2 + 3, endKey2 + 4));
		if ((key1[0] != previousKey1 || (key1[0] == previousKey1 && key1[1] != 2)) && previousKey1 != "")
		{
			SendVirtualKeyUp(previousVK1);
		}
		if ((key2[0] != previousKey2 || (key2[0] == previousKey2 && key2[1] != 2)) && previousKey2 != "")
		{
			SendVirtualKeyUp(previousVK2);
		}
		for(c1 = 32 ; c1 < keys.length ; c1 ++)
		{
			//ShowMessage(key1[0] + " " + keys[c1][0]);
			if(key1[0] == keys[c1][0])
			{
				if(key1[1] == "0")
				{
					SendVirtualKeyStroke(keys[c1][1], false, false, false, false);
				}
				else
				{
					SendVirtualKeyDown(keys[c1][1]);
				}
				break;
			}
		}
		for(c2 = 32 ; c2 < keys.length ; c2 ++)
		{
			if(key2[0] == keys[c2][0])
			{
				if(key2[1] == "0")
				{
					SendVirtualKeyStroke(keys[c2][1], false, false, false, false);
				}
				else
				{
					SendVirtualKeyDown(keyCodesVirtual[c2][1]);
				}
				break;
			}
		}
		if(key1[1] != "2")
		{
			SendVirtualKeyUp(keys[c1][1]);
			previousKey1 = "";
			previousVK1 = "";
		}
		else
		{
			previousKey1 = key1[0];
			previousVK1 = keys[c1][1];
		}
		if(key2[1] != "2")
		{
			SendVirtualKeyUp(keys[c2][1]);
			previousKey2 = "";
			previousVK2 = "";
		}
		else
		{
			previouskey2 = key2[0];
			previousVK2 = keys[c2][1];
		}
	}
}

function showLongText() {
		var textField = CreateTextFieldDialog( "showLongText_");
		
		textField.name = "showLongText_";
		textField.maxLength = 500;
		textField.prompt = "Text to type:";
		textField.value = "";  
		
		theTerminal.Push(textField); 
}

function showLongText_OK(textfield) {
	sendText(textfield.value);
}

function showLongText_Cancel(textfield) {
}

function sendText(textToSend, showHistoryOnScreen) {
	//ShowMessage(textToSend);
	for (var x = 0; x < textToSend.length; x++)
	{
		if (showHistoryOnScreen == null || showHistoryOnScreen) {
			showHistory(textToSend.charAt(x), true);
		}
		for (var y =32; y < keys.length; y++)
		{
			//ShowMessage(keys[y][0]);
			if (textToSend.charAt(x) == (keys[y][0])) {
				if (shiftKeyActive || controlKeyActive || altKeyActive || winKeyActive) {
					if (keys[y][1] == "") {
						SendUnicodeKeystroke(y);
					} else {
						SendVirtualKeystroke(keys[y][1], shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive);
					}
				} else {
					SendUnicodeKeystroke(y);
				}
				break;
			}
		}
	}
}

function sendSpecialKey(keynameToSend, showHistoryOnScreen, forceShiftCtrlAltWin) {
	if (showHistoryOnScreen == null || showHistoryOnScreen) {
		showHistory("<" + keynameToSend + ">", true);
	}
	for(c1 = 32 ; c1 < keys.length ; c1 ++)	{
		if(keynameToSend == keys[c1][0])
		{
			if (forceShiftCtrlAltWin != null && forceShiftCtrlAltWin.length != 0) {
				SendVirtualKeyStroke(keys[c1][1], forceShiftCtrlAltWin[0], forceShiftCtrlAltWin[1], forceShiftCtrlAltWin[2], forceShiftCtrlAltWin[3]);
			} else {
				SendVirtualKeyStroke(keys[c1][1], shiftKeyActive, controlKeyActive, altKeyActive, winKeyActive);
			}
			break;
		}
	}
}
function sendCombinationKey(keysAsString, showHistoryOnScreen) {
	//Style: Ctrl + F4 (first key kept pressed while second is send)
	var key1 = keysAsString.slice(0, (keysAsString.indexOf("+") -1));
	var key2 = keysAsString.slice((keysAsString.indexOf("+") +1));
	//ShowMessage("key1: " + key1 + ", key2: " + key2);
	var c1; //counter 1
	var c2; //counter 2
	for(c1 = 32 ; c1 < keys.length ; c1 ++) {
		//ShowMessage(key1[0] + " " + keys[c1][0]);
		if(key1 == keys[c1][0])
		{
			SendVirtualKeyDown(keys[c1][1]);
			break;
		}
	}
	for(c2 = 32 ; c2 < keys.length ; c2 ++)	{
		if(key2 == keys[c2][0])
		{
			SendVirtualKeyStroke(keys[c2][1], false, false, false, false);
			break;
		}
	}
	SendVirtualKeyUp(keys[c1][1]);
	if (showHistoryOnScreen == null || showHistoryOnScreen) {
		showHistory("<" + keysAsString + ">", true);
	}
}


function sendCtrlAltDel() {
		//  SendvirtualKeystroke (Code, Shift, Ctrl, Alt, Win)
		ShowMessage("Ctrl + Alt + Delete");
		showHistory("<Ctrl + Alt + Delete>", false);
		//SendVirtualKeystroke(0x2e, false, true, true, false);
		SendVirtualKeyDown(0x11); //ctrl
		SendVirtualKeyDown(0x12); //alt
		//SendVirtualKeyDown(0x2e); //del
		//SendVirtualKeyUp(0x2e); //del
		SendVirtualKeystroke(0x2e, false, false, false, false); //del
		SendVirtualKeyUp(0x11); //ctrl
		SendVirtualKeyUp(0x12); //alt
		ClearKeyboardState();
}

function switchShift() {
	if (shiftKeyActive) {
		ShowMessage("Shift key deactivated");
		optionsMenuItems[3] = "Activate Shift key";
	} else {
		ShowMessage("Shift key activated");
		optionsMenuItems[3] = "Deactivate Shift key";
	}
	shiftKeyActive = !shiftKeyActive;
	theTerminal.PopTo("baseKeypadWidget_");
}

function switchCtrl() {
	if (controlKeyActive) {
		ShowMessage("Ctrl key deactivated");
		optionsMenuItems[4] = "Activate Ctrl key";
	} else {
		ShowMessage("Ctrl key activated");
		optionsMenuItems[4] = "Deactivate Ctrl key";
	}
	controlKeyActive = !controlKeyActive;
	theTerminal.PopTo("baseKeypadWidget_");
}

function switchAlt() {
	if (altKeyActive) {
		ShowMessage("Alt key deactivated");
		optionsMenuItems[5] = "Activate Alt key";
	} else {
		ShowMessage("Alt key activated");
		optionsMenuItems[5] = "Deactivate Alt key";
	}
	altKeyActive = !altKeyActive;
	theTerminal.PopTo("baseKeypadWidget_");
}

function switchWin() {
	if (winKeyActive) {
		ShowMessage("Win key deactivated");
		optionsMenuItems[6] = "Activate Win key";
	} else {
		ShowMessage("Win key activated");
		optionsMenuItems[6] = "Deactivate Win key";
	}
	winKeyActive = !winKeyActive;
	theTerminal.PopTo("baseKeypadWidget_");
}

function showHelp()
{
    var code = new Array();
    var title = new Array();
    var description = new Array();
    
    code[0] = new Array("s");
    title[0] = "LeftClick";
    description[0] = "MouseLeftClick. Hold to lock left button.";

    theTerminal.ShowKeypadHelp("Help", code, title, description);    

}