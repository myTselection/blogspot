var widget = CreateQuestionDialog( "confirmation_");
widget.textualContent = "Disconnect?"
theTerminal.Push(widget);

function confirmation_OK(w)
{
	theTerminal.Disconnect();
}
