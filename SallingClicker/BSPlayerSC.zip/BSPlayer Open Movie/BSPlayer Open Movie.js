var browsePath = "";

// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_path = null;

// Read settings for this script
try {
	var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	if( settingsFileStream == null ) {
		// Write defaults
		writeSettings();
		settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	}
	while( true ) {
		var propertyName = settingsFileStream.ReadLine();
		var propertyValue = settingsFileStream.ReadLine();
		if( propertyName == "setting_path" ) {
			browsePath = propertyValue;
		}
	}
} catch( e ) {
} finally {
	if( settingsFileStream != null ) settingsFileStream.Close();	
}


launchBrowser();


function writeSettings()
{
	try {
		var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );	// overwrite
		settingsFileStream.WriteLine( "setting_path" );
		settingsFileStream.WriteLine( browsePath );
		settingsFileStream.Close();
	} catch( e ) {}
}

function launchBrowser()
{
	var browser = CreateListScreen( "browser_");	
	browser.name = "More menu open presentation";
	browser.title = "Select File";        
	browser.selectedItem = 0;
	browser.itemLabels = getFolderItems();
	    
    theTerminal.Push( browser );
}



function browser_ValueUpdated( browser, property )
{
    var path = browser.itemLabels[browser.selectedItem] + "\\";

    var newPath = fso.BuildPath( browsePath, path );
    newPath = fso.GetAbsolutePathName( newPath );
    if( newPath == browsePath ) {
		newPath = "";
    }
    
    if( fso.FileExists( newPath ) ) {
        // Selected a file
		var wsh = new ActiveXObject('WScript.Shell');
		var BSPlayerPath = wsh.RegRead("HKEY_CURRENT_USER\\Software\\BST\\bsplayerv1\\AppPath");
		if( BSPlayerPath != null ) {
			new ActiveXObject("Shell.Application").ShellExecute( BSPlayerPath, "\"" + newPath + "\"" );
		    theTerminal.PopTo( "BSPlayer" );
        }
        return false;
    } else {
        // Selected a folder
        browsePath = newPath;
		writeSettings();
    }
    
    browser.itemLabels = getFolderItems();
    browser.selectedItem = 0;
    
    // Don't pop browser from stack
    return true;
}

function getFolderItems()
{
	var items = new Array();
	
	if( browsePath == "" ) {
		// Open Presentation
		var e = new Enumerator( fso.Drives );
		for( ; !e.atEnd(); e.moveNext() ) {
			var x = e.item();
			items.push( x.DriveLetter + ":" );
		}        
	} else {
		items.push("..");
		
	    var folder = null;
	    try {
			folder = fso.GetFolder( browsePath );
	    } catch( e ) {
			browsePath = "";
			return getFolderItems();
	    }
	    
		var e = new Enumerator( folder.SubFolders );
		for( ; !e.atEnd(); e.moveNext() ) {
			var x = e.item();
			items.push(x.Name);
		}        
	    
		e = new Enumerator( folder.files );
		for( ; !e.atEnd(); e.moveNext() ) {
			var file = e.item();
			var filename = file.Name;
			var fileext4 = filename.substr( filename.lastIndexOf("."), 4 ).toLowerCase();
			var fileext5 = filename.substr( filename.lastIndexOf("."), 5 ).toLowerCase();
			if( fileext4 == ".mpg" || fileext4 == ".avi" || fileext5 == ".mpeg" || fileext5 == ".divx" ) {
				items.push( file.Name );
			}
		}    
	}
	
	return items;
}


