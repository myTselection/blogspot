var WM_BSP_CMD = 0x400+2;
var BSP_SetVol = 0x10104;
var BSP_GetVol = 0x10105;
var BSP_GetStatus = 0x10102;
var BSP_GetMovLen = 0x10100;
var BSP_GetMovPos = 0x10101;
var BSP_Seek = 0x10103;
var BSP_GetFileName = 0x1010B;
var BSP_VolUp = 1;
var BSP_VolDown = 2;
var BSP_Pause = 21;
var BSP_Play = 20;
var BSP_FS_Switch = 10;

var keyRepeated = false;
var sampleRow = null;

// Initialize more menu items

var moreMenuItems = new Array();
moreMenuItems[0] = "Open Movie";

var moreMenuItemUUIDs = new Array();
moreMenuItemUUIDs[0] = "FAF9BF8A-CB5F-4558-9205-98FE963538F2";	// Open Movie




// Check if BSPlayer is installed, and get the exe path if it is.

var BSPlayerPath = null;
try {
	var wsh = new ActiveXObject('WScript.Shell');
	BSPlayerPath = wsh.RegRead("HKEY_CURRENT_USER\\Software\\BST\\bsplayerv1\\AppPath");
} catch( e ) {}

if( BSPlayerPath == null ) {
	var widget = CreatePopupDialog( "" ); // not interested in callbacks
	widget.textualContent = "Cannot find BSPlayer.";
	theTerminal.Push( widget );
	exit();
}

// Check if BSPlayer is launched

var bspwh = 0;
try {
	bspwh = FindWindow( "BSPlayer", "" );
} catch( e ) {
}

if( bspwh == 0 ) {
	var widget = CreateQuestionDialog( "launcher_" );
	widget.textualContent = "Launch BSPlayer?";
	theTerminal.Push( widget );
	exit();
}

launchWidget();
exit();





// Helpers and callbacks

function launchWidget()
{
	var widget = CreateMediaplayerScreen( "mykeypad_" );
	widget.title = "BSPlayer";
	widget.name = "BSPlayer";
	sampleRow = widget.CreateRow( "", scCenter, scWrap, scLarge );
	theTerminal.Push( widget );
}


function launcher_OK(w)
{
	new ActiveXObject("Shell.Application").ShellExecute( BSPlayerPath, "" );
	launchWidget();
}


function mykeypad_Update( theScreen )
{
	try {
	
		var bspwh = 0;
		try {
			bspwh = FindWindow( "BSPlayer", "" );
		} catch( e ) {}

		if( bspwh == 0 ) {
			throw "BSPlayer not launched";
		}
		
		var status = SendMessage( bspwh, WM_BSP_CMD, BSP_GetStatus, 0 );
		if( status == 4 ) {
			throw "No movie open";
		}
		
		switch( status ) {
			case 0:
				theScreen.playerState = scStopped;
				break;
			case 1:
				theScreen.playerState = scPaused;
				break;
			case 2:
				theScreen.playerState = scPlaying;
				break;
		}

		var filename = null;
		try {
			filename = ReceiveStringUsingCopyData( bspwh, BSP_GetFileName, 256 );
		} catch( e ) {
			throw "No movie open";
		}
				
		try {
			var mediaLength = SendMessage( bspwh, WM_BSP_CMD, BSP_GetMovLen, 0 );
			var mediaPos = SendMessage( bspwh, WM_BSP_CMD, BSP_GetMovPos, 0 );

			var volume = SendMessage( bspwh, WM_BSP_CMD, BSP_GetVol, 0 );
			volume = volume * 100 / 25; // normalize to 0-100

			theScreen.listeningVolume = volume;
			theScreen.mediaLength = mediaLength/1000;
			theScreen.mediaPosition = mediaPos/1000;
			if( sampleRow != null ) sampleRow.textualContent = filename;
		} catch( e ) {
			throw "No movie playing";
		}
		
	} catch( e ) {
		if( sampleRow != null ) sampleRow.textualContent = e;
		theScreen.mediaLength = -1;
		theScreen.mediaLength = -1;
		theScreen.playerState = scIndeterminate;
	}
}



function mykeypad_KeyDown( theScreen, theKey )
{	
	try {
		var bspwh = FindWindow( "BSPlayer", "" );
		if( bspwh == 0 ) {
			new ActiveXObject("Shell.Application").ShellExecute( BSPlayerPath, "" );
			throw "null player";
		}

		ActivateWindow( bspwh );
		
		if( theKey == "^" || theKey == "u" ) {
			SendMessage( bspwh, WM_BSP_CMD, BSP_VolUp, 0 );
		} else if( theKey == "v" || theKey == "d" ) {
			SendMessage( bspwh, WM_BSP_CMD, BSP_VolDown, 0 );
		} else if( theKey == ">" ) {
			var mediaLength = SendMessage( bspwh, WM_BSP_CMD, BSP_GetMovLen, 0 );
			var mediaPos = SendMessage( bspwh, WM_BSP_CMD, BSP_GetMovPos, 0 );
			mediaPos += 10 * 1000;
			if( mediaPos < mediaLength ) {
				SendMessage( bspwh, WM_BSP_CMD, BSP_Seek, mediaPos );
			}
		} else if( theKey == "<" ) {
			var mediaLength = SendMessage( bspwh, WM_BSP_CMD, BSP_GetMovLen, 0 );
			var mediaPos = SendMessage( bspwh, WM_BSP_CMD, BSP_GetMovPos, 0 );
			mediaPos -= 10 * 1000;
			if( mediaPos > 0 ) {
				SendMessage( bspwh, WM_BSP_CMD, BSP_Seek, mediaPos );
			}
		}
		
		
	} catch( e ) {}

	keyRepeated = false;

	// Keep the keypad active
	return true;
}



function mykeypad_KeyRepeat( theScreen, theKey )
{	
	try {
		var bspwh = FindWindow( "BSPlayer", "" );
		if( bspwh == 0 ) throw "null player";
				
		if( theKey == "s" && !keyRepeated ) {
			SendMessage( bspwh, WM_BSP_CMD, BSP_FS_Switch, 0 );
		} else if( theKey == "^" || theKey == "u" ) {
			SendMessage( bspwh, WM_BSP_CMD, BSP_VolUp, 0 );
		} else if( theKey == "v" || theKey == "d" ) {
			SendMessage( bspwh, WM_BSP_CMD, BSP_VolDown, 0 );
		} else if( theKey == ">" ) {
			var mediaLength = SendMessage( bspwh, WM_BSP_CMD, BSP_GetMovLen, 0 );
			var mediaPos = SendMessage( bspwh, WM_BSP_CMD, BSP_GetMovPos, 0 );
			mediaPos += 10 * 1000;
			if( mediaPos < mediaLength ) {
				SendMessage( bspwh, WM_BSP_CMD, BSP_Seek, mediaPos );
			}
		} else if( theKey == "<" ) {
			var mediaLength = SendMessage( bspwh, WM_BSP_CMD, BSP_GetMovLen, 0 );
			var mediaPos = SendMessage( bspwh, WM_BSP_CMD, BSP_GetMovPos, 0 );
			mediaPos -= 10 * 1000;
			if( mediaPos > 0 ) {
				SendMessage( bspwh, WM_BSP_CMD, BSP_Seek, mediaPos );
			}
		}
	} catch( e ) {}

	keyRepeated = true;
}


function mykeypad_KeyUp( theScreen, theKey )
{	
	try {
		var bspwh = FindWindow( "BSPlayer", "" );
		if( bspwh == 0 ) throw "null player";

		if( theKey == "s" && ! keyRepeated ) {
			SendMessage( bspwh, WM_BSP_CMD, BSP_Pause, 0 );
		} else if( theKey == "f" ) {
			showMenu();
		} else if (theKey == ":help" || theKey == "#") {
	        showHelp();
		}
	} catch( e ) {}
	
	return true;
}


function mykeypad_ValueUpdated(theScreen, property)
{    
	try {
		var bspwh = FindWindow( "BSPlayer", "" );
		if( bspwh == 0 ) throw "null player";
		
		if (property == 4 /*PlayheadPosition*/ ) {
		// Setting new playhead position from device widget
			SendMessage( bspwh, WM_BSP_CMD, BSP_Seek, theScreen.mediaPosition*1000 );
		}
	} catch( e ) {}
}


function showMenu()
{
	var moreMenu = CreateListScreen( "moreMenu_");
	moreMenu.name = "More menu list";
	moreMenu.title = "More";
	moreMenu.selectedItem = 0;
	moreMenu.itemLabels = moreMenuItems;
	theTerminal.Push( moreMenu );
}


function moreMenu_ValueUpdated(theScreen, theProperty)
{
	try {
		var uuid = moreMenuItemUUIDs[theScreen.selectedItem];
		if( uuid == "quit" ) {
			var bspwh = FindWindow( "BSPlayer", "" );
			if( bspwh == 0 ) throw "null player";
			SendMessage( bspwh, 0x0012, 0, 0 );			
			return false;
		} else if( uuid != "" ) {
			theTerminal.ExecuteScript(moreMenuItemUUIDs[theScreen.selectedItem]);	
			// Force an update of the mediaplayer widget, before the next track starts
			currentSong = null;
			currentAlbum = null;
		}
	} catch( e ) {}
}


function showHelp()
{
    var code = new Array();
    var title = new Array();
    var description = new Array();
    
    code[0] = "s";
    title[0] = "Play/Pause/Full";
    description[0] = "Toggle the player state. Hold to toggle full screen mode.";

    code[1] = new Array("v", "d");
    title[1] = "Volume Down";
    description[1] = "Softens the listening volume.";

    code[2] = new Array("^", "u");
    title[2] = "Volume Up";
    description[2] = "Raises the listening volume.";

    code[3] = new Array("<");
    title[3] = "Rewind";
    description[3] = "Hold to rewind through the currently playing movie.";

    code[4] = new Array(">");
    title[4] = "Fast forward";
    description[4] = "Hold to fast forward through the currently playing movie.";

    code[5] = new Array("f", "*");
    title[5] = "More";
    description[5] = "Other settings and commands";

    theTerminal.ShowKeypadHelp("BSPlayer Help", code, title, description);    
}