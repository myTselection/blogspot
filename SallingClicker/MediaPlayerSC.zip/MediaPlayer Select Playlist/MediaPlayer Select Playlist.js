
var object = null;
var player = null;
var userPlaylists = null;
var audioPlaylists = null;

// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_playlist_item = 0;
var setting_track_item = 0;

// Read settings for this script
try {
	var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	if( settingsFileStream == null ) {
		// Write defaults
		writeSettings();
		settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	}
	while( true ) {
		var propertyName = settingsFileStream.ReadLine();
		var propertyValue = settingsFileStream.ReadLine();
		if( propertyName == "setting_playlist_item" ) {
			setting_playlist_item = parseInt( propertyValue );
		} else if( propertyName == "setting_track_item" ) {
			setting_track_item = parseInt( propertyValue );
		}
	}
} catch( e ) {
} finally {
	if( settingsFileStream != null ) settingsFileStream.Close();	
}



var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("wmplayer.exe")) 
{
    launchWidget();
} 
else 
{
    var launchQuestion = CreateQuestionDialog( "launch_");
    launchQuestion.textualContent = "Launch Media Player?";
    theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
    launchWidget();
}


function writeSettings()
{
	try {
		var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );	// overwrite
		settingsFileStream.WriteLine( "setting_playlist_item" );
		settingsFileStream.WriteLine( setting_playlist_item );
		settingsFileStream.WriteLine( "setting_track_item" );
		settingsFileStream.WriteLine( setting_track_item );
		settingsFileStream.Close();
	} catch( e ) {}
}



function launchWidget()
{
    object = new ActiveXObject("SCWMPlayer.WMPlayerHelper");
    player = object.GetMediaPlayer();
    
    // Playlists
    var playlistCollection = player.playlistCollection;
    var playlists = player.mediaCollection.getByAttribute("MediaType","playlist");    
    var playlistItems = new Array();
    audioPlaylists = new Array();
    for (var i = 0; i < playlists.count; i++)
    {
        var playlist = playlists.item(i);
        var mediaContentTypes  = playlist.getItemInfo("MediaContentTypes");
        if( mediaContentTypes == "" || mediaContentTypes == 1 || mediaContentTypes == 3 ) {
			var playlistArray = playlistCollection.getByName( playlist.name );
			if( playlistArray != null && playlistArray.count > 0 ) {
				try {
					var pl = playlistArray.item(0);
					playlistItems.push( playlist.name );
					audioPlaylists.push( pl );
				} catch( e ) {}
			}
	    }
    }
    
    if (playlistItems.length > 0)
    {
        var list = CreateListScreen( "playlist_");
        
        list.name = "More Menu playlist list";
        list.title = "Select Playlist";
        list.itemLabels = playlistItems;
        list.selectedItem = setting_playlist_item;
        
        theTerminal.Push(list);
    }
}

function playlist_ValueUpdated(theList, theProperty)
{	
	if( setting_playlist_item != theList.selectedItem ) {
		setting_track_item = 0;
		setting_playlist_item = theList.selectedItem;
		writeSettings();
	}

    selectTrackFromListAndPlay(audioPlaylists[theList.selectedItem]);
}

function selectTrackFromListAndPlay(playlist)
{
    savedPlaylist = playlist;
        
    if (playlist != null && playlist.count > 0 )
    {
        var listItems = new Array();
        for (var i = 0; i < playlist.count; i++) {
            listItems.push(playlist.Item(i).name);
        }

        var trackList = CreateListScreen( "playTrack_");
        
        trackList.name = "Select track list";
        trackList.itemLabels = listItems;
        trackList.selectedItem = setting_track_item;
        trackList.title = playlist.name;
       
        theTerminal.Push(trackList);
    }
    else
    {
        var messageBox = CreateMessageboxDialog( "");
        
        messageBox.name = "No tracks found message box";
        messageBox.title = "Clicker";
        messageBox.textualContent = "No tracks found";
        
        theTerminal.Push(messageBox);
    }
}

function playTrack_ValueUpdated(list, theProperty)
{
	if( setting_track_item != list.selectedItem ) {
		setting_track_item = list.selectedItem;
		writeSettings();
	}

    if (savedPlaylist != null)
    {
        var media = savedPlaylist.item(list.selectedItem);

        player.currentPlaylist = savedPlaylist;
        player.controls.playItem(media);
    }   
    
    theTerminal.PopTo("Windows Media Player");
}


