// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_artist_item = 0;
var setting_album_item = 0;
var setting_track_item = 0;

// Read settings for this script
try {
	var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	if( settingsFileStream == null ) {
		// Write defaults
		writeSettings();
		settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	}
	while( true ) {
		var propertyName = settingsFileStream.ReadLine();
		var propertyValue = settingsFileStream.ReadLine();
		if( propertyName == "setting_artist_item" ) {
			setting_artist_item = parseInt( propertyValue );
		} else if( propertyName == "setting_album_item" ) {
			setting_album_item = parseInt( propertyValue );
		} else if( propertyName == "setting_track_item" ) {
			setting_track_item = parseInt( propertyValue );
		}
	}
} catch( e ) {
} finally {
	if( settingsFileStream != null ) settingsFileStream.Close();	
}


var wmpHelper = null;
var wmp = null;
var shownTracks = null;
var savedPlaylist = null;

var selected_artist = null;
var selected_album = null;

var helper = new ActiveXObject("SCHelper.SECHelper");
if( helper.IsProcessRunning("wmplayer.exe") ) {
    launchWidget();
} else {
    var launchQuestion = CreateQuestionDialog( "launch_");
    launchQuestion.textualContent = "Launch Media Player?";
    theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
    launchWidget();
}

function writeSettings()
{
	try {
		var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );	// overwrite
		settingsFileStream.WriteLine( "setting_artist_item" );
		settingsFileStream.WriteLine( setting_artist_item );
		settingsFileStream.WriteLine( "setting_album_item" );
		settingsFileStream.WriteLine( setting_album_item );
		settingsFileStream.WriteLine( "setting_track_item" );
		settingsFileStream.WriteLine( setting_track_item );
		settingsFileStream.Close();
	} catch( e ) {}
}



//
// Show list of artists
//

function launchWidget()
{
    wmpHelper = new ActiveXObject("SCWMPlayer.WMPlayerHelper");
    wmp = wmpHelper.GetMediaPlayer();
    
	var artist_list = new Array();
    artist_list.push("All");
	
    var artist_collection = wmp.mediaCollection.getAttributeStringCollection("Author", "Audio");
    for( var i = 0; i < artist_collection.count; i++ ){
        var artist = artist_collection.item(i);
        if( artist != "" ) artist_list.push( artist );
    }

    var list = CreateListScreen( "browse_");
    
    list.name = "More Menu browse by artist list";
    list.title = "Select Artist";
    list.itemLabels = artist_list;
    list.selectedItem = setting_artist_item;
    
    theTerminal.Push(list);
}



//
// An artist was selected - show list of albums
//

function browse_ValueUpdated(list, property)
{
	if( setting_artist_item != list.selectedItem ) {
		setting_track_item = 0;
		setting_album_item = 0;
		setting_artist_item = list.selectedItem;
		writeSettings();
	}

    selected_artist = list.itemLabels[list.selectedItem];

    var album_list = new Array();

    if( selected_artist == "All" ) {
    // All artists
        var album_collection = wmp.mediaCollection.getAttributeStringCollection("Album", "Audio");
        for( var i = 0; i < album_collection.count; i++ ){
            var album = album_collection.item(i);
            if( album != "" ) album_list.push( album );	      
        }
    } else {
    // Some specific artist
        album_list.push("All");
        
        var tracks = wmp.mediaCollection.getByAuthor( selected_artist );
        var albums = new Array();
        for (var i = 0; i < tracks.count; i++) {
            var media = tracks.item(i);
            var Album = media.getItemInfo("Album");            
            var Artist = media.getItemInfo("Artist");            
            if (Album != "" && Artist == selected_artist ) {
                albums.push(Album);
            }
        }

        // Remove duplicates

        if( albums.length > 0 ) {
            albums.sort();
            album_list.push(albums[0]);
        }
        
        for( var j = 1; j < albums.length; j++ ) {
            if( albums[j] != album_list[album_list.length-1] ) {
                album_list.push(albums[j]);
            }
        }
    }

    var list = CreateListScreen( "browse_album_");    
    list.name = "More Menu browse by artist album list";
    list.title = "Select Album";
    list.itemLabels = album_list;
    list.selectedItem = setting_album_item;   
    theTerminal.Push(list);
}



//
// An album was selected - show list of tracks
//

function browse_album_ValueUpdated(list, property)
{
	if( setting_album_item != list.selectedItem ) {
		setting_track_item = 0;
		setting_album_item = list.selectedItem;
		writeSettings();
	}

    selected_album = list.itemLabels[list.selectedItem];
    
    var playlist = null;
    
    // Compute a superset of tracks to include
    if( selected_album == "All" && selected_artist == "All" ) {
    // Will never happen
    } else if( selected_album == "All" ) {
    //  Only artist specified
        playlist = wmp.mediaCollection.getByAuthor( selected_artist );
    } else if( selected_artist == "All" ) {
    //  Only album specified
        playlist = wmp.mediaCollection.getByAlbum( selected_album );
    } else {
    //  Both artist and album specified
        playlist = wmp.mediaCollection.getByAlbum( selected_album );
    }
    
    //

    if( playlist == null || playlist.count == 0 ) {
        var messageBox = CreateMessageboxDialog( "");        
        messageBox.name = "No tracks found message box";
        messageBox.title = "Clicker";
        messageBox.textualContent = "No tracks found";        
        theTerminal.Push(messageBox);
        return;
    }

    // Build a list of matching tracks. We require both album and artist to match. The supplied list of tracks
    // may be larger.
 
    savedPlaylist = playlist;
    
    shownTracks = new Array();
    for( var i = 0; i < playlist.count; i++ ) {
        var media = playlist.item(i);
		var Album = media.getItemInfo("Album");            
		var Artist = media.getItemInfo("Artist");            
        
        if ( (Album == selected_album || selected_album == "All") && 
             (Artist == selected_artist || selected_artist == "All") ) {
			shownTracks.push(media);
		}
    }
    
    // Sort tracks list if an album has been selected
    if( selected_album != "All" && selected_album != "" ) {
        shownTracks.sort( compareTracksByIndex );
    }

    var listItems = new Array();
    for( var i = 0; i < shownTracks.length; i++ ) {
        var media = shownTracks[i];
		listItems.push( media.name );
    }

    // Populate and show a list widget
    var trackList = CreateListScreen( "playTrack_");
    trackList.name = "Select track list";
    trackList.itemLabels = listItems;
    trackList.selectedItem = setting_track_item;
    trackList.title = "Select Track";       
    theTerminal.Push(trackList);        
}


function compareTracksByIndex( a, b )
{
	var aidx = a.getItemInfo("WM/TrackNumber");            
	var bidx = b.getItemInfo("WM/TrackNumber");            

    if( aidx != null && aidx != 0 && bidx != null && bidx != 0 ) {
        return aidx - bidx; // A negative value if the first argument passed is less than the second argument.
    } else if( aidx != null && aidx != 0 ) {
        return -1; // a comes before b
    } else if( bidx != null && bidx != 0 ) {
        return 1; // a comes after b
    } else {
        return 0; // we don't care
    }
}



//
// A track was selected - play it
//

function playTrack_ValueUpdated(list, theProperty)
{
	if( setting_track_item != list.selectedItem ) {
		setting_track_item = list.selectedItem;
		writeSettings();
	}

    if (savedPlaylist != null)
    {
        var media = shownTracks[list.selectedItem];
        wmp.currentPlaylist = savedPlaylist;
        wmp.controls.playItem(media);
    }   
    
    theTerminal.PopTo("Windows Media Player");
}