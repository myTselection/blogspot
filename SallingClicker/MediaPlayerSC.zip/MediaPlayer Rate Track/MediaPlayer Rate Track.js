
var object = null;
var player = null;

var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("wmplayer.exe")) 
{
    launchWidget();
} 
else 
{
    var launchQuestion = CreateQuestionDialog( "launch_");
    launchQuestion.textualContent = "Launch Media Player?";
    theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
    launchWidget();
}

function launchWidget()
{
    object = new ActiveXObject("SCWMPlayer.WMPlayerHelper");
    player = object.GetMediaPlayer();
    
    var media = player.controls.currentItem;
    if (media != null)
    {
        var slider = CreateSliderDialog( "rateTrack_");
                    
        slider.name = "More menu rating slider";
        slider.title = "Rate Track";
        slider.maxValue = 5;
        slider.value = media.getItemInfo("UserRating") / 20;
                
        theTerminal.Push(slider);
    }
}

function rateTrack_OK(slider)
{   
    var media = player.controls.currentItem;
    if (media != null)
    {
        media.setItemInfo("UserRating", slider.value * 20);
    }
    
    theTerminal.PopTo("Windows Media Player");
}
