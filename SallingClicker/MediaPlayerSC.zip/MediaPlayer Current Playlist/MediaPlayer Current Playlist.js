var object = new ActiveXObject("SCWMPlayer.WMPlayerHelper");
var player = object.GetMediaPlayer();

var selected_playlist = player.currentPlaylist;

if( selected_playlist.count > 500  ) { // library    
	var popup = CreatePopupDialog("popup_");
	popup.textualContent = "Current playlist is too large.";
	theTerminal.Push( popup );
} else {
    var current_track = player.currentmedia;
    var listItems = new Array();
    var sel_index = 0;
    for( var i = 0; i < selected_playlist.count; i++ ) {
        var track = selected_playlist.item(i);
	    listItems.push( track.name );
        if( current_track.isIdentical( track ) ) {
	        sel_index = i;            
        }
    }

    var list = CreateListScreen( "playTrack_");
    list.name = "Source list";
    list.title = selected_playlist.name;
    list.itemLabels = listItems;
    list.selectedItem = sel_index;
        
    theTerminal.Push(list);
}

function playTrack_ValueUpdated(list, theProperty)
{
    var media = selected_playlist.item(list.selectedItem);
    player.currentPlaylist = selected_playlist;
    player.controls.playItem(media);
    theTerminal.Popto( "Windows Media Player" ); 
}
