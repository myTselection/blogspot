
var object = null;
var player = null;
var userPlaylists = null;

var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("wmplayer.exe")) 
{
    launchWidget();
} 
else 
{
    var launchQuestion = CreateQuestionDialog( "launch_");
    launchQuestion.textualContent = "Launch Media Player?";
    theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
    launchWidget();
}

function launchWidget()
{
    object = new ActiveXObject("SCWMPlayer.WMPlayerHelper");
    player = object.GetMediaPlayer();
    
    if (player.controls.currentItem != null)
    {
        var playlistArray = player.playlistCollection.getAll();
        
        // Build list of user playlists
        var playlistItems = new Array();
        userPlaylists = new Array();
        for (var i = 0; i < playlistArray.count; i++)
        {
			try {
				var playlist = playlistArray.item(i);

				// Don't want auto created playlists
				if (playlist.getItemInfo("PlaylistType") != "Auto")
				{
					playlistItems[i] = playlist.name;
					userPlaylists.push(playlist);
				}
			} catch( e ) {}
        }
    
        if (playlistItems.length > 0)
        {
            var list = CreateListScreen( "addToPlaylist_");
            
            list.name = "More Menu add to playlist list";
            list.title = "Select Playlist";
            list.itemLabels = playlistItems;
            list.selectedItem = 0;
            
            theTerminal.Push(list);
        }
    }
}

function addToPlaylist_ValueUpdated(theList, theProperty)
{
    var playlist = userPlaylists[theList.selectedItem];
    var media = player.currentMedia;
    
    if (media != null)
    {
        playlist.appendItem(media);
    }
    
    theTerminal.PopTo("Windows Media Player");
}
