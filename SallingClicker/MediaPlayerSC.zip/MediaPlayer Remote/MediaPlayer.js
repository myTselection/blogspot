var object = null;
var player = null;
var moreMenu = CreateListScreen( "moreMenu_");

var mediaPlayer = null;
var playlistRow = null;
var songRow = null;
var artistRow = null;
var albumRow = null;

var keyWasRepeated = false;
var currentSong = null;

// Initialize more menu
var moreMenuItems = new Array();
moreMenuItems[0] = "Rate Track";
moreMenuItems[1] = "Add to Playlist";
moreMenuItems[2] = "PlayLists";
moreMenuItems[3] = "Browse by Artist";
moreMenuItems[4] = "Repeat";
moreMenuItems[5] = "Playlist Shuffle";
moreMenuItems[6] = "Play Random Track";
moreMenuItems[7] = "Set Sound Balance";
moreMenuItems[8] = "Quit";

var moreMenuItemUUIDs = new Array();
moreMenuItemUUIDs[0] = "6BB14A6B-EF7D-4c4c-A6A8-E30DDD1765BF";   // Rate Track
moreMenuItemUUIDs[1] = "6649FCDC-C2D5-46ad-8E41-5E5F5E663E37";   // Add to Playlist
moreMenuItemUUIDs[2] = "89719EA5-A1D0-4c7b-899F-5596E952860F";   // PlayLists
moreMenuItemUUIDs[3] = "38C0D229-D763-4794-8FB3-96E79E153AE5";   // Browse by Artist
moreMenuItemUUIDs[4] = "8A311DD4-1368-4308-8CF0-07CB2AC1849A";   // Repeat
moreMenuItemUUIDs[5] = "82CD4015-5C7C-4e9d-9339-65EDA3B77E37";   // Playlist Shuffle
moreMenuItemUUIDs[6] = "2894CEDA-8C25-4efd-B319-366CE7DC8D15";   // Play Random Track
moreMenuItemUUIDs[7] = "A5EAB91F-0FEA-4c23-84A6-62F6D5DBDBA1";   // Set Sound Balance
moreMenuItemUUIDs[8] = "quit";                                   // Quit

moreMenu.name = "More menu list";
moreMenu.title = "More";
moreMenu.selectedItem = 0;
moreMenu.itemLabels = moreMenuItems;


// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_artwork_layout = 1;
var setting_moremenu_item = 0;

// Read settings for this script
try {
   var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
   if( settingsFileStream == null ) {
      // Write defaults
      writeSettings();
      settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
   }
   while( true ) {
      var propertyName = settingsFileStream.ReadLine();
      var propertyValue = settingsFileStream.ReadLine();
      if( propertyName == "setting_artwork_layout" ) {
         setting_artwork_layout = parseInt( propertyValue );
      } else if( propertyName == "setting_moremenu_item" ) {
         setting_moremenu_item = parseInt( propertyValue );
      }
   }
} catch( e ) {
} finally {
   if( settingsFileStream != null ) settingsFileStream.Close();
}


//
launchWidget();


function writeSettings()
{
   try {
      var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );   // overwrite
      settingsFileStream.WriteLine( "setting_artwork_layout" );
      settingsFileStream.WriteLine( setting_artwork_layout );
      settingsFileStream.WriteLine( "setting_moremenu_item" );
      settingsFileStream.WriteLine( setting_moremenu_item );
      settingsFileStream.Close();
   } catch( e ) {}
}


function launchWidget()
{
    object = new ActiveXObject("SCWMPlayer.WMPlayerHelper");
    player = object.GetMediaPlayer();

    mediaPlayer = CreateMediaplayerScreen( "mediaPlayer_");

   if( theTerminal.displaySize == scSmall ) {
      songRow = mediaPlayer.CreateRow("", scCenter, scClip, scSmall);
      albumRow = mediaPlayer.CreateRow("", scCenter, scClip, scSmall);
   } else if( theTerminal.displaySize == scMedium ) {
      songRow = mediaPlayer.CreateRow("", scCenter, scClip, scSmall);
      artistRow = mediaPlayer.CreateRow("", scCenter, scClip, scSmall);
      albumRow = mediaPlayer.CreateRow("", scCenter, scClip, scSmall);
   } else {
      playlistRow = mediaPlayer.CreateRow("", scLeft, scClip, scSmall);
      songRow = mediaPlayer.CreateRow("", scCenter, scScroll, scLarge);
      artistRow = mediaPlayer.CreateRow("", scCenter, scClip, scMedium);
      albumRow = mediaPlayer.CreateRow("", scCenter, scClip, scMedium);
   }

    mediaPlayer.title = "Windows Media Player";
    mediaPlayer.name = "Windows Media Player";
   mediaPlayer.imageStyle = scFill;
    theTerminal.Push(mediaPlayer);
}

// =============================================================================

// This function is called periodically, at a rate of once per second
function mediaPlayer_Update(theScreen)
{
    try
    {
        if (player == null)
        {
            throw "null player";
        }

      if (player.playState == 1)
      {
         // Player state is Stopped
         theScreen.playerState = scStopped;
         if( playlistRow != null ) playlistRow.textualContent = "";
         if( songRow != null ) songRow.textualContent = "No Track";
         if( artistRow != null ) artistRow.textualContent = "";
         if( albumRow != null ) albumRow.textualContent = "";
            theScreen.mediaLength = -1;
            theScreen.mediaPosition = -1;
         theScreen.mediaRating = -1;
         theScreen.image = "";
         currentSong = null;
         return;
      }
      else if (player.playState == 2)
      {
         // Player state is Paused
         theScreen.playerState = scPaused;
      }
      else if (player.playState == 3)
      {
         // Player state is Playing
         theScreen.playerState = scPlaying;
      }

        var playList = player.currentPlaylist;
        if (playList != null)
        {
            // Need these here, to keep things consistent if the user changes the
            // option from the GUI.
            mediaPlayer.shuffle = player.settings.getMode("shuffle");

            var repeatMode = player.settings.getMode("loop");
            if (repeatMode == 0)
            {
                mediaPlayer.mediaRepeat = scRepeatOff;
            }
            else
            {
                mediaPlayer.mediaRepeat = scRepeatAll;
            }
        }

        var media = player.controls.currentItem;
        if (media != null)
        {
            // All hell breaks loose if this happens when a track is not selected
            // Get current playhead position from media player and inform widget
            var position = player.controls.currentPosition;
            mediaPlayer.mediaPosition = position;

         var rating = media.getItemInfo("UserRating");
         if( rating < 1 ) {
            mediaPlayer.mediaRating = -1;
         } else if( rating >= 1 && rating < 25 ) {
            mediaPlayer.mediaRating = 20;
         } else if( rating >= 25 && rating < 50 ) {
            mediaPlayer.mediaRating = 40;
         } else if( rating >= 50 && rating < 75 ) {
            mediaPlayer.mediaRating = 60;
         } else if( rating >= 75 && rating < 90 ) {
            mediaPlayer.mediaRating = 80;
         } else if( rating >= 90 ) {
            mediaPlayer.mediaRating = 100;
         }

            if (media.name != currentSong)
            {
                updateMediaplayerWidget();
            }
        } else {
         if( playlistRow != null ) playlistRow.textualContent = "";
         if( songRow != null ) songRow.textualContent = "No Track";
         if( artistRow != null ) artistRow.textualContent = "";
         if( albumRow != null ) albumRow.textualContent = "";
            theScreen.mediaLength = -1;
            theScreen.mediaPosition = -1;
         theScreen.mediaRating = -1;
         theScreen.image = "";
         theScreen.playerState = scStopped;
         currentSong = null;
        }

        mediaPlayer.listeningVolume = player.settings.volume;
    }
    catch (e)
    {
      if( playlistRow != null ) playlistRow.textualContent = "";
      if( songRow != null ) songRow.textualContent = "Track info N/A";
      if( artistRow != null ) artistRow.textualContent = "";
      if( albumRow != null ) albumRow.textualContent = "";
        theScreen.mediaLength = -1;
        theScreen.mediaPosition = -1;
      theScreen.mediaRating = -1;
      theScreen.image = "";
      theScreen.playerState = scStopped;
      currentSong = null;
    }
}

function mediaPlayer_ValueUpdated(theScreen, property)
{
    if (property == 4 /*PlayheadPosition*/ )
    {   // Setting new playhead position from device widget
        player.controls.currentPosition = mediaPlayer.mediaPosition;
    }
}

function mediaPlayer_Exit(theScreen)
{
    object = null;
    player = null;
    mediaPlayer = null;
    moreMenu = null;
}

function mediaPlayer_KeyDown(theScreen, theKey)
{
    try {
      if (theKey == "s") {
         if (player.playState == 3) {
            // Current state is playing, set to pause
            mediaPlayer.playerState = scPaused;
            player.controls.Pause();

            ShowMessage("Windows Media Player", Pause);
         } else {
            // Not playing, so start playing
            mediaPlayer.playerState = scPlaying;
            player.controls.Play();

            var media = player.controls.currentItem;
            if( media != null ) {
               ShowMessage(media.name, Play);
            }
         }
      } else if (theKey == "^" || theKey == "u") {
         changeVolume(5);
      } else if (theKey == "c") {
         muteUnmute();
      } else if (theKey >= "0" && theKey <= "5") {
         setRating( theKey - "0" );
      } else if (theKey == "v" || theKey == "d") {
         changeVolume(-5);
      }
    }
    catch (e) {
      player = null;
   }

}

function mediaPlayer_KeyRepeat(theScreen, theKey)
{
    keyWasRepeated = true;

    try
    {
        if (theKey == ">")
        {
            player.controls.currentPosition = player.controls.currentPosition + 5;

         var location = -1;

         var media = player.controls.currentItem
         if (media != null)
         {
            location = 100 * player.controls.currentPosition / media.duration;
               ShowMessage("", FForward, location);
         }
        }
        else if (theKey == "<")
        {
            player.controls.currentPosition = player.controls.currentPosition - 5;

         var location = -1;

         var media = player.controls.currentItem
         if (media != null)
         {
            location = 100 * player.controls.currentPosition / media.duration;
               ShowMessage("", FRewind, location);
         }
        }
        else if (theKey == "^" || theKey == "u")
        {
            changeVolume(5);
        }
        else if (theKey == "v" || theKey == "d")
        {
            changeVolume(-5);
        }
    }
    catch (e)
    {
        player = null;
    }
}

function mediaPlayer_KeyUp(theScreen, theKey)
{

    if (theKey == "f" || theKey == "*")
    {
        // Display the OptionsList
        moreMenu.selectedItem = setting_moremenu_item;
        theTerminal.Push(moreMenu);
    }
    else if (theKey == ">")
    {
        if (keyWasRepeated == false)
        {
            player.controls.Next();

           var media = player.controls.currentItem;
            if (media != null)
            {
                ShowMessage(media.name, Next);
            }
        } else {
           var media = player.controls.currentItem;
           if( media != null ) {
            ShowMessage(media.name, Play);
         }
        }
    }
    else if (theKey == "<")
    {
        if (keyWasRepeated == false)
        {
            player.controls.previous();

           var media = player.controls.currentItem;
            if (media != null)
            {
                ShowMessage(media.name, Previous);
            }
        } else {
           var media = player.controls.currentItem;
           if( media != null ) {
               ShowMessage(media.name, Play);
         }
        }
    }
   else if (theKey == ":help" || theKey == "#")
   {
       showHelp();
   }

    keyWasRepeated = false;
 }

// =============================================================================

function moreMenu_ValueUpdated(theScreen, theProperty)
{
   setting_moremenu_item = theScreen.selectedItem;
   writeSettings();
   // How do I close WMP without keystroke ALT+F4?
   if (moreMenuItemUUIDs[theScreen.selectedItem] == "quit") {
        var wmpwh = FindWindow("WMPlayerApp", "Windows Media Player");
        if (wmpwh != 0) {
        theTerminal.PopTo("Windows Media Player");
        player.controls.Stop();
        ActivateWindow(wmpwh);
        SendVirtualKeystroke(0x73,false,false,true,false);
        }
        //mediaPlayer_Exit(theScreen);
      //}
   } else if(moreMenuItemUUIDs[theScreen.selectedItem] != "") {
      theTerminal.ExecuteScript(moreMenuItemUUIDs[theScreen.selectedItem]);
   }
}

// =============================================================================

function setRating(rating)
{
   try {
      var media = player.controls.currentItem;
      if (media != null) {
         media.setItemInfo("UserRating", rating * 20);
      }
   } catch( e ) {}
}

function muteUnmute()
{
   if( player.settings.mute ) {
      player.settings.mute = false;
      ShowMessage("Windows Media Player", Volume, player.settings.volume);
   } else {
      player.settings.mute = true;
      ShowMessage("Windows Media Player", Mute, 0);
   }
}

function changeVolume(delta)
{
    try
    {
      player.settings.mute = false;

        // Raise volume
        var soundVolume = player.settings.volume + delta;

        if (soundVolume < 0)
        {
            soundVolume = 0;
        }
        else if (soundVolume > 100)
        {
            soundVolume = 100;
        }

        player.settings.volume = soundVolume;

      if (soundVolume == 0)
      {
         ShowMessage("Windows Media Player", Mute, soundVolume);
      }
      else
      {
         ShowMessage("Windows Media Player", Volume, soundVolume);
      }
    }
    catch (e)
    {
        player = null;
    }
}

//=============================================================================

function updateMediaplayerWidget()
{
    // Initialize with info from current track
    var media = player.controls.currentItem
    if (media != null)
    {
        mediaPlayer.mediaLength = media.duration;

        var index = GetSongIndexInPlaylist(player.currentPlaylist) + 1;
        if( playlistRow != null ) playlistRow.textualContent = index + " of " + player.currentPlaylist.count + " in " + player.currentPlaylist.name;

        if( songRow != null ) songRow.textualContent = media.name;

        var Album = media.getItemInfo("Album");
        if( Album == null || Album == "" ) Album = "Unknown Album";

        var Artist = media.getItemInfo("Artist");
        if( Artist == null || Artist == "" ) Artist = "Unknown Artist";

        if (theTerminal.displaySize == 4 /* scHuge */) {
         if( artistRow != null ) artistRow.textualContent = Album;
         if( albumRow != null ) albumRow.textualContent = Artist;
        } else {
         if( artistRow != null ) artistRow.textualContent = Album;
         if( albumRow != null ) albumRow.textualContent = Artist;
        }

        // Update artwork
        var artwork = null;

        // Doesn't work yet
//        var count = player.currentMedia.getAttributeCountByType("WM/Picture", "");
//        player.currentMedia.getItemInfoByType("WM/Picture", "", 0);

        if (artwork != null)
        {

            // There is artwork...
            if (currentSong != media.name)
            {
                // Looks like new artwork, so update it. Setting the image property sets a
                // dirty bit, so only set this property, if it has changed.
            }
        }
        else
        {
            // There isn't any artwork
            mediaPlayer.image = "";
        }

        currentSong = media.name;
    }
}

//=============================================================================
// This is so easy in iTunes! After going through the media player object
// model, this is the only thing I came up with. This is actually based on
// sample code from the media player sdk help file.

function GetSongIndexInPlaylist(playlist)
{
    // Loop through the playlist one entry at a time.
    for (var i = 0; i < playlist.count; i++)
    {
        // Test whether the media item matches
        // the item in the playlist at the loop index.
        if (player.currentmedia.isIdentical(playlist.item(i)))
        {
            // They match, return the index
            return i;
        }
    }
}

//=============================================================================

function showHelp()
{
    var code = new Array();
    var title = new Array();
    var description = new Array();

    code[0] = "s";
    title[0] = "Player Mode";
    description[0] = "Click to toggle between play and pause.";

    code[1] = "<";
    title[1] = "Previous Track";
    description[1] = "Skips to the beginning of the currently playing track, or to the previous track if already at the beginning. Hold to scan a track backwards.";

    code[2] = ">";
    title[2] = "Next Track";
    description[2] = "Skips to the next track. Hold to scan a track forward.";

    code[3] = new Array("^", "u");
    title[3] = "Volume Up";
    description[3] = "Raises the listening volume";

    code[4] = new Array("v", "d");
    title[4] = "Volume Down";
    description[4] = "Softens the listening volume";

    code[5] = new Array("f", "*");
    title[5] = "More";
    description[5] = "More settings and commands";

    theTerminal.ShowKeypadHelp("Media Player Help", code, title, description);
}