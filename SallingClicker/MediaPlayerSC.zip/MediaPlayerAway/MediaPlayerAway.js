
var helper = new ActiveXObject("SCHelper.SECHelper");
var shouldReactivate = false;

function EnteringProximity(theTerminal)
{
	if( shouldReactivate == true ) {
	    if( helper.IsProcessRunning("wmplayer.exe") ) {
			var object = new ActiveXObject("SCWMPlayer.WMPlayerHelper");
            var player = object.GetMediaPlayer();
            
			// Play and fade in				
			var targetVolume = player.settings.volume;
			player.settings.volume = 0;
			player.controls.Play();
			for( i = 0; i <= targetVolume; i++ ) {
				player.settings.volume = i;
			}
        }
	}
}

function LeavingProximity(theTerminal)
{	
    shouldReactivate = false;
    if( helper.IsProcessRunning("wmplayer.exe") ) {
		var object = new ActiveXObject("SCWMPlayer.WMPlayerHelper");
        var player = object.GetMediaPlayer();
        
	    if( player.playState == 3 ) {
		    shouldReactivate = true;

			// Fade out and pause
			var oldVolume = player.settings.volume;
			for( i = oldVolume; i >= 0; i-- ) {
				player.settings.volume = i;
			}
			player.controls.Pause();
			player.settings.volume = oldVolume;				
	    }	
    }
}