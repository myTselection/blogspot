
var object = null;
var player = null;

var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("wmplayer.exe")) 
{
    launchWidget();
} 
else 
{
    var launchQuestion = CreateQuestionDialog( "launch_");
    launchQuestion.textualContent = "Launch Media Player?";
    theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
    launchWidget();
}

function launchWidget()
{
    object = new ActiveXObject("SCWMPlayer.WMPlayerHelper");
    player = object.GetMediaPlayer();
    
    var onOffSelector = CreateBooleanSwitchDialog( "shuffle_");
    
    onOffSelector.name = "More menu shuffle on off selector";
    onOffSelector.title = "Shuffle";
    onOffSelector.value = player.settings.getMode("Shuffle");
    
    theTerminal.Push(onOffSelector);
}

function shuffle_OK(onOffSelector)
{
    player.settings.setMode("Shuffle", onOffSelector.value);
    theTerminal.PopTo("Windows Media Player");
}

