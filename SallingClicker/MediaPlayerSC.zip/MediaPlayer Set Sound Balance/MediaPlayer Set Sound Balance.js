
var object = null;
var player = null;

var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("wmplayer.exe")) 
{
    launchWidget();
} 
else 
{
    var launchQuestion = CreateQuestionDialog( "launch_");
    launchQuestion.textualContent = "Launch Media Player?";
    theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
    launchWidget();
}

function launchWidget()
{
    object = new ActiveXObject("SCWMPlayer.WMPlayerHelper");
    player = object.GetMediaPlayer();
    
    var slider = CreateSliderDialog( "balance_");
    
    slider.name = "More menu balance slider";
    slider.title = "Set Balance";
    slider.maxValue = 10;
    slider.value = (player.settings.balance / 20) + 5;
        
    theTerminal.Push(slider);
}

function balance_OK(slider)
{       
    player.settings.balance = (slider.value * 20) - 100;
    theTerminal.PopTo("Windows Media Player");
}

function balance_Updated(slider)
{   
    player.settings.balance = (slider.value * 20) - 100;
}
