
var object = null;
var player = null;

var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("wmplayer.exe")) 
{
    launchWidget();
} 
else 
{
    var launchQuestion = CreateQuestionDialog( "launch_");
    launchQuestion.textualContent = "Launch Media Player?";
    theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
    launchWidget();
}

function launchWidget()
{
    object = new ActiveXObject("SCWMPlayer.WMPlayerHelper");
    player = object.GetMediaPlayer();
    
    var onOffSelector = CreateBooleanSwitchDialog( "repeat_");
    
    onOffSelector.name = "More menu onOffSelector on off selector";
    onOffSelector.title = "Repeat";
    onOffSelector.value = player.settings.getMode("loop");
    
    theTerminal.Push(onOffSelector);   
}

function repeat_OK(onOffSelector)
{
    player.settings.setMode("loop", onOffSelector.value);
    theTerminal.PopTo("Windows Media Player");
}
