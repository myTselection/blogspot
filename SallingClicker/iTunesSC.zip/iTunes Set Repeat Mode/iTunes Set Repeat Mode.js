var iTunes = null


var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("iTunes.exe")) {
	launchWidget();
} else {
	var launchQuestion = CreateQuestionDialog("launch_");
	launchQuestion.textualContent = "Launch iTunes?";
	theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
	launchWidget();
}

function launchWidget()
{
	iTunes = new ActiveXObject("iTunes.Application");
	
    // Repeat
    var playList = iTunes.CurrentPlaylist;
    if (playList != null)
    {
        var items = new Array( "Off", "Song", "All in " + playList.name );
        
        var list = CreateOptionListDialog( "repeat_");
        
        list.name = "More menu repeat list";
        list.title = "Repeat";
        list.itemLabels = items;
        list.value = playList.SongRepeat;
        
        theTerminal.Push(list);   
    }
    else
    {
        var messageBox = CreateMessageboxDialog( "");
        
        messageBox.title = "Clicker";
        messageBox.textualContent = "No current playlist";
        
        theTerminal.Push(messageBox);
    }
}

//=============================================================================

function repeat_OK(list)
{
    var playList = iTunes.CurrentPlaylist;
    if (playList != null)
    {
        playList.SongRepeat = list.value;
    }
}

