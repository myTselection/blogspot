var iTunes = null
var moreMenu = CreateListScreen( "moreMenu_");

var mediaPlayer = null;
var playlistRow = null;
var songRow = null;
var artistRow = null;
var albumRow = null;

// Initialize more menu
var moreMenuItems = new Array();
moreMenuItems[0] = "Current Playlist";
moreMenuItems[1] = "Playlists";
moreMenuItems[2] = "Browse by Artist";      
moreMenuItems[3] = "Find Album";            
moreMenuItems[4] = "Find by Artist";        
moreMenuItems[5] = "Find by Composer";  
moreMenuItems[6] = "Find by Name";         
moreMenuItems[7] = "Rate Track";         
moreMenuItems[8] = "Add to Playlist";
moreMenuItems[9] = "Repeat";
moreMenuItems[10] = "Playlist Shuffle";
moreMenuItems[11] = "Play Random Track";    
moreMenuItems[12] = "Visuals On/Off";
moreMenuItems[13] = "Set Artwork Layout";

var moreMenuItemUUIDs = new Array();
moreMenuItemUUIDs[0] = "2EC3593D-CD6F-41c3-A6F8-DB46F293E776";	// Current Playlist
moreMenuItemUUIDs[1] = "9B8E8E37-76FA-4fdb-95E0-A6BCACEF924F";	// Playlists
moreMenuItemUUIDs[2] = "997B9C42-5057-494d-8D4F-B6444C23720F";  // Browse by Artist
moreMenuItemUUIDs[3] = "E24DE795-566E-40e0-B25B-B9CCD97132EB";  // Find Album
moreMenuItemUUIDs[4] = "84627FAD-5911-4f12-91B0-6A581B8B9D84";  // Find by Artist
moreMenuItemUUIDs[5] = "554A673C-135F-4da8-8020-6CBEB0C0AC31";  // Find by Composer
moreMenuItemUUIDs[6] = "52F280A2-63B7-4cda-BE8E-A38DFF34F4A9";  // Find by Name
moreMenuItemUUIDs[7] = "EA9A4C1C-98A0-4cda-A85A-14FEB84C883A";	// rate track
moreMenuItemUUIDs[8] = "E11DBD76-AEC2-4615-8750-F2F8F9309443";	// Add to Playlist
moreMenuItemUUIDs[9] = "5CCDFD3F-061E-4db3-B840-26FA62BD37C4";	// Repeat
moreMenuItemUUIDs[10] = "A736A2E2-703D-40f0-8781-15DA09D50F7C";	// Playlist Shuffle
moreMenuItemUUIDs[11] = "DBD49EC0-2DD3-4b5e-8E30-34127355A6D2";	// Play Random Track
moreMenuItemUUIDs[12] = "084AA12B-2D35-4d8f-98AE-9B4C7ECBC5A9";	// Visuals On/Off
moreMenuItemUUIDs[13] = "";

moreMenu.name = "More menu list";
moreMenu.title = "More";
moreMenu.selectedItem = 0;
moreMenu.itemLabels = moreMenuItems;

var keyWasRepeated = false;
var leftProxmity = false;
var userPlaylists = null;
//var browse_artist = null; where was this used?

var currentSong = null;
var currentAlbum = null;

// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_artwork_newlayout = 0;
var setting_moremenu_item = 0;

// Read settings for this script
try {
	var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	if( settingsFileStream == null ) {
		// Write defaults
		writeSettings();
		settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	}
	while( true ) {
		var propertyName = settingsFileStream.ReadLine();
		var propertyValue = settingsFileStream.ReadLine();
		if( propertyName == "setting_artwork_newlayout" ) {
			setting_artwork_newlayout = parseInt( propertyValue );
		} else if( propertyName == "setting_moremenu_item" ) {
			setting_moremenu_item = parseInt( propertyValue );
		}
	}
} catch( e ) {
} finally {
	if( settingsFileStream != null ) settingsFileStream.Close();	
}


// Make sure iTunes is launched

var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("iTunes.exe")) {
	launchWidget();
} else {
	var launchQuestion = CreateQuestionDialog("launch_");
	launchQuestion.textualContent = "Launch iTunes?";
	theTerminal.Push(launchQuestion);
}




function writeSettings()
{
	try {
		var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );	// overwrite
		settingsFileStream.WriteLine( "setting_artwork_newlayout" );
		settingsFileStream.WriteLine( setting_artwork_newlayout );
		settingsFileStream.WriteLine( "setting_moremenu_item" );
		settingsFileStream.WriteLine( setting_moremenu_item );
		settingsFileStream.Close();
	} catch( e ) {}
}


function launch_OK(w)
{
	launchWidget();
}

function launchWidget()
{
	try {
		iTunes = new ActiveXObject("iTunes.Application");
	} catch( e ) {}
	if( iTunes == null ) {
		var popup = CreatePopupDialog("popup");
		popup.textualContent = "Cannot connect to iTunes. Please install/repair.";
		theTerminal.Push( popup );
		return;
	}

	mediaPlayer = CreateMediaplayerScreen( "mediaPlayer_");
	// Create rows for the display
	if( theTerminal.displaySize == scSmall ) {
		songRow = mediaPlayer.CreateRow("", scLeft, scClip, scSmall);
		albumRow = mediaPlayer.CreateRow("", scLeft, scClip, scSmall);
	} else if( theTerminal.displaySize == scMedium ) {
		songRow = mediaPlayer.CreateRow("", scLeft, scClip, scSmall);
		artistRow = mediaPlayer.CreateRow("", scLeft, scClip, scSmall);
		albumRow = mediaPlayer.CreateRow("", scLeft, scClip, scSmall);
	} else {
		playlistRow = mediaPlayer.CreateRow("", scLeft, scClip, scSmall);
		songRow = mediaPlayer.CreateRow("", scLeft, scScroll, scLarge);
		artistRow = mediaPlayer.CreateRow("", scLeft, scClip, scMedium);
		albumRow = mediaPlayer.CreateRow("", scLeft, scClip, scMedium);
	}
	
	mediaPlayer.title = "iTunes";
	mediaPlayer.name = "iTunes";
	theTerminal.Push(mediaPlayer);
}


// =============================================================================

// This function is called periodically, at a rate of once per second
function mediaPlayer_Update(theScreen)
{
    try {
        if (iTunes == null) {
            return;
        }
    
        var playList = iTunes.CurrentPlaylist;
        if (playList != null) {
            // Need these here, to keep things consistent if the user changes the 
            // option from the GUI.
            
            theScreen.shuffle = playList.Shuffle;
            
            var repeatMode = playList.SongRepeat;
            if( repeatMode == 0 ) {
				theScreen.mediaRepeat = scRepeatOff;
            } else if( repeatMode == 1 ) {
				theScreen.mediaRepeat = scRepeatOne;
            } else if( repeatMode == 2 ) {
				theScreen.mediaRepeat = scRepeatAll;
            }
        } else {
			theScreen.mediaRepeat = scRepeatOff;
			theScreen.shuffle = false;
        }

		theScreen.listeningVolume = iTunes.SoundVolume;

        var track = iTunes.CurrentTrack;
        if( track != null ) {
            // All hell breaks loose if this happens when a track is not selected
            // Get current playhead position from iTunes and inform widget
            var position = iTunes.PlayerPosition;
            theScreen.mediaPosition = position;
			theScreen.mediaRating = track.rating;	
			
			if( iTunes.PlayerState == 0 ) {
				theScreen.playerState = scPaused;
			} else {
				theScreen.playerState = scPlaying;
			}
			
            if( track.Name != currentSong || track.Album != currentAlbum ) {
                updateMediaplayerWidget();
            }
        } else {
			if( playlistRow != null ) playlistRow.textualContent = "";
			if( songRow != null ) songRow.textualContent = "No Track";
			if( artistRow != null ) artistRow.textualContent = "";
			if( albumRow != null ) albumRow.textualContent = "";
            theScreen.mediaLength = -1;
            theScreen.mediaPosition = -1;
			theScreen.mediaRating = -1;	
			theScreen.image = "";
			theScreen.playerState = scStopped;
			currentSong = null;
			currentAlbum = null;
        }
    } catch (e) {
		if( playlistRow != null ) playlistRow.textualContent = "";
		if( songRow != null ) songRow.textualContent = "Track N/A";
		if( artistRow != null ) artistRow.textualContent = "";
		if( albumRow != null ) albumRow.textualContent = "";
		theScreen.mediaLength = -1;
        theScreen.mediaPosition = -1;
		theScreen.mediaRating = -1;	
		theScreen.image = "";
		theScreen.playerState = scStopped;
		currentSong = null;
		currentAlbum = null;
    }
    
    if( setting_artwork_newlayout == 1 || theScreen.image == "" ) {
		theScreen.imageStyle = scFill;
		theScreen.imageOpacity = 0.5;
		if( songRow != null ) songRow.horizontalAlignment = scCenter;
		if( artistRow != null ) artistRow.horizontalAlignment = scCenter;
		if( albumRow != null ) albumRow.horizontalAlignment = scCenter;
	} else {
		theScreen.imageStyle = scFloatLeft;
		theScreen.imageOpacity = 1.0;
		theScreen.imageRowOffset = 1;	    
		if( songRow != null ) songRow.horizontalAlignment = scLeft;
		if( artistRow != null ) artistRow.horizontalAlignment = scLeft;
		if( albumRow != null ) albumRow.horizontalAlignment = scLeft;
	}
}

function mediaPlayer_ValueUpdated(theScreen, property)
{
    if (property == 4 /*PlayheadPosition*/ ) {
       // Setting new playhead position from device widget
        iTunes.PlayerPosition = mediaPlayer.mediaPosition;
    }
}

function mediaPlayer_Exit(theScreen)
{
    iTunes = null;
    mediaPlayer = null;
    moreMenu = null;
}

function mediaPlayer_KeyDown(theScreen, theKey)
{
    keyWasRepeated = false;
    try {
		if( theKey == "^" || theKey == "u" ) {
			changeVolume(5);
		} else if( theKey == "v" || theKey == "d" ) {
			changeVolume(-5);
		} else if( theKey == "c") {
			muteUnmute();
		} else if( theKey >= "0" && theKey <= "5" ) {
			setRating( theKey - "0" );
		}
	} catch (e) { 
	//iTunes = null;
    }        
}

function mediaPlayer_KeyRepeat(theScreen, theKey)
{    
    try {
        if( theKey == ">" ) {
            iTunes.PlayerPosition = iTunes.PlayerPosition + 5;

			var location = -1;
			
		    var track = iTunes.CurrentTrack;
		    if (track != null) {
				location = 100 * iTunes.PlayerPosition / track.Duration;
			}

            ShowMessage("", FForward, location);
        } else if( theKey == "<" ) {
            iTunes.PlayerPosition = iTunes.PlayerPosition - 5;

			var location = -1;
			
		    var track = iTunes.CurrentTrack;
		    if (track != null) {
				location = 100 * iTunes.PlayerPosition / track.Duration;
			}

            ShowMessage("", FRewind, location);
        } else if( theKey == "^" || theKey == "u" ) {
            changeVolume(5);
        } else if( theKey == "v" || theKey == "d" ) {
            changeVolume(-5);
        } else if( !keyWasRepeated && (theKey == "s" || theKey == "f" || theKey == "*") ) {
            theTerminal.ExecuteScript("2EC3593D-CD6F-41c3-A6F8-DB46F293E776");	            
        }
    }
    catch (e) { 
	//iTunes = null;
    }        
    keyWasRepeated = true;
}

function mediaPlayer_KeyUp(theScreen, theKey)
{
    if( ! keyWasRepeated && (theKey == "f" || theKey == "*") ) {
        moreMenu.selectedItem = setting_moremenu_item;
        theTerminal.Push(moreMenu);

    } else if( theKey == ">" ) {
        if( keyWasRepeated == false ) {
            iTunes.NextTrack();
            if( iTunes.CurrentTrack != null ) {
                ShowMessage(iTunes.CurrentTrack.Name, Next);
            }    
        } else {
            if (iTunes.CurrentTrack != null) ShowMessage(iTunes.CurrentTrack.Name, Play);
        }

    } else if( theKey == "<" ) {
        if (keyWasRepeated == false) {
            iTunes.BackTrack();
            if (iTunes.CurrentTrack != null) {
                ShowMessage(iTunes.CurrentTrack.Name, Previous);
            }    
        } else {
            if (iTunes.CurrentTrack != null) ShowMessage(iTunes.CurrentTrack.Name, Play);
        }

    } else if( theKey == ":help" || theKey == "#" ) {
	    showHelp();

	} else if( ! keyWasRepeated && theKey == "s" ) {
		if( iTunes.playerState != 0 ) {
			// Current state is playing, set to pause
			iTunes.Pause();	            
			ShowMessage("iTunes", Pause);
		} else {
			// Not playing, so start playing
			iTunes.Play();
			ShowMessage(iTunes.CurrentTrack.Name, Play);
		}
	}
    
    keyWasRepeated = false;
 }

// =============================================================================

function artworklayout_OK(dlg)
{
	currentSong = null;
	currentAlbum = null;
	setting_artwork_newlayout = dlg.value;
	writeSettings();	
    theTerminal.Popto("iTunes");	
}

function moreMenu_ValueUpdated(theScreen, theProperty)
{
	setting_moremenu_item = theScreen.selectedItem;
	writeSettings();
	
    if( moreMenuItemUUIDs[theScreen.selectedItem] != "" ) {
        theTerminal.ExecuteScript(moreMenuItemUUIDs[theScreen.selectedItem]);	
        
        // Force an update of the mediaplayer widget, before the next track starts
        currentSong = null;
        currentAlbum = null;
	} else if( theScreen.selectedItem == 13 ) {
		var layoutoptions = CreateOptionListDialog( "artworklayout_");
		layoutoptions.itemLabels = new Array("Artwork Left-aligned","Artwork in Background","No Artwork");
		layoutoptions.title = "Set Artwork Layout";
		layoutoptions.value = setting_artwork_newlayout;
		theTerminal.Push( layoutoptions );
	}
}

// =============================================================================

function setRating(rating)
{
	var track = iTunes.CurrentTrack;
	if( track != null ) {
		try {
			track.Rating = rating * 20;
		} catch( e ) {}
	}
}

function muteUnmute()
{
	if( iTunes.mute ) {
		iTunes.mute = false;
		ShowMessage("iTunes", Volume, iTunes.SoundVolume);
	} else {
		ShowMessage("iTunes", Mute, 0);
		iTunes.mute = true;
	}
}

function changeVolume(delta)
{   
    // Change volume by delta
    var soundVolume = iTunes.SoundVolume + delta;
    
	iTunes.mute = false;
    
    if (soundVolume < 0) {
        soundVolume = 0;
    } else if (soundVolume > 100) {
        soundVolume = 100;
    }
    
    iTunes.SoundVolume = soundVolume;
    
    if (soundVolume == 0) {
		ShowMessage("iTunes", Mute, soundVolume);
	} else {
		ShowMessage("iTunes", Volume, soundVolume);
	}
}

//=============================================================================

function updateMediaplayerWidget()
{   
    // Initialize with info from current track
    var track = iTunes.CurrentTrack;
    if (track != null) {
        mediaPlayer.mediaLength = track.Duration;
        
        if( playlistRow != null ) {
			playlistRow.textualContent = track.PlayOrderIndex + " of " + iTunes.CurrentPlaylist.Tracks.Count + " in " + iTunes.CurrentPlaylist.Name;
		}
		    
        if( songRow != null ) {
	        songRow.textualContent = track.Name;
        }
        
        var Album = track.Album;
        if( Album == null || Album == "" ) Album = "Unknown Album";

        var Artist = track.Artist;
        if( Artist == null || Artist == "" ) Artist = "Unknown Artist";
        
        if (theTerminal.displaySize == 4 /* scHuge */) {
			if( artistRow != null ) artistRow.textualContent = Album;
			if( albumRow != null ) albumRow.textualContent = Artist;
        } else {
			if( artistRow != null ) artistRow.textualContent = Album;
			if( albumRow != null ) albumRow.textualContent = Artist;
        }
                
        // Update artwork
		try {
       		var artworkCollection = track.Artwork;
        	if (artworkCollection == null || setting_artwork_newlayout == 2 ) {
            	// There isn't any artwork
            	mediaPlayer.image = "";
        	} else if (artworkCollection.Count == 0) {
            	// There isn't any artwork
            	mediaPlayer.image = "";
        	} else if (currentSong != track.Name || currentAlbum != track.Album) {
            	// Looks like new artwork, so update it.
            	var artwork = artworkCollection.Item(1);
            	var tfolder = fso.GetSpecialFolder(2);
            	var tfile = tfolder + "\\SallingClicker.tmp"
            	artwork.SaveArtworkToFile(tfile);
            	mediaPlayer.image = tfile;
        	}
        } catch( e ) {
            mediaPlayer.image = "";		
		}
        currentSong = track.Name;
        currentAlbum = track.Album;
    } else {
		if( playlistRow != null ) playlistRow.textualContent = "";
		if( songRow != null ) songRow.textualContent = "No track";
		if( artistRow != null ) artistRow.textualContent = "";
		if( albumRow != null ) albumRow.textualContent = "";
        mediaPlayer.mediaLength = -1;
        mediaPlayer.mediaPosition = -1;
		mediaPlayer.mediaRating = -1;	
		mediaPlayer.image = "";
		mediaPlayer.playerState = scStopped;
    }
}

//=============================================================================

function showHelp()
{
    var code = new Array();
    var title = new Array();
    var description = new Array();
    
    code[0] = "s";
    title[0] = "Player Mode";
    description[0] = "Click to toggle between play and pause. Hold to see current playlist.";

    code[1] = "<";
    title[1] = "Previous Track";
    description[1] = "Skips to the beginning of the currently playing track, or to the previous track if already at the beginning. Hold to scan a track backwards.";

    code[2] = ">";
    title[2] = "Next Track";
    description[2] = "Skips to the next track. Hold to scan a track forward.";

    code[3] = new Array("^", "u");
    title[3] = "Volume Up";
    description[3] = "Raises the listening volume.";

    code[4] = new Array("v", "d");
    title[4] = "Volume Down";
    description[4] = "Softens the listening volume.";

    code[5] = new Array("f", "*");
    title[5] = "More";
    description[5] = "More settings and commands. Hold to see current playlist.";

    theTerminal.ShowKeypadHelp("iTunes Help", code, title, description);    
}