var iTunes = null


var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("iTunes.exe")) {
	launchWidget();
} else {
	var launchQuestion = CreateQuestionDialog("launch_");
	launchQuestion.textualContent = "Launch iTunes?";
	theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
	launchWidget();
}

function launchWidget()
{
	iTunes = new ActiveXObject("iTunes.Application");
	
	var playlist = iTunes.LibraryPlaylist;
	var count = playlist.tracks.Count - 1;	
	//iTunes.BrowserWindow.SelectedPlaylist = playlist; // Broken in iTunes 7.1
	
	for( var i = 0; i < 10; i++ ) {
		// Play random track (try 10 times, in case a track is broken)
		var randomNumber = Math.random();
		var trackNumber = count * randomNumber + 1;
		var track = playlist.tracks.Item(trackNumber);
		try {
			track.Play();
			break;
		} catch( e ) {
		}
	}
    
    theTerminal.Popto("iTunes"); 
}

