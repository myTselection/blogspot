var iTunes = null;
var userPlaylists = null;
var theTrack = null;

var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("iTunes.exe")) {
	launchWidget();
} else {
	var launchQuestion = CreateQuestionDialog("launch_");
	launchQuestion.textualContent = "Launch iTunes?";
	theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
	launchWidget();
}

function launchWidget()
{
	iTunes = new ActiveXObject("iTunes.Application");
	
    theTrack = iTunes.CurrentTrack;
    if (theTrack == null) return;

    var mainLibrary = iTunes.LibrarySource;
    var playLists = mainLibrary.Playlists;
    
    // Build list of user playlists
    var playlistItems = new Array();
    userPlaylists = new Array();            
    for (var i = 1; i <= playLists.Count; i++)
    {
        var playlist = playLists.Item(i);
        if (playlist.Kind == 2 /* ITPlaylistKindUser */)
        {
            // Smart playlists cannot be modified
            if (playlist.Smart == false)
            {
                playlistItems.push(playlist.Name);
                userPlaylists.push(playlist);
            }
        }
    }
    
    if (playlistItems.length > 0)
    {
        var list = CreateListScreen( "addToPlaylist_");
        
        list.name = "More Menu add to playlist list";
        list.title = "Select Playlist";
        list.itemLabels = playlistItems;
        list.selectedItem = 0;
        
        theTerminal.Push(list);
    }
}

//=============================================================================

function addToPlaylist_ValueUpdated(theList, theProperty)
{
    var playlist = userPlaylists[theList.selectedItem];    
    userPlaylists = null;
    
    if (theTrack == null ) return;

	playlist.AddTrack(theTrack);
        
    theTerminal.PopTo("iTunes");
}