// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_searchstring = "";

// Read settings for this script
try {
	var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	if( settingsFileStream == null ) {
		// Write defaults
		writeSettings();
		settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	}
	while( true ) {
		var propertyName = settingsFileStream.ReadLine();
		var propertyValue = settingsFileStream.ReadLine();
		if( propertyName == "setting_searchstring" ) {
			setting_searchstring = propertyValue;
		}
	}
} catch( e ) {
} finally {
	if( settingsFileStream != null ) settingsFileStream.Close();	
}



var iTunes = null;
var tracks = null;

var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("iTunes.exe")) {
	launchWidget();
} else {
	var launchQuestion = CreateQuestionDialog("launch_");
	launchQuestion.textualContent = "Launch iTunes?";
	theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
	launchWidget();
}

function launchWidget()
{
	iTunes = new ActiveXObject("iTunes.Application");
	
    // Find by name
    var textField = CreateTextFieldDialog( "findSong_");
    
    textField.name = "More menu find name text field";
    textField.title = "Find by Name";
    textField.prompt = "Find:";     
    textField.value = setting_searchstring;
    
    theTerminal.Push(textField);   
}



function writeSettings()
{
	try {
		var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );	// overwrite
		settingsFileStream.WriteLine( "setting_searchstring" );
		settingsFileStream.WriteLine( setting_searchstring );
		settingsFileStream.Close();
	} catch( e ) {}
}


//=============================================================================

function findSong_OK(textfield)
{
    // Create list of all tracks with textfield.value in the artist's name and
    // play the track the user selects.
    
    if( setting_searchstring != textfield.value ) {
	    setting_searchstring = textfield.value;
	    writeSettings();
	}
    
    if( textfield.value.length < 3 ) {
        var messageBox = CreatePopupDialog( "");
        messageBox.textualContent = "Enter at least 3 letters";      
        theTerminal.Push( messageBox );       
        return true;
    }

    // Search the main library playlist and make it current
    var playlist = iTunes.LibraryPlaylist;
    tracks = playlist.Search(textfield.value, 5);
    
    if( tracks == null || tracks.Count == 0 ) {
        var messageBox = CreatePopupDialog( "");        
        messageBox.textualContent = "No tracks found";        
        theTerminal.Push(messageBox);        
        return true;
    }
    
    //
    
    var listItems = new Array();
    for( var i = 0; i < tracks.Count; i++ ) {
        var track = tracks.Item(i+1);
        listItems[i] = track.name;
    }

    var trackList = CreateListScreen( "playTrack_");    
    trackList.itemLabels = listItems;
    trackList.selectedItem = 0;
    trackList.title = "Select Track";  
    theTerminal.Push(trackList);
}

//=============================================================================

function playTrack_ValueUpdated(list, theProperty)
{
	var hitPlaylist = iTunes.LibrarySource.Playlists.ItemByName( "Clicker Playlist" );
	if( hitPlaylist != null ) {
		hitPlaylist.Delete();
	}
	hitPlaylist = iTunes.CreatePlaylist( "Clicker Playlist" );
	
	var theTrack = null;
	for( var i = 0; i < tracks.Count; i++ ) {
		var trk = hitPlaylist.AddTrack( tracks.Item(i+1) );
		if( i == list.selectedItem ) {
			theTrack = trk;
		}
	}
    
    iTunes.BrowserWindow.SelectedPlaylist = hitPlaylist;
	if( theTrack != null ) theTrack.Play();
    theTerminal.Popto("iTunes"); 
}
