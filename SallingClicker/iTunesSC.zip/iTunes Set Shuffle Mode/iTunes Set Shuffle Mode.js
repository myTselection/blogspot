var iTunes = null


var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("iTunes.exe")) {
	launchWidget();
} else {
	var launchQuestion = CreateQuestionDialog("launch_");
	launchQuestion.textualContent = "Launch iTunes?";
	theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
	launchWidget();
}

function launchWidget()
{
	iTunes = new ActiveXObject("iTunes.Application");
	
    // Playlist Shuffle
    var playList = iTunes.CurrentPlaylist;
    if (playList != null)
    {                     
        var onOffSelector = CreateBooleanSwitchDialog( "shuffle_");
        
        onOffSelector.name = "More menu shuffle on off selector";
        onOffSelector.title = "Shuffle";
        onOffSelector.value = playList.Shuffle;
        
        theTerminal.Push(onOffSelector);
    }
    else
    {
        var messageBox = CreateMessageboxDialog( "");
        
        messageBox.title = "Clicker";
        messageBox.textualContent = "No current playlist";
        
        theTerminal.Push(messageBox);
    }
}

//=============================================================================

function shuffle_OK(onOffSelector)
{
    var playList = iTunes.CurrentPlaylist;
    if (playList != null)
    {
        // Tell iTunes the new shuffle state        
        playList.Shuffle = onOffSelector.value;
    }
}
