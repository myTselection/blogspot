var helper = new ActiveXObject("SCHelper.SECHelper");
var shouldReactivate = false;

function CallStatusChanged( theTerminal, theCallStatus, thePhoneNumber, theCallType, theCID )
{
	if( theCallStatus == 1 ) {
	//	Phone went idle
		if( shouldReactivate == true ) {
			if( helper.IsProcessRunning("iTunes.exe") ) {
				var iTunes = new ActiveXObject("iTunes.Application");

				// Play and fade in				
				var targetVolume = iTunes.soundVolume;
				iTunes.soundVolume = 0;
				iTunes.Play();
				for( i = 0; i <= targetVolume; i++ ) {
					iTunes.soundVolume = i;
				}
			}
		}   
	} else if( theCallStatus == 2 || theCallStatus == 7 ) {
	//	Phone is calling (incoming) or alerting (outgoing)
		shouldReactivate = false;
		if( helper.IsProcessRunning("iTunes.exe") ) {
			var iTunes = new ActiveXObject("iTunes.Application");

			if( iTunes.PlayerState == 1 ) {
				shouldReactivate = true;
				
				// Fade out and pause				
				var oldVolume = iTunes.soundVolume;
				for( i = oldVolume; i >= 0; i-- ) {
					iTunes.soundVolume = i;
				}
				iTunes.Pause();
				iTunes.soundVolume = oldVolume;
			}
		}
	}	    
}
