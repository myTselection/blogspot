var iTunes = new ActiveXObject("iTunes.Application");	

var selected_playlist = iTunes.CurrentPlaylist;
if( selected_playlist.SpecialKind == 6 ) { // library    
	var popup = CreatePopupDialog("popup_");
	popup.textualContent = "Current playlist is a library playlist.";
	theTerminal.Push( popup );
} else {

    var tracks = selected_playlist.Tracks;
    var current_track = iTunes.CurrentTrack;
    var sel_index = 0;

    var listItems = new Array();
    var i = 0;
    for( var e = new Enumerator( tracks ); ! e.atEnd(); e.moveNext() ) {
        var track = e.item();
	    listItems.push( track.name );
	    if( track.trackID == current_track.trackID ) {
	        sel_index = i;
	    }
	    i++;
    }

    var list = CreateListScreen( "playTrack_");
    list.name = "Source list";
    list.title = iTunes.CurrentPlaylist.Name;
    list.itemLabels = listItems;
    list.selectedItem = sel_index;
        
    theTerminal.Push(list);
}

function playTrack_ValueUpdated(list, theProperty)
{
//    var song = list.itemLabels[list.selectedItem];
    iTunes.BrowserWindow.SelectedPlaylist = selected_playlist;
	selected_playlist.Tracks.Item(list.selectedItem+1).Play();
    theTerminal.Popto("iTunes"); 
}
