// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_searchstring = "";

// Read settings for this script
try {
	var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	if( settingsFileStream == null ) {
		// Write defaults
		writeSettings();
		settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	}
	while( true ) {
		var propertyName = settingsFileStream.ReadLine();
		var propertyValue = settingsFileStream.ReadLine();
		if( propertyName == "setting_searchstring" ) {
			setting_searchstring = propertyValue;
		}
	}
} catch( e ) {
} finally {
	if( settingsFileStream != null ) settingsFileStream.Close();	
}



var iTunes = null;
var tracks = null;

var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("iTunes.exe")) {
	launchWidget();
} else {
	var launchQuestion = CreateQuestionDialog("launch_");
	launchQuestion.textualContent = "Launch iTunes?";
	theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
	launchWidget();
}

function launchWidget()
{
	iTunes = new ActiveXObject("iTunes.Application");
	
    var textField = CreateTextFieldDialog( "find_");    
    textField.title = "Find by Artist";
    textField.prompt = "Artist:";     
    textField.value = setting_searchstring;    
    theTerminal.Push(textField);   
}


function writeSettings()
{
	try {
		var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );	// overwrite
		settingsFileStream.WriteLine( "setting_searchstring" );
		settingsFileStream.WriteLine( setting_searchstring );
		settingsFileStream.Close();
	} catch( e ) {}
}


//=============================================================================

function find_OK(textfield)
{
    if( setting_searchstring != textfield.value ) {
	    setting_searchstring = textfield.value;
	    writeSettings();
	}
    
    if( textfield.value.length < 3 ) {
        var messageBox = CreatePopupDialog( "");
        messageBox.textualContent = "Enter at least 3 letters";      
        theTerminal.Push( messageBox );       
        return true;
    }

    // Search the main library playlist and make it current
    var playlist = iTunes.LibraryPlaylist;
    var tracks = playlist.Search( textfield.value, 2 );
    if( tracks == null || tracks.Count == 0 ) {
        var messageBox = CreatePopupDialog( "");        
        messageBox.textualContent = "No artist found";        
        theTerminal.Push(messageBox);        
        return true;
    }

    //
    
    var listItems = new Array();
    for( var i = 0; i < tracks.Count; i++ ) {
        var track = tracks.Item(i+1);
        listItems[i] = track.Artist;
    }
    
    listItems.sort();
    var uniqueListItems = new Array();
    uniqueListItems.push( listItems[0] );
    for( var j = 1; j < listItems.length; j++ ) {
        if( listItems[j] != uniqueListItems[uniqueListItems.length-1] ) {
            uniqueListItems.push( listItems[j] );
        }
    }

    var groupList = CreateListScreen( "groupList_");
    groupList.itemLabels = uniqueListItems;
    groupList.selectedItem = 0;
    groupList.title = "Select Artist";
    theTerminal.Push( groupList );
}


function groupList_ValueUpdated( list, theProperty )
{
    selected_group = list.itemLabels[list.selectedItem];

    tracks = new Array();
    var found_track_names = new Array();
    var playlist = iTunes.LibraryPlaylist;
    var _tracks = playlist.Search( selected_group, 2 );
    for( var i = 1; i <= _tracks.Count; i++ ) {
        var track = _tracks.Item(i);
        if( track.Artist != "" && track.Artist == selected_group ) {
            tracks.push( track );
            found_track_names.push( track.name );
        }
    }
    
    var trackList = CreateListScreen( "playTrack_");
    trackList.itemLabels = found_track_names;
    trackList.selectedItem = 0;
    trackList.title = "Select Track";
    theTerminal.Push( trackList );   
}
        
//=============================================================================

function playTrack_ValueUpdated(list, theProperty)
{
	var hitPlaylist = iTunes.LibrarySource.Playlists.ItemByName( "Clicker Playlist" );
	if( hitPlaylist != null ) {
		hitPlaylist.Delete();
	}
	hitPlaylist = iTunes.CreatePlaylist( "Clicker Playlist" );

	var theTrack = null;
	for( var i = 0; i < tracks.length; i++ ) {
		var trk = hitPlaylist.AddTrack( tracks[i] );
		if( i == list.selectedItem ) {
			theTrack = trk;
		}
	}
    
    iTunes.BrowserWindow.SelectedPlaylist = hitPlaylist;
	if( theTrack != null ) theTrack.Play();
    theTerminal.Popto("iTunes"); 
}
