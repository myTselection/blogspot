
var iTunes = null

var playlists = null;
var sources = null;
var playlistItems = null;
var sourceItems = null;
var selected_playlist = null;

// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_source_item = 0;
var setting_playlist_item = 0;
var setting_track_item = 0;

// Read settings for this script
try {
	var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	if( settingsFileStream == null ) {
		// Write defaults
		writeSettings();
		settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	}
	while( true ) {
		var propertyName = settingsFileStream.ReadLine();
		var propertyValue = settingsFileStream.ReadLine();
		if( propertyName == "setting_source_item" ) {
			setting_source_item = parseInt( propertyValue );
		} else if( propertyName == "setting_playlist_item" ) {
			setting_playlist_item = parseInt( propertyValue );
		} else if( propertyName == "setting_track_item" ) {
			setting_track_item = parseInt( propertyValue );
		}
	}
} catch( e ) {
} finally {
	if( settingsFileStream != null ) settingsFileStream.Close();	
}



var helper = new ActiveXObject("SCHelper.SECHelper");
if( helper.IsProcessRunning("iTunes.exe") ) {
	launchWidget();
} else {
	var launchQuestion = CreateQuestionDialog("launch_");
	launchQuestion.textualContent = "Launch iTunes?";
	theTerminal.Push(launchQuestion);
}



function writeSettings()
{
	try {
		var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );	// overwrite
		settingsFileStream.WriteLine( "setting_source_item" );
		settingsFileStream.WriteLine( setting_source_item );
		settingsFileStream.WriteLine( "setting_playlist_item" );
		settingsFileStream.WriteLine( setting_playlist_item );
		settingsFileStream.WriteLine( "setting_track_item" );
		settingsFileStream.WriteLine( setting_track_item );
		settingsFileStream.Close();
	} catch( e ) {}
}


function launch_OK(widget)
{
	launchWidget();
}

function launchWidget()
{
	iTunes = new ActiveXObject("iTunes.Application");	
    sources = GetSources();    
    if( sources.length == 1 ) {
	    DisplayPlaylistsInSource( iTunes.LibrarySource );
    } else {
        DisplayListOfSources();
    }        
}

//=============================================================================

function DisplayListOfSources()
{
    sourceItems = new Array();
    for( var i = 0; i < sources.length; i++ ) {
        var source = sources[i];
        sourceItems.push(source.name);
    }

    var list = CreateListScreen( "sourcelist_");    
    list.name = "Source list";
    list.title = "Select Source";
    list.itemLabels = sourceItems;
    list.selectedItem = setting_source_item;
    theTerminal.Push(list);
}

//=============================================================================

function DisplayPlaylistsInSource(source)
{
    playlists = new Array();
    playlistItems = new Array();
    for( var i = 1; i <= source.Playlists.Count; i++ ) {
        var playlist = source.Playlists.Item(i);
        if( playlist.playlistID == iTunes.LibraryPlaylist.playlistID ) continue;        
        playlists.push(playlist);
        playlistItems.push(playlist.Name);
    }
    
    if( playlistItems.length > 0 ) {
        var list = CreateListScreen( "playlist_");
        
        list.name = "Playlist list";
        list.title = "Select Playlist";
        list.itemLabels = playlistItems;
        list.selectedItem = setting_playlist_item;
	}

	theTerminal.Push(list);
}

//=============================================================================

function sourcelist_ValueUpdated(theList, theProperty)
{
	if( setting_source_item != theList.selectedItem ) {
		setting_track_item = 0;
		setting_playlist_item = 0;
		setting_source_item = theList.selectedItem;
		writeSettings();
	}
	
    var source = sources[theList.selectedItem];
    
    DisplayPlaylistsInSource(source);
}

//=============================================================================

function playlist_ValueUpdated(theList, theProperty)
{
	if( setting_playlist_item != theList.selectedItem ) {
		setting_track_item = 0;
		setting_playlist_item = theList.selectedItem;
		writeSettings();
	}

    selected_playlist = playlists[theList.selectedItem]

    selectTrackFromListAndPlay();
}

//=============================================================================

function selectTrackFromListAndPlay()
{
	var tracks = selected_playlist.Tracks;
	
    if( tracks == null || tracks.Count == 0 ) {
        var messageBox = CreateMessageboxDialog( "");        
        messageBox.name = "No tracks found message box";
        messageBox.title = "Clicker";
        messageBox.textualContent = "No tracks found";        
        theTerminal.Push(messageBox);       
        return;
    }

    var listItems = new Array();
	for( var e = new Enumerator( tracks ); ! e.atEnd(); e.moveNext() ) {
		listItems.push( e.item().name );
    }

    var trackList = CreateListScreen( "playTrack_");    
    trackList.name = "Select track list";
    trackList.itemLabels = listItems;
    trackList.selectedItem = setting_track_item;
    trackList.title = "Select Track";      
    theTerminal.Push(trackList);
    
    return;
}

//=============================================================================

function playTrack_ValueUpdated(list, theProperty)
{
	if( setting_track_item != list.selectedItem ) {
		setting_track_item = list.selectedItem;
		writeSettings();
	}

    iTunes.BrowserWindow.SelectedPlaylist = selected_playlist;
	selected_playlist.Tracks.Item(list.selectedItem+1).Play();
    theTerminal.Popto("iTunes"); 
}

//=============================================================================

function GetSources()
{
    var sources = new Array();
    for( var i = 1; i <= iTunes.Sources.Count; i++ ) {
	    var source = iTunes.Sources.Item(i);	    
        if( source.Kind == 1 /* ITSourceKindLibrary */ ||
			source.Kind == 7 /* ITSourceKindSharedLibrary */ ||
			source.Kind == 2 /* ITSourceKindIPod */ ||
			source.Kind == 3 /* ITSourceKindAudioCD */ ||
			source.Kind == 6 /* ITSourceKindRadioTuner */ ||
			source.Kind == 4 /* ITSourceKindMP3CD */ ) {
            sources.push(source);
        }
    }    
    return sources;  
}