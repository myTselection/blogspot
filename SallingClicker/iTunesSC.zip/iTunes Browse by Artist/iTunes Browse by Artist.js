// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_artist_item = 0;
var setting_album_item = 0;
var setting_track_item = 0;

// Read settings for this script
try {
	var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	if( settingsFileStream == null ) {
		// Write defaults
		writeSettings();
		settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
	}
	while( true ) {
		var propertyName = settingsFileStream.ReadLine();
		var propertyValue = settingsFileStream.ReadLine();
		if( propertyName == "setting_artist_item" ) {
			setting_artist_item = parseInt( propertyValue );
		} else if( propertyName == "setting_album_item" ) {
			setting_album_item = parseInt( propertyValue );
		} else if( propertyName == "setting_track_item" ) {
			setting_track_item = parseInt( propertyValue );
		}
	}
} catch( e ) {
} finally {
	if( settingsFileStream != null ) settingsFileStream.Close();	
}


//
//
//

var iTunes = null
var selected_artist = null;
var selected_album = null;
var selected_track = null;
var album_tracks = null;
var xmlPath = null;

var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("iTunes.exe")) {
	launchWidget();
} else {
	var launchQuestion = CreateQuestionDialog("launch_");
	launchQuestion.textualContent = "Launch iTunes?";
	theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
	launchWidget();
}



function writeSettings()
{
	try {
		var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );	// overwrite
		settingsFileStream.WriteLine( "setting_artist_item" );
		settingsFileStream.WriteLine( setting_artist_item );
		settingsFileStream.WriteLine( "setting_album_item" );
		settingsFileStream.WriteLine( setting_album_item );
		settingsFileStream.WriteLine( "setting_track_item" );
		settingsFileStream.WriteLine( setting_track_item );
		settingsFileStream.Close();
	} catch( e ) {}
}



function launchWidget()
{
    // We need this later on
	iTunes = new ActiveXObject("iTunes.Application");

    xmlPath = iTunes.LibraryXMLPath;

    var xmldom = LoadDOM( xmlPath );
	
    try {
        if( xmldom == null ) {
        // We'll end up here with older versions of iTunes that lack the property used above
            var wsh = new ActiveXObject('WScript.Shell');
            var myMusicPath = wsh.RegRead("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders\\My Music");
            xmlPath = myMusicPath + "\\iTunes\\iTunes Music Library.xml";
            xmldom = LoadDOM( xmlPath );
    	}
    } catch( e ) {}

    try {
        if( xmldom == null ) {
        // We'll end up here with older versions of iTunes that lack the property used above
            var wsh = new ActiveXObject('WScript.Shell');
            var personalPath = wsh.RegRead("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders\\Personal");
            xmlPath = personalPath + "\\My Music\\iTunes\\iTunes Music Library.xml";
            xmldom = LoadDOM( xmlPath );
    	}
    } catch( e ) {}

    if( xmldom == null ) {
        var messageBox = CreateMessageboxDialog( "");
        messageBox.title = "Cannot find Library";
        messageBox.textualContent = "Please upgrade iTunes so we can better locate your music.";
        theTerminal.Push(messageBox);
        return;
    }


    // Parse XML DB to get the list of available artists
    var artist_list = new Array();
    artist_list.push("All");

    var xsldom = LoadDOM( resourcesPath + "\\artists.xsl" );
    var output = xmldom.transformNode( xsldom );
    var artists = output.split("\r\n");

    // Remove duplicates    
	artist_list.push(artists[0]);
	for( var j = 1; j < artists.length; j++ ) {
		if( artists[j] != artist_list[artist_list.length-1] ) {
			artist_list.push( artists[j] );
		}
	}        

    // Populate and show a list widget    
    var list = CreateListScreen( "browse_");
    list.name = "More Menu browse by artist list";
    list.title = "Select Artist";
    list.itemLabels = artist_list;
    list.selectedItem = setting_artist_item;
    theTerminal.Push(list);
}



//
// An artist was selected - show list of albums
//

function browse_ValueUpdated(list, property)
{
	if( setting_artist_item != list.selectedItem ) {
		setting_track_item = 0;
		setting_album_item = 0;
		setting_artist_item = list.selectedItem;
		writeSettings();
	}
    
    selected_artist = list.itemLabels[list.selectedItem];

    var album_list = new Array();

    if( selected_artist == "All" ) {
        // Parse XML DB to get the list of available artists
        var xmldom = LoadDOM( xmlPath );
        var xsldom = LoadDOM( resourcesPath + "\\albums.xsl" );
        var output = xmldom.transformNode( xsldom );
        var albums = output.split("\r\n");

        // Remove duplicates    
	    album_list.push(albums[0]);
	    for( var j = 1; j < albums.length; j++ ) {
		    if( albums[j] != album_list[album_list.length-1] ) {
			    album_list.push( albums[j] );
		    }
	    }        

    } else {
        // Collect a list of all albums where this artist participates 
        var albums = new Array();
        var playlist = iTunes.LibraryPlaylist;
        var tracks = playlist.Search( selected_artist, 2 );
        for( var i = 1; i <= tracks.Count; i++ ) {
            var track = tracks.Item(i);
            if( track.Album != "" && track.Artist == selected_artist ) {
                albums.push( track.Album );
            }
        }

        // Remove duplicates
        album_list.push("All");
        if( albums.length > 0 ) {
            albums.sort();
            album_list.push(albums[0]);
        }
        for( var j = 1; j < albums.length; j++ ) {
            if( albums[j] != album_list[album_list.length-1] ) {
                album_list.push(albums[j]);
            }
        }
    }

    // Populate and show a list widget
    var list = CreateListScreen( "browse_album_");
    list.name = "More Menu browse by artist album list";
    list.title = "Select Album";
    list.itemLabels = album_list;
    list.selectedItem = setting_album_item;    
    theTerminal.Push(list);
}



//
// An album was selected - show list of tracks
//

function browse_album_ValueUpdated(list, property)
{
	if( setting_album_item != list.selectedItem ) {
		setting_track_item = 0;
		setting_album_item = list.selectedItem;
		writeSettings();
	}

    selected_album = list.itemLabels[list.selectedItem];    
    
    var playlist = iTunes.LibraryPlaylist;
    var tracks = null;
    
    if( selected_album == "All" && selected_artist == "All" ) {
    // Will never happen
    } else if (selected_album == "All") {
        tracks = playlist.Search(selected_artist, 2);
    } else if (selected_artist == "All") {
        tracks = playlist.Search(selected_album, 3);
    } else {
        tracks = playlist.Search(selected_album, 3);
    }
    
    // No matching tracks?
    if( tracks == null || tracks.Count == 0 ) {
        var messageBox = CreateMessageboxDialog( "");
        messageBox.name = "No tracks found message box";
        messageBox.title = "Clicker";
        messageBox.textualContent = "No tracks found";
        theTerminal.Push(messageBox);
        return;
    }

    // Build a list of matching tracks. We require both album and artist to match. The supplied list of tracks
    // may be larger.
    album_tracks = new Array();
    for( var i = 0; i < tracks.Count; i++ ) {
        var track = tracks.Item(i+1);
        if ( (track.Album == selected_album || selected_album == "All") && 
             (track.Artist == selected_artist || selected_artist == "All" ) ) {
            album_tracks.push( track );
	    }
    }

    // Sort tracks list if an album has been selected
    if( selected_album != "All" && selected_album != "" ) {
        album_tracks.sort( compareTracksByIndex );
    }

    var listItems = new Array();
    for( var i = 0; i < album_tracks.length; i++ ) {
        var track = album_tracks[i];
		listItems.push( track.name );
    }    

    // Populate and show a list widget
    var trackList = CreateListScreen( "playTrack_");
    trackList.name = "Select track list";
    trackList.itemLabels = listItems;
    trackList.selectedItem = setting_track_item;
    trackList.title = "Select Track";
    theTerminal.Push(trackList);   
}

function compareTracksByIndex( a, b )
{
	var aidx = a.TrackNumber;            
	var bidx = b.TrackNumber;            

    if( aidx != null && aidx != 0 && bidx != null && bidx != 0 ) {
        return aidx - bidx; // A negative value if the first argument passed is less than the second argument.
    } else if( aidx != null && aidx != 0 ) {
        return -1; // a comes before b
    } else if( bidx != null && bidx != 0 ) {
        return 1; // a comes after b
    } else {
        return 0; // we don't care
    }
}



//
// A track was selected - play it
//

function playTrack_ValueUpdated(list, theProperty)
{
	if( setting_track_item != list.selectedItem ) {
		setting_track_item = list.selectedItem;
		writeSettings();
	}

    selected_track = list.itemLabels[list.selectedItem];

	var albumPlaylist = iTunes.LibrarySource.Playlists.ItemByName( "Clicker Playlist" );
	if( albumPlaylist != null ) {
		albumPlaylist.Delete();
	}
	var albumPlaylist = iTunes.CreatePlaylist( "Clicker Playlist" );
	
	var theTrack = null;
	for( var i = 0; i < album_tracks.length; i++ ) {
		var trk = albumPlaylist.AddTrack( album_tracks[i] );
		if( i == list.selectedItem ) {
			theTrack = trk;
		}
	}

    iTunes.BrowserWindow.SelectedPlaylist = albumPlaylist;

	if( theTrack != null ) {
		theTrack.Play();
    }
    
    theTerminal.Popto("iTunes"); 
}


//
// MSXML helpers
//

function LoadDOM(file)
{
    var dom;
    dom = MakeDOM(null);
    if( ! dom.load( file ) ) return null;
    return dom;
}

function MakeDOM(progID)
{
    if( progID == null ) {
        progID = "msxml2.DOMDocument.3.0";
    }

    var dom;
    dom = new ActiveXObject(progID);
    dom.async = false;
    dom.validateOnParse = false;
    dom.resolveExternals = false;

    return dom;
}