var iTunes = null


var helper = new ActiveXObject("SCHelper.SECHelper");
if (helper.IsProcessRunning("iTunes.exe")) {
	launchWidget();
} else {
	var launchQuestion = CreateQuestionDialog("launch_");
	launchQuestion.textualContent = "Launch iTunes?";
	theTerminal.Push(launchQuestion);
}

function launch_OK(w)
{
	launchWidget();
}

function launchWidget()
{
	iTunes = new ActiveXObject("iTunes.Application");
	
    var track = iTunes.CurrentTrack;
    if (track != null)
    {
        var slider = CreateSliderDialog( "sliderRateTrack_");
        
        slider.name = "More menu rating slider";
        slider.title = "Rate Track";
        slider.maxValue = 5;
        slider.value = track.Rating / 20;
        
        theTerminal.Push(slider);
    }
}

//=============================================================================

function sliderRateTrack_OK(slider)
{   
	var error = false;
	
    var track = iTunes.CurrentTrack;
    if (track != null)
    {
        try
        {
            track.Rating = slider.value * 20;
        }
        catch (exception)
        {
            error = true;
        }    
        
        if (error == true)
        {
            var messageBox = CreateMessageboxDialog( "");
            
            messageBox.title = "Clicker";
            messageBox.textualContent = "Unable to change rating";
            
            theTerminal.Push(messageBox);
        }
    }
}