var WM_WDVD_CMD     = 0x111;
var WDVD_Mute       = 0x00018663;

try {
var wdvdwh = FindWindow( "WinDVDClass", "Intervideo WinDVD 7");
if( wdvdwh == 0 ) {
   throw "WinDVD not started.";
} else {
   ActivateWindow( wdvdwh );
   SendMessage( wdvdwh, WM_WDVD_CMD, WDVD_Mute, 0 );
}
} catch( e ) {}