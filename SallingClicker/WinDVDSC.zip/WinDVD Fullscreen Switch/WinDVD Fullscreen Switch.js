var WM_WDVD_CMD     = 0x111;
var WDVD_FS_Switch  = 0x000186A3;

try {
var wdvdwh = FindWindow( "WinDVDClass", "Intervideo WinDVD 7");
if( wdvdwh == 0 ) {
   throw "WinDVD not started.";
} else {
   ActivateWindow( wdvdwh );
   SendMessage( wdvdwh, WM_WDVD_CMD, WDVD_FS_Switch, 0 );
}
} catch( e ) {}