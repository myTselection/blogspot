var WM_WDVD_CMD     = 0x111; //WM_COMMAND
//var BSP_SetVol      = 0x10104;
//var BSP_GetVol      = 0x10105;
//var BSP_GetStatus   = 0x10102;
//var BSP_GetMovLen   = 0x10100;
//var WDVD_GetMovPos  = 0;
//var BSP_Seek        = 0x10103;
//var BSP_GetFileName = 0x1010B;

var WDVD_FF         = 0x000186B0;
var WDVD_FR         = 0x000186B1;
var WDVD_NChap      = 0x00018687;
var WDVD_PChap      = 0x00018686;
var WDVD_VolUp      = 0x000186AE;
var WDVD_VolDown    = 0x000186AF;
var WDVD_Up         = 0x000186b2;
var WDVD_Down       = 0x000186b3;
var WDVD_Left       = 0x000186b4;
var WDVD_Right      = 0x000186b5;
var WDVD_Select     = 0x00018689;
var WDVD_Pause      = 0x0001875B;
var WDVD_Menu       = 0x000184d6;
var WDVD_Exit       = 0x00018684;

//for double function
var PlayMode        = false;
var Key_Left        = WDVD_Left;
var Key_Right       = WDVD_Right;
var Key_Up          = WDVD_Up;
var Key_Down        = WDVD_Down;
var Key_Center      = WDVD_Select;

var keyRepeated     = false;
var sampleRow       = null;

// Initialize more menu items

var moreMenuItems = new Array();
moreMenuItems[0] = "Open DVD";
moreMenuItems[1] = "Open File";
moreMenuItems[2] = "DVD Menu";
moreMenuItems[3] = "Fullscreen/Window";
moreMenuItems[4] = "Mute/Unmute";
//moreMenuItems[5] = "OSD On/Off";
moreMenuItems[5] = "Quit";

var moreMenuItemUUIDs = new Array();
moreMenuItemUUIDs[0] = "d0fda4c0-8817-11da-a72b-0800200c9a66";   // Open DVD
moreMenuItemUUIDs[1] = "7597e790-8794-11da-a72b-0800200c9a66";   // Open File
moreMenuItemUUIDs[2] = "7c1213c0-8794-11da-a72b-0800200c9a66";   // DVD Menu
moreMenuItemUUIDs[3] = "828ab950-8794-11da-a72b-0800200c9a66";   // Fullscreen/Window
moreMenuItemUUIDs[4] = "8ab1d230-8794-11da-a72b-0800200c9a66";   // Mute/Unmute
//moreMenuItemUUIDs[5] = "OSD";                                    // activate/deactivate OSD (!slow when inc/dec volume!) -
moreMenuItemUUIDs[5] = "Exit";                                   // Quit



//Read Settings
// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_OSD             = true;

// Read settings for this script
try {
   var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
   if( settingsFileStream == null ) {
      // Write defaults
      writeSettings();
      settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
   }
   while( true ) {
      var propertyName = settingsFileStream.ReadLine();
      var propertyValue = settingsFileStream.ReadLine();
      if( propertyName == "setting_OSD" ) {
         var temp = parseInt( propertyValue );
         if (temp == 0) {
            setting_OSD = false;
         } else {
            setting_OSD = true;
         }
      }
   }
} catch( e ) {
} finally {
   if( settingsFileStream != null ) settingsFileStream.Close();
}

// Check if WinDVD is installed, and get the exe path if it is.

var WinDVDPath = null;
try {
   var wsh = new ActiveXObject('WScript.Shell');
   //Will only work with WinDVD 7, search the registry for WinDVD Path if you have an other version
   WinDVDPath = wsh.RegRead("HKEY_CURRENT_USER\\Software\\InterVideo\\WinDVD4\\Path");
} catch( e ) {}

if( WinDVDPath == null ) {
   var widget = CreatePopupDialog( "" ); // not interested in callbacks
   widget.textualContent = "Cannot find WinDVD.";
   theTerminal.Push( widget );
   exit();
}

// Check if WinDVD is launched

var wdvdwh = 0;
try {
   wdvdwh = FindWindow( "WinDVDClass", "Intervideo WinDVD 5");
} catch( e ) {
}

if( wdvdwh == 0 ) {
   new ActiveXObject("Shell.Application").ShellExecute( WinDVDPath+"\\WinDVD.exe", "" );
}

launchWidget();
exit();

// Helpers and callbacks
function writeSettings()
{
   try {
      var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );   // overwrite
      var temp = 0;
      settingsFileStream.WriteLine( "setting_OSD" );
      if (setting_OSD) {
         temp = 1;
      } else {
         temp = 0;
      }
      settingsFileStream.WriteLine( temp );
      settingsFileStream.Close();
   } catch( e ) {}
}

function launchWidget()
{
   var widget = CreateMediaplayerScreen( "mykeypad_" );
   widget.title = "WinDVD";
   widget.name = "WinDVD";
   sampleRow = widget.CreateRow( "", scCenter, scWrap, scLarge );
   theTerminal.Push( widget );
}


function mykeypad_Update( theScreen )
{
   try {

      var wdvdwh = 0;
      try {
         wdvdwh = FindWindow( "WinDVDClass", "Intervideo WinDVD 5");
      } catch( e ) {}

      if( wdvdwh == 0 ) {
         throw "WinDVD not launched";
      } else {
        if (PlayMode) {
         sampleRow.textualContent = "Play Mode";
        } else {
         sampleRow.textualContent = "Menu Mode";
        }
      }

   } catch( e ) {
      if( sampleRow != null ) sampleRow.textualContent = e;
      theScreen.mediaLength = -1;
      theScreen.mediaLength = -1;
      theScreen.playerState = scIndeterminate;
   }

}

function mykeypad_KeyDown( theScreen, theKey )
{
   try {
      var wdvdwh = FindWindow( "WinDVDClass", "Intervideo WinDVD 5");
      if( wdvdwh == 0 ) {
         new ActiveXObject("Shell.Application").ShellExecute( WindDVDPath+"\\WinDVD.exe", "" );
         throw "null player";
      }

      ActivateWindow( wdvdwh );

      if( theKey == "^" || theKey == "u" ) {
         SendMessage( wdvdwh, WM_WDVD_CMD, Key_Up, 0 );
         /*if (setting_OSD) {
            var volume = SendMessage( wdvdwh, WM_WDVD_CMD, WDVD_GetVol, 0 );
            volume = volume * 100 / 25; // normalize to 0-100
            ShowMessage("", Volume);
         }*/
      } else if( theKey == "v" || theKey == "d" ) {
         SendMessage( wdvdwh, WM_WDVD_CMD, Key_Down, 0 );
         /*if (setting_OSD) {
            var volume = SendMessage( wdvdwh, WM_WDVD_CMD, WDVD_GetVol, 0 );
            volume = volume * 100 / 25; // normalize to 0-100
            if (volume > 0) {
               ShowMessage("", Volume, volume);
            } else {
               ShowMessage("", Mute, volume);
            }
         }*/
      } else if( theKey == ">" ) {
        SendMessage( wdvdwh, WM_WDVD_CMD, Key_Right, 0 );
        /*if (setting_OSD) {
           var pos = 100*mediaPos/mediaLength;
           ShowMessage("", FForward, pos);
        }*/
      } else if( theKey == "<" ) {
        SendMessage( wdvdwh, WM_WDVD_CMD, Key_Left, 0 );
        /*if (setting_OSD) {
            var pos = 100*mediaPos/mediaLength;
            ShowMessage("", FRewind, pos);
        }*/
      }


   } catch( e ) {}

   keyRepeated = false;

   // Keep the keypad active
   return true;
}

function mykeypad_KeyRepeat( theScreen, theKey )
{
   try {
      var wdvdwh = FindWindow( "WinDVDClass", "Intervideo WinDVD 5");
      if( wdvdwh == 0 ) throw "null player";

      if( theKey == "s" && !keyRepeated ) {
         switchKeys();
      } else if( theKey == "^" || theKey == "u" ) {
         SendMessage( wdvdwh, WM_WDVD_CMD, Key_Up, 0 );
         /*if (setting_OSD) {
            var volume = SendMessage( wdvdwh, WM_WDVD_CMD, WDVD_GetVol, 0 );
            volume = volume * 100 / 25; // normalize to 0-100
            ShowMessage("", Volume, volume);
         }*/
      } else if( theKey == "v" || theKey == "d" ) {
         SendMessage( wdvdwh, WM_WDVD_CMD, Key_Down, 0 );
         /*if (setting_OSD) {
            var volume = SendMessage( wdvdwh, WM_WDVD_CMD, WDVD_GetVol, 0 );
            volume = volume * 100 / 25; // normalize to 0-100
            if (volume > 0) {
               ShowMessage("", Volume, volume);
            } else {
               ShowMessage("", Mute, volume);
            }
        } */
      } else if( theKey == ">" ) {
        if (PlayMode) {
           SendMessage( wdvdwh, WM_WDVD_CMD, WDVD_NChap, 0 );
        } else {
           SendMessage( wdvdwh, WM_WDVD_CMD, Key_Right, 0 );
        }
        /*if (setting_OSD) {
           var pos = 100*mediaPos/mediaLength;
           ShowMessage("", FForward, pos);
        }*/
      } else if( theKey == "<" ) {
        if (PlayMode) {
           SendMessage( wdvdwh, WM_WDVD_CMD, P_Chap, 0 );
        } else {
          SendMessage( wdvdwh, WM_WDVD_CMD, Key_Left, 0 );
        }
        /*if (setting_OSD) {
               var pos = 100*mediaPos/mediaLength;
               ShowMessage("", FRewind, pos);
        }*/
      }
   } catch( e ) {}

   keyRepeated = true;
}


function mykeypad_KeyUp( theScreen, theKey )
{
   try {
      var wdvdwh = FindWindow( "WinDVDClass", "Intervideo WinDVD 5");
      if( wdvdwh == 0 ) throw "null player";

      if( theKey == "s" && ! keyRepeated ) {
         SendMessage( wdvdwh, WM_WDVD_CMD, Key_Center, 0 );
         /*if (setting_OSD){
            var status = SendMessage( wdvdwh, WM_WDVD_CMD, WDVD_GetStatus, 0 );
            switch( status ) {
               case 0:
                  ShowMessage("", Stop);
                  break;
               case 1:
                  ShowMessage("", Pause);
                  break;
               case 2:
                  ShowMessage("", Play);
                  break;
            }
         }*/
      } else if( theKey == "f" ) {
         showMenu();
      } else if (theKey == ":help" || theKey == "#") {
         showHelp();
      }
   } catch( e ) {}

   return true;
}


function mykeypad_ValueUpdated(theScreen, property)
{
//   try {
//      wdvdwh = FindWindow( "WinDVDClass", "Intervideo WinDVD 5");
//      if( wdvdwh == 0 ) throw "null player";
//      if (property == 4 /*PlayheadPosition*/ ) {
      // Setting new playhead position from device widget
//         SendMessage( wdvdwh, WM_WDVD_CMD, WDVD_Seek, theScreen.mediaPosition*1000 );
//      }
//   } catch( e ) {}
}

function switchKeys()
{
   if (PlayMode) {
      Key_Up     = WDVD_Up;
      Key_Down   = WDVD_Down;
      Key_Left   = WDVD_Left;
      Key_Right  = WDVD_Right;
      Key_Center = WDVD_Select;
      var wdvdwh = FindWindow( "WinDVDClass", "Intervideo WinDVD 5");
      if( wdvdwh == 0 ) {
         throw "WinDVD not started.";
      } else {
        //switch to DVD Menu
         ActivateWindow( wdvdwh );
         SendMessage( wdvdwh, WM_WDVD_CMD, WDVD_Menu, 0 );
      }
   } else {
      Key_Up     = WDVD_VolUp;
      Key_Down   = WDVD_VolDown;
      Key_Left   = WDVD_FR;
      Key_Right  = WDVD_FF;
      Key_Center = WDVD_Pause;
   }
   PlayMode = !PlayMode;
}

function showMenu()
{
   var moreMenu = CreateListScreen( "moreMenu_");
   moreMenu.name = "More menu list";
   moreMenu.title = "More";
   moreMenu.selectedItem = 0;
   moreMenu.itemLabels = moreMenuItems;
   theTerminal.Push( moreMenu );
}


function moreMenu_ValueUpdated(theScreen, theProperty)
{
   try {
      var uuid = moreMenuItemUUIDs[theScreen.selectedItem];
      if( uuid == "Exit" ) {
         wdvdwh = FindWindow( "WinDVDClass", "Intervideo WinDVD 5");
         if( wdvdwh == 0 ) throw "null player";
         SendMessage( wdvdwh, WM_WDVD_CMD, WDVD_Exit, 0 );
         theTerminal.PopTo("WinDVD");
         return false;
      } else if (uuid == "OSD"){
         setting_OSD = !setting_OSD;
         writeSettings();
         return false;
      } else if( uuid != "" ) {
         theTerminal.ExecuteScript(moreMenuItemUUIDs[theScreen.selectedItem]);
         // Force an update of the mediaplayer widget, before the next track starts
         //currentSong = null;
         //currentAlbum = null;
      }
   } catch( e ) {}
}


function showHelp()
{
    var code = new Array();
    var title = new Array();
    var description = new Array();
    if (PlayMode) {
       code[0] = "s";
       title[0] = "Play/Pause/Menu Mode";
       description[0] = "Play Mode: Toggle the player state. Hold to switch to DVD Menu and Menu Mode. Menu Mode must be used to Navigate a DVD menu.";

       code[1] = new Array("v", "d");
       title[1] = "Volume Down";
       description[1] = "Play Mode: Softens the listening volume.";

       code[2] = new Array("^", "u");
       title[2] = "Volume Up";
       description[2] = "Play Mode: Raises the listening volume.";

       code[3] = new Array("<");
       title[3] = "Reverse Playback";
       description[3] = "Play Mode: Start/accelerate Reverse Playback (-x1/-x2/-x4/-x8/-x20/-x60).";

       code[4] = new Array(">");
       title[4] = "Fast Playback";
       description[4] = "Play Mode: Accelerate Playback Speed (x2/x4/x8/x20/x60/x1).";

    } else {
       code[0] = "s";
       title[0] = "Select/Play Mode"
       description[0] = "Menu Mode: Select Item. Hold to switch to Play Mode.  Play Mode must be used to control the playback of a DVD/movie."

       code[1] = new Array("v", "d");
       title[1] = "Down";
       description[1] = "Menu Mode: Navigate down in the DVD menu.";

       code[2] = new Array("^", "u");
       title[2] = "Up";
       description[2] = "Menu Mode: Navigate up in the DVD menu.";

       code[3] = new Array("<");
       title[3] = "Left";
       description[3] = "Menu Mode: Navigate left in the DVD menu.";

       code[4] = new Array(">");
       title[4] = "Right";
       description[4] = "Menu Mode: Navigate right in the DVD menu.";
    }
    code[5] = new Array("f", "*");
    title[5] = "More";
    description[5] = "Other settings and commands";
    theTerminal.ShowKeypadHelp("WinDVD Help", code, title, description);
}