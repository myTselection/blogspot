var browsePath = "";

// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_path = null;

// Read settings for this script
try {
   var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
   if( settingsFileStream == null ) {
      // Write defaults
      writeSettings();
      settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
   }
   while( true ) {
      var propertyName = settingsFileStream.ReadLine();
      var propertyValue = settingsFileStream.ReadLine();
      if( propertyName == "setting_path" ) {
         browsePath = propertyValue;
      }
   }
} catch( e ) {
} finally {
   if( settingsFileStream != null ) settingsFileStream.Close();
}


launchBrowser();


function writeSettings()
{
   try {
      var settingsFileStream = fso.CreateTextFile( settingsPath + "\\settings.txt", true );   // overwrite
      settingsFileStream.WriteLine( "setting_path" );
      settingsFileStream.WriteLine( browsePath );
      settingsFileStream.Close();
   } catch( e ) {}
}

function launchBrowser()
{
   var browser = CreateListScreen( "browser_");
   browser.name = "More menu open presentation";
   browser.title = "Select File";
   browser.selectedItem = 0;
   browser.itemLabels = getDrives();
   theTerminal.Push( browser );
}



function browser_ValueUpdated( browser, property )
{
    var drive = browser.itemLabels[browser.selectedItem];

    if( fso.DriveExists( drive ) ) {
      // Selected a drive
      var wsh = new ActiveXObject('WScript.Shell');
      var WinDVDPath = wsh.RegRead("HKEY_CURRENT_USER\\Software\\InterVideo\\DVD7\\Path");
      if( WinDVDPath != null ) {
         new ActiveXObject("Shell.Application").ShellExecute( WinDVDPath + "\\WinDVD.exe", "\"" + drive + "\"" );
          theTerminal.PopTo( "WinDVD" );
        }
        return false;
    }
    // Don't pop browser from stack
    return true;
}

function getDrives() {
   var items = new Array();
   var e = new Enumerator( fso.Drives );
   for( ; !e.atEnd(); e.moveNext() ) {
      var x = e.item();
      items.push( x.DriveLetter + ":" );
   }
   return items;
}