
function getAppPath()



//****************YOU MAY NEED TO EDIT THIS PATH********************

{
    var path = "C:\\Program Files\\Media Center Alarm Clock\\MCAlarmClock2.exe"; 
//************************************************************************************

    
    return path;
}

function launch()
{
    var shell = new ActiveXObject("Shell.Application");
    shell.ShellExecute(getAppPath(), "" )
}

launch();

{
var generalNavigatorkeypad = CreateKeypadScreen( "generalNavigatorkeypad_" );
generalNavigatorkeypad.title = "MCE Alarm Clock";
generalNavigatorkeypad.CreateRow( "", sccenter, scWrap, scmedium );
generalNavigatorkeypad.CreateRow( "Navigate & Select", sccenter, scWrap, scLarge );
generalNavigatorkeypad.CreateRow( "", sccenter, scWrap, scmedium );
generalNavigatorkeypad.CreateRow( "Use keypad to enter time manually", sccenter, scWrap, scsmall );
generalNavigatorkeypad.CreateRow( "Hold 'Center' button on Exit", sccenter, scWrap, scsmall );

   theTerminal.Push( generalNavigatorkeypad );    
}


function generalNavigatorkeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "WindowsForms10.Window.8.app1", "Alarm Clock" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "0": 
	SendVirtualKeystroke( 0x30, false, false, false, false);
        break;
   case "1":
      SendVirtualKeystroke( 0x31, false, false, false, false);
	break;
   case "2":
	SendVirtualKeystroke( 0x32, false, false, false, false);
	break;
   case "3": 
	SendVirtualKeystroke( 0x33, false, false, false, false);
	break;
   case "4":
	SendVirtualKeystroke( 0x34, false, false, false, false);
	break;
   case "5":
	SendVirtualKeystroke( 0x35, false, false, false, false);
	break;
   case "6":
	SendVirtualKeystroke( 0x36, false, false, false, false);
	break;
   case "7":
	SendVirtualKeystroke( 0x37, false, false, false, false);
	break;
   case "8":
	SendVirtualKeystroke( 0x38, false, false, false, false); 
	break;
   case "9":
	SendVirtualKeystroke( 0x39, false, false, false, false);
	break;
        
     case "v":
	SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
	break;

     case "^":
	SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW             
	break;

     case "<":
        SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
	break;

     case ">":
        SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
	break;

  case "#":	        
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    theTerminal.PopTo("MainMenu");
    break;
  case "0x0020":	        
    showSettingsMenu();
    break;
  case "*":	        
    SendVirtualKeystroke( 0x08, false, false, false, false); //BACKSPACE
    break;        

default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;

}


function generalNavigatorkeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "WindowsForms10.Window.8.app1", "Alarm Clock" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {        
     case "v":
	SendVirtualKeystroke( 0x22, false, false, false, false); //DOWN ARROW
	break;

     case "^":
	SendVirtualKeystroke( 0x21, false, false, false, false);  //UP ARROW             
	break;
     case "s":
        SendVirtualKeystroke( 0x0d, false, false, false, false); 
	theTerminal.PopTo("MainMenu");
     	break
	     
default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;

}

function generalNavigatorkeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "WindowsForms10.Window.8.app1", "Alarm Clock" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
     case "s":
        SendVirtualKeystroke( 0x0d, false, false, false, false); // SELECT
        break;
default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;

}

