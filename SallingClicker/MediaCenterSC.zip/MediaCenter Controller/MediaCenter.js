//Press the 'More' button to toggle between "Brower" and "Player" modes
//Hold the 'Center' button to return to the Menu screen
//From Menu Mode: Hold 'Display' to bring up system Settings.
//From Controller mode: Hold 'More' to bring up more player functions.
//Press '*' to go back one screen.
//Press '#' to go to the Main Meu


//-------------------------- Main Menu Items: edit Items you don't want------
var MenuItems = new Array();
MenuItems[0] = "Music";
MenuItems[1] = "DVD";                    
MenuItems[2] = "TV";
MenuItems[3] = "Radio";
MenuItems[4] = "Videos";        
MenuItems[5] = "Pictures";
MenuItems[6] = "Weather";
MenuItems[7] = "Alarm Clock";
MenuItems[8] = "Close MediaCenter"
MenuItems[9] = "(Directionals)";

//----------------------------------------------------------------------------
var MenuItemUUIDs = new Array();
MenuItemUUIDs[6] = "108d204c-da93-11db-8314-0800200c9a66";   //Weather
MenuItemUUIDs[7] = "74e11e90-da95-11db-8314-0800200c9a66";   //Alarm Clock

// Create more menu items listing
var morePicsMenuItems = new Array();
morePicsMenuItems[0] = "Zoom";
morePicsMenuItems[1] = "Right-Click Options";
morePicsMenuItems[2] = "Back/Escape";
morePicsMenuItems[3] = "MCE Main Menu";

// Create more menu items listing
var SettingsMenuItems = new Array();
SettingsMenuItems[0] = "Fullscreen";
SettingsMenuItems[1] = "More Display Options";
SettingsMenuItems[2] = "Right-Click Options";
SettingsMenuItems[3] = "Back/Escape";
SettingsMenuItems[4] = "MCE Main Menu"


var SettingsMenuItemUUIDs = new Array();
SettingsMenuItemUUIDs[1] = "5ea83688-c7b0-11db-8314-0800200c9a66";   // Display

// Create more menu items listing
var RadioMenuItems = new Array();
RadioMenuItems[0] = "Play/Pause";   
RadioMenuItems[1] = "Stop Live Radio";         
RadioMenuItems[2] = "MCE Main Menu";         

// Create more menu items listing
var TVMenuItems = new Array();
TVMenuItems[0] = "Record"; 
TVMenuItems[1] = "Stop Recording"; 
TVMenuItems[2] = "Closed Captioning"; 
TVMenuItems[3] = "Select TV Menu"; 
TVMenuItems[4] = "MCE Main Menu"; 

// Create more menu items listing
var selectTVMenuItems = new Array();
selectTVMenuItems[0] = "Live TV";
selectTVMenuItems[1] = "Recorded TV";
selectTVMenuItems[2] = "Search";     //--------------------> Edit this if you don't 					//have a querty keyboard

selectTVMenuItems[3] = "Guide";
selectTVMenuItems[4] = "Movies";

// Create more menu items listing
var recordMenuItems = new Array();
recordMenuItems[0] = "Stop";
recordMenuItems[1] = "Nevermind";      

// Create more menu items listing
var moreVideoMenuItems = new Array();
moreVideoMenuItems[0] = "Mute/Unmute";
moreVideoMenuItems[1] = "Stop";
moreVideoMenuItems[2] = "Aspect";
moreVideoMenuItems[3] = "MCE Main Menu";

// Create more menu items listing
var moreRecTVMenuItems = new Array();
moreRecTVMenuItems[0] = "Mute/Unmute";
moreRecTVMenuItems[1] = "Stop";
moreRecTVMenuItems[2] = "Closed Captioning";
moreRecTVMenuItems[3] = "MCE Main Menu";

var DVDMenuItems = new Array();
DVDMenuItems[0] = "Next Chapter";   
DVDMenuItems[1] = "Previous Chapter";
DVDMenuItems[2] = "Mute/ Unmute";
DVDMenuItems[3] = "Subtitles";
DVDMenuItems[4] = "Audio Selections";
DVDMenuItems[5] = "Aspect";
DVDMenuItems[6] = "Stop";
DVDMenuItems[7] = "Title Menu";
DVDMenuItems[8] = "Eject Disc";
DVDMenuItems[9] = "MCE Main Menu";

//====================================== * LAUNCH * ==================================

{
    var Menu = CreateListScreen( "Menu_");
    Menu.name = "MainMenu";
    Menu.title = "Media Center";
    Menu.selectedItem = 0;
    Menu.itemLabels = MenuItems;
    theTerminal.Push( Menu );
}

function getAppPath()
//================== #vvvvvvv INSTALL PATH (edit below) vvvvvv ============
{




                           var path = "C://windows//ehome//ehshell.exe"; 
    
                                                 return path;





}
//====================================== *^^^^ INSTALL PATH ^^^^  ========
function launch()
{
    var shell = new ActiveXObject("Shell.Application");
    shell.ShellExecute(getAppPath(), "" )
}



// FileSystemObject for use in this script
var fso = new ActiveXObject( "Scripting.FileSystemObject" );

// Settings (persisted in txt file)
var setting_artwork_layout = 1;
var setting_moremenu_item = 0;

// Read settings for this script
try {
   var settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
   if( settingsFileStream == null ) {
      // Write defaults
      writeSettings();
      settingsFileStream = fso.OpenTextFile( settingsPath + "\\settings.txt", 1, false );
   }
   while( true ) {
      var propertyName = settingsFileStream.ReadLine();
      var propertyValue = settingsFileStream.ReadLine();
      if( propertyName == "setting_artwork_layout" ) {
         setting_artwork_layout = parseInt( propertyValue );
      } else if( propertyName == "setting_moremenu_item" ) {
         setting_moremenu_item = parseInt( propertyValue );
      }
   }
} catch( e ) {
} finally {
   if( settingsFileStream != null ) settingsFileStream.Close();
}



launch();



//=============================== * MAIN MENU OPTIONS * ===============

function showMenu()
{
    var Menu = CreateListScreen( "Menu_");
    Menu.name = "MainMenu";
    Menu.title = "Media Center";
    Menu.selectedItem = 0;
    Menu.itemLabels = MenuItems;
    theTerminal.Push( Menu );
}


function Menu_ValueUpdated(theScreen, theProperty)
{
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
var option = MenuItems[ theScreen.selectedItem];


    if( option == "Videos" )
    {   showNavVideokeypad(); 
        SendVirtualKeystroke( 0x45, false, true, false, false );
        return true;
    }

    else if( option == "Music" )
    {  
        showNavMusickeypad();
        SendVirtualKeystroke( 0x4d, false, true, false, false );
        return true; 
    }


    else if( option == "Pictures" )
    {
        showNavPicskeypad();     
        SendVirtualKeystroke( 0x49, false, true, false, false );
        return true;
    }

    else if( option == "TV" )
    { 
        showselectTVMenu(); 
        SendVirtualKeystroke( 0x54, true, true, false, false );
        return true;
    }

    else if( option == "Radio" )
    {
        showNavRadiokeypad();   
        SendVirtualKeystroke( 0x41, false, true, false, false );
        return true;    
    }

    else if( option == "Weather" )
    {  
        theTerminal.ExecuteScript(MenuItemUUIDs[theScreen.selectedItem]);    
        return true; 
    }

    else if( option == "Alarm Clock" )
    {  
        theTerminal.ExecuteScript(MenuItemUUIDs[theScreen.selectedItem]);    
        return true; 
    }
 
    else if( option == "DVD" )   
    {
        SendVirtualKeystroke( 0x4d, true, true, false, false);    
        showDVDkeypad();
        return true;     }

    else if( option == "(Directionals)" )    
    {
        showgeneralNavigatorkeypad();
        return true;
    }
    
    else if( option == "Close MediaCenter" )
    {
        SendVirtualKeystroke( 0x73, false, false, true, false);    
        return false;
    }
    
 else {
    return true;
        }   
   // Keep the keypad active
   return true; 
}
}

//================================= * NAV Music Menu * ========================




function showNavMusickeypad() 

{
var NavMusickeypad = CreateMediaPlayerScreen( "NavMusickeypad_" );
NavMusickeypad.title = "My Music";
NavMusickeypad.name = "Music";
NavMusickeypad.CreateRow( "", sccenter, scWrap, scmedium );
NavMusickeypad.CreateRow( "Music Menu Mode", sccenter, scWrap, scLarge );
NavMusickeypad.CreateRow( "", sccenter, scWrap, scsmall );
NavMusickeypad.CreateRow( "", sccenter, scWrap, scsmall );

   theTerminal.Push( NavMusickeypad );    
}

function NavMusickeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {        
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
  case "0x0020":
    SendVirtualKeystroke( 0x20, false, false, false, false);
    break;
  case "0":
    showSettingsMenu();
    break;
  case "*":
    SendVirtualKeystroke( 0x08, false, false, false, false);
    break;
  case "#":
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true);
    break;
  

     
default :
ShowMessage(  );    
}
// Keep the keypad active
keyRepeated = false;
return true;
}

function NavMusickeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "f":
    showSettingsMenu();
    break;                
  case "v":
    SendVirtualKeystroke( 0x22, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x21, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true );
    theTerminal.PopTo("MainMenu");
    break;

default :
ShowMessage(  );    
}
// Keep the keypad active
keyRepeated = false;
return true;
}


function NavMusickeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, false, false); 
    break;
  case "f":        
    theTerminal.ExecuteScript("00f20b76-e7e4-11db-8314-0800200c9a66");
    break;    


default :
ShowMessage(  );    
}
// Keep the keypad active
keyRepeated = false;
return true;
}



//=================================== * sETTINGS * =========================




function showSettingsMenu()
{
    var SettingsMenu = CreateListScreen( "SettingsMenu_");
    SettingsMenu.name = "settings";
    SettingsMenu.title = "Settings";
    SettingsMenu.selectedItem = 0;
    SettingsMenu.itemLabels = SettingsMenuItems;
    theTerminal.Push( SettingsMenu );
}

function SettingsMenu_ValueUpdated(theScreen, theProperty)
{

{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    var option = SettingsMenuItems[ theScreen.selectedItem];


    if( option == "Right-Click Options" )          
    {
         SendVirtualKeystroke( 0x44, false, true, false, false );
         return false;
    }

    else if( option == "More Display Options" )          
    {
        theTerminal.ExecuteScript(SettingsMenuItemUUIDs[theScreen.selectedItem]);    
        return false;
    }

    else if( option == "Back/Escape" )          
    {
        SendVirtualKeystroke( 0x08, false, false, false, false );
        return true;
    }

    else if( option == "Fullscreen" )          
    {
        SendVirtualKeystroke( 0x0d, false, false, true, false );
        return false;
    }


    else if( option == "MCE Main Menu" )          
    {
        SendVirtualKeystroke( 0x0d, false, false, true, true);
        theTerminal.PopTo("MainMenu");       
    }    


    else {
        return true;
    }   
// Keep the keypad active
return true; 
}
}
//================================= * Pictures * ============================
function showNavPicskeypad() 

{
   var NavPicskeypad = CreateMediaplayerScreen( "NavPicskeypad_" );
   NavPicskeypad.title = "Pictures";
   NavPicskeypad.name = "navpics";
   NavPicskeypad.CreateRow( "", sccenter, scWrap, scmedium );
   NavPicskeypad.CreateRow( "Pictures Menu Mode", sccenter, scWrap, scLarge );
   NavPicskeypad.CreateRow( "", sccenter, scWrap, scsmall);
   NavPicskeypad.CreateRow( "", scleft, scWrap, scmedium );

   theTerminal.Push( NavPicskeypad );    

}
function NavPicskeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {        
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;

  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
  case "*":
    SendVirtualKeystroke( 0x08, false, false, false, false); //Backspace        
    break;        
  case "#":	        
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    theTerminal.PopTo("MainMenu");
    break;
  case "0":	        
    showSettingsMenu();
    break;
  case "0x0020":	        
    showSettingsMenu();
    break;
default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;
}

function NavPicskeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
  case "f":
    showSettingsMenu();
    break;                
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true );
    theTerminal.PopTo("MainMenu");
    break;

default :
ShowMessage( theKey );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;
}

function NavPicskeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, false, false); //DOWN ARROW
    break;
case "c":
    SendVirtualKeystroke( 0x08, false, false, false, false); //DOWN ARROW
    break;
  case "f":
    showpicskeypad();
    break;
default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;
}

//=========================================

function showpicskeypad() 
{
   var picskeypad = CreateMediaplayerScreen( "picskeypad_" );
   picskeypad.title = "Slideshow Controller";
   picskeypad.CreateRow( "", scCenter, scWrap, scsmall );
   picskeypad.CreateRow( "Pause/Play/Resume: Center Button", scCenter, scWrap, scMedium );
   picskeypad.CreateRow( "Rew/FFwd: Left/Right", scCenter, scWrap, scMedium );
   picskeypad.CreateRow( "Volume: Up/Down", scCenter, scWrap, scMedium );
   picskeypad.CreateRow( "", scCenter, scWrap, scMedium );
   picskeypad.name = "picskeypad";
 
  theTerminal.Push( picskeypad );
}


function picskeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
   case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
   case "<":
    SendVirtualKeystroke( 0x25, true, true, false, false);
    break;   
   case ">":
    SendVirtualKeystroke( 0x27, true, true, false, false);
    break;                
   case "u":
     SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
   case "d":
    SendVirtualKeystroke( 0xAE, false, false, false, false);
    break;   
  case "#":	        
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    theTerminal.PopTo("MainMenu");
    break;
  case "0":	        
    showmorePicsMenu();
    break;
  case "0x0020":	        
    showmorePicsMenu();
    break;
  case "*":	        
    SendVirtualKeystroke( 0x08, false, false, false, false); //BACKSPACE
    break;        
 
default :
ShowMessage(  );    
}
}

function picskeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {

  case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
  case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true);
    theTerminal.PopTo("MainMenu");
    break;  
  case "f":
    showmorePicsMenu();
    break;
   
default :
ShowMessage(  );    
}
}

function picskeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "f":
    SendVirtualKeystroke( 0x49, false, true, false, false );            theTerminal.PopTo("navpics");
    break; 
  case "s" || "c":
    SendVirtualKeystroke( 0xb3, false, false, false, false);
    break;

default :
ShowMessage(  );    
}
}
//============================================

function showmorePicsMenu()
{
    var morePicsMenu = CreateListScreen( "morePicsMenu_");
    morePicsMenu.name = "morePicsMenu";
    morePicsMenu.title = "More Options";
    morePicsMenu.selectedItem = 0;
    morePicsMenu.itemLabels = morePicsMenuItems;
    theTerminal.Push( morePicsMenu );
}

function morePicsMenu_ValueUpdated(theScreen, theProperty)
{
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    var option = morePicsMenuItems[ theScreen.selectedItem];

    if( option == "Zoom" )     
    {    SendVirtualKeystroke( 0x0d, false, false, false, false);
         return true;         
         
    }

    else if( option == "Right-Click Options" )     
    {    SendVirtualKeystroke( 0x44, false, true, false, false );
	 theTerminal.PopTo("navpictures");
         
    }

    if( option == "Back/Escape" )     
    {    SendVirtualKeystroke( 0x08, false, false, false, false );
         return true;         
         
    }

    else if( option == "MCE Main Menu" )     
    {    SendVirtualKeystroke( 0x0d, false, false, true, true);
         theTerminal.PopTo("MainMenu");
         return true;
    }

    else {
         return true;
        }   
   // Keep the keypad active
   return false; 
}
}




//============================= * RADIO MENU OPTIONS * ==================


function showRadioMenu()
{
    var RadioMenu = CreateListScreen( "RadioMenu_");
    RadioMenu.name = "moreradio";
    RadioMenu.title = "Radio Controls";
    RadioMenu.selectedItem = 0;
    RadioMenu.itemLabels = RadioMenuItems;
    theTerminal.Push( RadioMenu );
}


function RadioMenu_ValueUpdated(theScreen, theProperty)
{
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    var option = RadioMenuItems[ theScreen.selectedItem];


    if( option == "Play/Pause" )
    {         
         SendVirtualKeystroke( 0x50, false, true, false, false); 
         return true;
    }

    else if( option == "Stop Live Radio" )      //--------------------CNTRL+SHIFT+S
    {
         SendVirtualKeystroke( 0x53, true, true, false, false );
         theTerminal.PopTo("navradio")
    }

    else {
         return true;
        }   
// Keep the keypad active
return true; 
}
}

//======================================== * RECORD MENU * ==================


// This will stop recording, or stop playing. It will also resume playing (but not recording)
// It is not possible to pause recording in MCE. 

function showrecordMenu()
{
    var recordMenu = CreateListScreen( "recordMenu_");
    recordMenu.name = "record";
    recordMenu.title = "record";
    recordMenu.selectedItem = 0;
    recordMenu.itemLabels = recordMenuItems;
    theTerminal.Push( recordMenu );
}

function recordMenu_ValueUpdated(theScreen, theProperty)
{

{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    var option = recordMenuItems[ theScreen.selectedItem];


    if( option == "Stop" )             
    {   
        SendVirtualKeystroke( 0x25, false, false, false, false);       
        SendVirtualKeystroke( 0x0d, false, false, false, false);       
 	theTerminal.PopTo("livetv");
    }

    else if( option == "Nevermind" )   
    {
	SendVirtualKeystroke( 0x0d, false, false, false, false );     
	theTerminal.PopTo("livetv");    
    }

    else {
    return true;
    }   
   // Keep the keypad active
   return true; 
}
}

//================================== * Select TV Menu  * =============================

function showselectTVMenu()
{
    var selectTVMenu = CreateListScreen( "selectTVMenu_");
    selectTVMenu.name = "selecttv";
    selectTVMenu.title = "TV Menu";
    selectTVMenu.selectedItem = 0;
    selectTVMenu.itemLabels = selectTVMenuItems;
    theTerminal.Push( selectTVMenu );
}

function selectTVMenu_ValueUpdated(theScreen, theProperty)
{

{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    var option = selectTVMenuItems[ theScreen.selectedItem];

    if( option == "Live TV" )  
    {
         SendVirtualKeystroke( 0x54, false, true, false, false );
         showtvkeypad();
    }

    else if( option == "MCE Main Menu" )          
    {
        SendVirtualKeystroke( 0x0d, false, false, true, true);
        theTerminal.PopTo("MainMenu");
        
    }    


    else if( option == "Recorded TV" )      
    {
         showNavrectvkeypad();   
         SendVirtualKeystroke( 0x4f, false, true, false, false );
         return true;
    }

    else if( option == "Guide" )     
    {
         showNavGuidekeypad();   
         SendVirtualKeystroke( 0x47, false, true, false, false );
         return true;
    }

else if( option == "Movies" )     
    {
         SendVirtualKeystroke( 0x54, true, true, false, false );
       	 SendVirtualKeystroke( 0x28, false, false, false, false );
      	 SendVirtualKeystroke( 0x28, false, false, false, false );
    	 SendVirtualKeystroke( 0x28, false, false, false, false );
     	 SendVirtualKeystroke( 0x28, false, false, false, false );
         SendVirtualKeystroke( 0x0d, false, false, false, false ); 
         showNavmovieMenu();
         return true;
    }    

else if( option == "Search" )     
    {
         SendVirtualKeystroke( 0x54, true, true, false, false );
       	 SendVirtualKeystroke( 0x28, false, false, false, false );
      	 SendVirtualKeystroke( 0x28, false, false, false, false );
     	 SendVirtualKeystroke( 0x28, false, false, false, false );
         SendVirtualKeystroke( 0x0d, false, false, false, false ); 
         showNavsearchMenu();
         return true;
    }    

    else {
    return true;
        }   
   // Keep the keypad active
   return true; 
}
}


//======================================= * LIVE TV MENU OPTIONS * =============================

function showTVMenu()
{
    var TVMenu = CreateListScreen( "TVMenu_");
    TVMenu.name = "moretvmenu";
    TVMenu.title = "More TV Controls";
    TVMenu.selectedItem = 0;
    TVMenu.itemLabels = TVMenuItems;
    theTerminal.Push( TVMenu );
}

function TVMenu_ValueUpdated(theScreen, theProperty)
{

{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    var option = TVMenuItems[ theScreen.selectedItem];



    if( option == "Record" )  
    {
         SendVirtualKeystroke( 0x52, false, true, false, false );
         return false;
    }


    else if( option == "Stop Recording" )     
    {
         SendVirtualKeystroke( 0x53, true, true, false, false );
         showrecordMenu();
         return true;
    }

    else if( option == "Select TV Menu" )     
    {
        SendVirtualKeystroke( 0x54, true, true, false, false );
         theTerminal.PopTo("selecttv")
         return true;
    }
    else if( option == "Closed Captioning" )     
    {
         SendVirtualKeystroke( 0x43, true, true, false, false );
         return false;
    }


    else if( option == "MCE Main Menu" )          
    {
        SendVirtualKeystroke( 0x0d, false, false, true, true);
        theTerminal.PopTo("MainMenu");
        return false;
    }    

    else {
    return true;
    }   
   // Keep the keypad active
   return true; 
}
}

//=========================== * GUIDE * ======================


function showNavGuidekeypad() 

{
var NavGuidekeypad = CreateKeypadScreen( "NavGuidekeypad_" );
NavGuidekeypad.CreateRow( "", scLeft, scWrap, sclarge );
NavGuidekeypad.title = "TV Guide";
NavGuidekeypad.CreateRow( "", sccenter, scWrap, scmedium );
NavGuidekeypad.CreateRow( "TV Guide Menu Mode", sccenter, scWrap, scLarge );
NavGuidekeypad.CreateRow( "", scleft, scWrap, scmedium );
NavGuidekeypad.CreateRow( "Press 'More' for TV Controller", sccenter, scWrap, scsmall );
   theTerminal.Push( NavGuidekeypad );    
}

function NavGuidekeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
   case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
   case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break; 
   case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
   case "0": 
    SendVirtualKeystroke( 0x30, false, false, false, false);
    break;
   case "1":
    SendVirtualKeystroke( 0x31, false, false, false, false);
    break;
   case "2":
    SendVirtualKeystroke( 0x32, false, false, false, false);
    break;
   case "3": 
    SendVirtualKeystroke( 0x33, false, false, false, false);
    break;
   case "4":
    SendVirtualKeystroke( 0x34, false, false, false, false);
    break;
   case "5":
    SendVirtualKeystroke( 0x35, false, false, false, false);
    break;
   case "6":
    SendVirtualKeystroke( 0x36, false, false, false, false);
    break;
   case "7":
    SendVirtualKeystroke( 0x37, false, false, false, false);
    break;
   case "8":
    SendVirtualKeystroke( 0x38, false, false, false, false); 
    break;
   case "9":
    SendVirtualKeystroke( 0x39, false, false, false, false);
    break;
  case "#":	        
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    theTerminal.PopTo("MainMenu");
    break;
  case "0x0020":	        
    showSettingsMenu();
    break;
  case "*":	        
    SendVirtualKeystroke( 0x08, false, false, false, false); //Backspace        
    break;
 
default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;
}

function NavGuidekeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
        
     case "v":
        SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
        break;

     case "^":
        SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
        break;

     case "<":
        SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
        break;
 
     case ">":
        SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
        break;
     case "f":
        showSettingsMenu();
        break;                
     case "s" || "c":
        SendVirtualKeystroke( 0x54, true, true, false, false);
        theTerminal.PopTo("selecttv");
        break;
  case "#":	        
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    break;
  case "0x0020":	        
    showSettingsMenu();
    break;
  case "*":	        
    SendVirtualKeystroke( 0x08, false, false, false, false); //Backspace        
    break;
  case "0":	        
    showSettingsMenu();
    break;


default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;

}
function NavGuidekeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "s" || "c":
     SendVirtualKeystroke( 0x0d, false, false, false, false);  
     break;
   case "f":
        showtvkeypad();
        break;


default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;
}

//====================================== RADIO =====================

function showNavRadiokeypad() 
{
var NavRadiokeypad = CreateMediaPlayerScreen( "Navradiokeypad_" );
NavRadiokeypad.title = "Radio";
NavRadiokeypad.name = "navradio";
NavRadiokeypad.CreateRow( "", sccenter, scWrap, scsmall );
NavRadiokeypad.CreateRow( "Radio Station Menu Mode", sccenter, scWrap, scLarge );
NavRadiokeypad.CreateRow( "", sccenter, scWrap, scsmall );
NavRadiokeypad.CreateRow( "Use keypad to enter a station/ select presets", sccenter, scWrap, scsmall );
NavRadiokeypad.CreateRow( "(Hold < and > to FF, REW)", sccenter, scWrap, scsmall );

   theTerminal.Push( NavRadiokeypad );    
}

function Navradiokeypad_KeyDown(theScreen, theKey)
{

var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "0": 
    SendVirtualKeystroke( 0x30, false, false, false, false);
    break;
  case "1":
    SendVirtualKeystroke( 0x31, false, false, false, false);
    break;
  case "2":
    SendVirtualKeystroke( 0x32, false, false, false, false);
    break;
  case "3": 
    SendVirtualKeystroke( 0x33, false, false, false, false);
    break;
  case "4":
    SendVirtualKeystroke( 0x34, false, false, false, false);
    break;
  case "5":
    SendVirtualKeystroke( 0x35, false, false, false, false);
    break;
  case "6":
    SendVirtualKeystroke( 0x36, false, false, false, false);
    break;
  case "7":
    SendVirtualKeystroke( 0x37, false, false, false, false);
    break;
  case "8":
    SendVirtualKeystroke( 0x38, false, false, false, false); 
    break;
  case "9":
    SendVirtualKeystroke( 0x39, false, false, false, false);
    break;
  case "#":
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true);
    break;
  case "*":
    SendVirtualKeystroke( 0x08, false, false, false, false);
    break;
  case "0x0020":	        
    showSettingsMenu();
    break;
   
default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;
}


function Navradiokeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); 
    break;
   case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);              
    break;
   case "<":
    SendVirtualKeystroke( 0x42, false, true, false, false);   //REWIND   
    break;
   case ">":
    SendVirtualKeystroke( 0x46, false, true, false, false);   //FFWD
    break;
   case "f":
    showSettingsMenu();
    break;                
   case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true );    
    theTerminal.PopTo("MainMenu");
    break;


default :
ShowMessage(  );    
}
}

function Navradiokeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "f": 
    showradiocontrollerkeypad();
    break;

   case "s" || "c":
        SendVirtualKeystroke( 0x0d, false, false, false, false); // SELECT
        break;
   case "v":
        SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
        break;
   case "^":
        SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
        break;
   case "<":
        SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
        break;
   case ">":
        SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
        break;

default :
ShowMessage(  );    
}
}

//................................................................................

function showradiocontrollerkeypad()
{
var radiocontrollerkeypad = CreateMediaPlayerScreen( "radiocontrollerkeypad_" );
radiocontrollerkeypad.title = "Radio Controller";
radiocontrollerkeypad.name = "radiocontoller";
radiocontrollerkeypad.CreateRow( "", scCenter, scWrap, scsmall );
radiocontrollerkeypad.CreateRow( "Center: Mute/Unmute", scCenter, scWrap, scMedium );
radiocontrollerkeypad.CreateRow( "Up/ Down: Volume", scCenter, scWrap, scMedium );
radiocontrollerkeypad.CreateRow( "Left/ Right: Seek channels", scCenter, scWrap, scMedium );
radiocontrollerkeypad.CreateRow( "", scCenter, scWrap, scsmall );

theTerminal.Push( radiocontrollerkeypad ); 
}

function radiocontrollerkeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {

   case "0": 
    SendVirtualKeystroke( 0x30, false, false, false, false);
    break;
   case "1":
    SendVirtualKeystroke( 0x31, false, false, false, false);
    break;
   case "2":
    SendVirtualKeystroke( 0x32, false, false, false, false);
    break;
   case "3": 
    SendVirtualKeystroke( 0x33, false, false, false, false);
    break;
   case "4":
    SendVirtualKeystroke( 0x34, false, false, false, false);
    break;
   case "5":
    SendVirtualKeystroke( 0x35, false, false, false, false);
    break;
   case "6":
    SendVirtualKeystroke( 0x36, false, false, false, false);
    break;
   case "7":
    SendVirtualKeystroke( 0x37, false, false, false, false);
    break;
   case "8":
    SendVirtualKeystroke( 0x38, false, false, false, false); 
    break;
   case "9":
    SendVirtualKeystroke( 0x39, false, false, false, false);
    break;
   case "<":
    SendVirtualKeystroke( 0x22, false, false, false, false);
    break;
   case ">":
    SendVirtualKeystroke( 0x21, false, false, false, false);
    break;
   case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
   case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
   case "#":
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true);
    break;
   case "*":
    SendVirtualKeystroke( 0x08, false, false, false, false);
    break; 
  case "0x0020":	        
    showRadioMenu();
    break;
     
default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;
}


function radiocontrollerkeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
   case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
   case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true );
    theTerminal.PopTo("MainMenu");
    break;
   case "f":
     showRadioMenu();
     break;
default :
ShowMessage(  );    
}
}

function radiocontrollerkeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "s" || "c":
     SendVirtualKeystroke( 0x77, false, false, false, false);       
     return true;
   case "f":
    theTerminal.PopTo("navradio");
    break;

default :
ShowMessage(  );    
}
}

//================================= * Movies * ===========================

function showNavmovieMenu() 

{
var NavmovieMenu = CreateMediaPlayerScreen( "NavmovieMenu_" );
   NavmovieMenu.title = "Movies";
   NavmovieMenu.name = "navmovie";
   NavmovieMenu.CreateRow( "", sccenter, scWrap, scmedium );
   NavmovieMenu.CreateRow( "Movie Menu Mode", sccenter, scWrap, scLarge );
   NavmovieMenu.CreateRow( "", scleft, scWrap, scmedium );
   NavmovieMenu.CreateRow( "Press 'More' for TV Controller", sccenter, scWrap, scsmall );
   theTerminal.Push( NavmovieMenu );    
}

function NavmovieMenu_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
  case "*":
    SendVirtualKeystroke( 0x08, false, false, false, false);
    break;
  case "#":	        
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    break;
  case "0x0020":	        
    showSettingsMenu();
    break;
  case "0":	        
    showSettingsMenu();
    break;

default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;
}

function NavmovieMenu_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
  case "s" || "c":
    SendVirtualKeystroke( 0x54, true, true, false, false);
    theTerminal.PopTo("selecttv");
    break;
  case "f":
    showSettingsMenu();
    break;                

default :
ShowMessage( );    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;
}
 
function NavmovieMenu_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, false, false); // SELECT
    break;
  case "f":
    showtvkeypad();
    break;     

default :
ShowMessage( );    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;
}

//================================= * Search * =============================

// |------------------------------------- QWERTY -------------------------|
// |      THE VALUES BELOW MAY NEED TO BE EDITED TO SUIT YOUR KEYBOARD    |
// |----------------------------------------------------------------------|



function showNavsearchMenu() 

{
var NavsearchMenu = CreateMediaPlayerScreen( "NavsearchMenu_" );
 NavsearchMenu.title = "Search";
 NavsearchMenu.name = "letters";
 NavsearchMenu.CreateRow( "Enter Letters", sccenter, scWrap, sclarge );
 NavsearchMenu.CreateRow( "Press 'More' to enter Numbers", sccenter, scWrap, scsmall);
 NavsearchMenu.CreateRow( "Press 'Delete' to go back", sccenter, scWrap, scsmall);
 NavsearchMenu.CreateRow( "Hold 'More' for TV Controller", sccenter, scWrap, scsmall);
 NavsearchMenu.CreateRow( "Hold 'Center' for Main Menu", sccenter, scWrap, scsmall);
   
   theTerminal.Push( NavsearchMenu );    
}

function NavsearchMenu_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
 
  case "1":
    SendVirtualKeystroke( 0x57, false, false, false, false);
    break;
  case "2":
    SendVirtualKeystroke( 0x45, false, false, false, false);
    break;
  case "3":
    SendVirtualKeystroke( 0x52, false, false, false, false);
    break;
  case "4":
    SendVirtualKeystroke( 0x53, false, false, false, false);
    break;
  case "5":
    SendVirtualKeystroke( 0x44, false, false, false, false);
    break;
  case "6":
    SendVirtualKeystroke( 0x46, false, false, false, false);
    break;
  case "7":
    SendVirtualKeystroke( 0x58, false, false, false, false);
    break;
  case "8":
    SendVirtualKeystroke( 0x43, false, false, false, false);
    break;
  case "9":
    SendVirtualKeystroke( 0x56, false, false, false, false);
    break;
  case "0": 
    showSettingsMenu();
    break;

  case "0x0008":
    SendVirtualKeystroke( 0x08, false, false, false, false);  //DELETE
    break;

  case "'t'":
    SendVirtualKeystroke( 0x54, false, false, false, false);
    break;
  case "'y'":
    SendVirtualKeystroke( 0x59, false, false, false, false);
    break;
  case "'u'":
    SendVirtualKeystroke( 0x55, false, false, false, false);
    break;
  case "'i'":
    SendVirtualKeystroke( 0x49, false, false, false, false);
    break;
  case "'o'":
    SendVirtualKeystroke( 0x4f, false, false, false, false);
    break;
  case "'p'":
    SendVirtualKeystroke( 0x50, false, false, false, false);
    break;
  case "'q'":
    SendVirtualKeystroke( 0x51, false, false, false, false);
    break;
  case "#":
    SendVirtualKeystroke( 0x41, false, false, false, false);
    break;
  case "*":
    SendVirtualKeystroke( 0x5a, false, false, false, false);
    break;
  case "'g'":
    SendVirtualKeystroke( 0x47, false, false, false, false);
    break;
  case "'h'":
    SendVirtualKeystroke( 0x48, false, false, false, false);
    break;
  case "'j'":
    SendVirtualKeystroke( 0x4a, false, false, false, false);
    break;
  case "'k'":
    SendVirtualKeystroke( 0x4b, false, false, false, false);
    break;
  case "'l'":
    SendVirtualKeystroke( 0x4c, false, false, false, false);
    break;
  case "'b'":
    SendVirtualKeystroke( 0x42, false, false, false, false);
    break;
  case "'n'":
    SendVirtualKeystroke( 0x4e, false, false, false, false);
    break;
  case "'m'":
    SendVirtualKeystroke( 0x4d, false, false, false, false);
    break;
  case "0x0020":
    SendVirtualKeystroke( 0x20, false, false, false, false);  //SPACEBAR
    break;
  case "','":
    SendVirtualKeystroke( 0xbc, false, false, false, false); //COMMA
    break;
  case "'.'":
    SendVirtualKeystroke( 0xbe, false, false, false, false); //PERIOD
    break; 

default :
ShowMessage();    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;
}

function NavsearchMenu_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    SendVirtualKeystroke( 0x54, true, true, false, false);
    theTerminal.PopTo("selecttv");
    break;     
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
  case "f":
    showtvkeypad();
    break;

default :
ShowMessage( );    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;
}
 
function NavsearchMenu_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, false, false); // SELECT
    break;
  case "f":
    shownumberkeypad();
    break;                

default :
ShowMessage( );    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;
}


function shownumberkeypad()
{
var numberkeypad = CreateMediaPlayerScreen( "numberkeypad_" );
   numberkeypad.title = "Search";
   numberkeypad.name = "numbers";
   numberkeypad.CreateRow( "", sccenter, scWrap, scmedium );
   numberkeypad.CreateRow( "Enter Numbers", sccenter, scWrap, sclarge );
   numberkeypad.CreateRow( "", sccenter, scWrap, scsmall );
   numberkeypad.CreateRow( "Press 'Center' to return/ enter Letters", sccenter, scWrap, scsmall );

   theTerminal.Push( numberkeypad );    
}

function numberkeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  
  case "','":
    SendVirtualKeystroke( 0xbc, false, false, false, false); //DOWN ARROW    break;
    break;
  case "'.'":
    SendVirtualKeystroke( 0xbe, false, false, false, false); //DOWN ARROW    break;
    break;
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
   case "0": 
    SendVirtualKeystroke( 0x30, false, false, false, false);
    break;
   case "1":
    SendVirtualKeystroke( 0x31, false, false, false, false);
    break;
   case "2":
    SendVirtualKeystroke( 0x32, false, false, false, false);
    break;
   case "3": 
    SendVirtualKeystroke( 0x33, false, false, false, false);
    break;
   case "4":
    SendVirtualKeystroke( 0x34, false, false, false, false);
    break;
   case "5":
    SendVirtualKeystroke( 0x35, false, false, false, false);
    break;
   case "6":
    SendVirtualKeystroke( 0x36, false, false, false, false);
    break;
   case "7":
    SendVirtualKeystroke( 0x37, false, false, false, false);
    break;
   case "8":
    SendVirtualKeystroke( 0x38, false, false, false, false); 
    break;
   case "9":
    SendVirtualKeystroke( 0x39, false, false, false, false);
    break;
  case "0x0008":
    SendVirtualKeystroke( 0x08, false, false, false, false);
    break;
  case "0x0020":
    SendVirtualKeystroke( 0x20, false, false, false, false);
    break;
  case "#":
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true);
    break;
  case "*":
    SendVirtualKeystroke( 0x08, false, false, false, false);
    break;


default :
ShowMessage( );    
}
   // Keep the keypad active
   keyRepeated = false;
   return true;
}

function numberkeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "f":        
    showSettingsMenu();
    break;    
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true );
    theTerminal.PopTo("MainMenu");
    break;
  case "0x0008":
    SendVirtualKeystroke( 0x08, false, false, false, false);
    break;


default :
ShowMessage( );    
}
   // Keep the keypad active
   keyRepeated = false;
   return true;
}


function numberkeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    theTerminal.PopTo("letters");
    SendVirtualKeystroke( 0x0d, false, false, false, false);
    break;
  case "f":
    theTerminal.PopTo("letters");
    break;                

default :
ShowMessage( );    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;
}






//================================= * Videos * ============================
function showNavVideokeypad() 

{
   var NavVideokeypad = CreateMediaplayerScreen( "NavVideokeypad_" );
   NavVideokeypad.title = "Videos";
   NavVideokeypad.name = "navvideo";
   NavVideokeypad.CreateRow( "", sccenter, scWrap, scmedium );
   NavVideokeypad.CreateRow( "Video Menu Mode", sccenter, scWrap, scLarge );
   NavVideokeypad.CreateRow( "", sccenter, scWrap, scsmall);
   NavVideokeypad.CreateRow( "", scleft, scWrap, scmedium );

   theTerminal.Push( NavVideokeypad );    

}
function NavVideokeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {        
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
  case "#":	        
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    break;
  case "0x0020":	        
    showSettingsMenu();
    break;
  case "*":	        
    SendVirtualKeystroke( 0x08, false, false, false, false); //Backspace        
    break;
  case "0":	        
    showSettingsMenu();
    break;

default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;
}

function NavVideokeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
  case "f":
    showSettingsMenu();
    break;                
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true );
    theTerminal.PopTo("MainMenu");
    break;

default :
ShowMessage( theKey );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;
}

function NavVideokeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, false, false); //DOWN ARROW
    break;
  case "f":
    showvideokeypad();
    break;
default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;
}

//=========================================

function showvideokeypad() 
{
   var videokeypad = CreateMediaplayerScreen( "videokeypad_" );
   videokeypad.title = "Video Controller";
   videokeypad.CreateRow( "", scCenter, scWrap, scsmall );
   videokeypad.CreateRow( "Pause/Play/Resume: Center Button", scCenter, scWrap, scMedium );
   videokeypad.CreateRow( "Rew/FFwd: Left/Right", scCenter, scWrap, scMedium );
   videokeypad.CreateRow( "Volume: Up/Down", scCenter, scWrap, scMedium );
   videokeypad.CreateRow( "", scCenter, scWrap, scMedium );
   videokeypad.name = "video";
 
  theTerminal.Push( videokeypad );
}


function videokeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
   case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
   case "<":
    SendVirtualKeystroke( 0x42, true, true, false, false);
    break;   
   case ">":
    SendVirtualKeystroke( 0x46, true, true, false, false);
    break;                
   case "u":
     SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
   case "d":
    SendVirtualKeystroke( 0xAE, false, false, false, false);
    break;   
  case "#":	        
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    break;
  case "0x0020":	        
    showmoreVideoMenu();
    break;
  case "*":	        
    SendVirtualKeystroke( 0x08, false, false, false, false); //Backspace        
    break;
  case "0":	        
    showmoreVideoMenu();
    break;

default :
ShowMessage(  );    
}
}

function videokeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {

  case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
  case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true);
    theTerminal.PopTo("MainMenu");
    break;  
  case "f":
    showmoreVideoMenu();
    break;
   
default :
ShowMessage(  );    
}
}

function videokeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "f":
    SendVirtualKeystroke( 0x45, false, true, false, false);
    theTerminal.PopTo("navvideo");
    break; 
  case "s" || "c":
    SendVirtualKeystroke( 0xb3, false, false, false, false);
    break;

default :
ShowMessage(  );    
}
}
//============================================

function showmoreVideoMenu()
{
    var moreVideoMenu = CreateListScreen( "moreVideoMenu_");
    moreVideoMenu.name = "morevideomenu";
    moreVideoMenu.title = "More Options";
    moreVideoMenu.selectedItem = 0;
    moreVideoMenu.itemLabels = moreVideoMenuItems;
    theTerminal.Push( moreVideoMenu );
}

function moreVideoMenu_ValueUpdated(theScreen, theProperty)
{
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    var option = moreVideoMenuItems[ theScreen.selectedItem];

    if( option == "Mute/Unmute" )          
    {
        SendVirtualKeystroke( 0x77, false, false, false, false );     
        return true;
    }

    else if( option == "Aspect" )          
    {
         SendVirtualKeystroke( 0x5a, true, true, false, false );     
         return true;
    }

    else if( option == "Stop" )          
    {
         SendVirtualKeystroke( 0x53, true, true, false, false );
  	 theTerminal.PopTo("navvideo");
    }

    else if( option == "MCE Main Menu" )          
    {
          theTerminal.PopTo("MainMenu");
	  SendVirtualKeystroke( 0x0d, false, false, true, true );
	  return false;
    }

    else {
         return true;
        }   
   // Keep the keypad active
   return false; 
}
}


//======================================= * Recorded TV * 
function showNavrectvkeypad() 

{
   var Navrectvkeypad = CreateMediaplayerScreen( "Navrectvkeypad_" );
   Navrectvkeypad.title = "Recorded TV";
   Navrectvkeypad.name = "navrectv";
   Navrectvkeypad.CreateRow( "", sccenter, scWrap, scmedium );
   Navrectvkeypad.CreateRow( "Recorded TV Menu Mode", sccenter, scWrap, scLarge );
   Navrectvkeypad.CreateRow( "", sccenter, scWrap, scsmall);
   Navrectvkeypad.CreateRow( "", scleft, scWrap, scmedium );
   theTerminal.Push( Navrectvkeypad );    
}


function Navrectvkeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {        
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW    
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW   
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW  
    break;
  case "#":	        
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    break;
  case "0x0020":	        
    showSettingsMenu();
    break;
  case "*":	        
    SendVirtualKeystroke( 0x08, false, false, false, false); //Backspace   
    break;
  case "0":	        
    showSettingsMenu();
    break;

default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;
}

function Navrectvkeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW    
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW   
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW  
    break;
  case "f":
    showSettingsMenu();
    break;                  
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true );
    theTerminal.PopTo("MainMenu");
    break;

default :
ShowMessage( theKey );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;
}

function Navrectvkeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, false, false); 
    break;
case "f":
    showrectvkeypad();
    break;
default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;
}

//=========================================

function showrectvkeypad() 
{
   var rectvkeypad = CreateMediaplayerScreen( "rectvkeypad_" );
   rectvkeypad.title = "Recorded TV Controller";
   rectvkeypad.name = "rectv";
   rectvkeypad.CreateRow( "", scCenter, scWrap, scsmall );
   rectvkeypad.CreateRow( "Pause/Play/Resume: Center Button", scCenter, scWrap, scMedium );
   rectvkeypad.CreateRow( "Rew/FFwd: Left/Right", scCenter, scWrap, scMedium );
   rectvkeypad.CreateRow( "Volume: Up/Down", scCenter, scWrap, scMedium );
   rectvkeypad.CreateRow( "", scCenter, scWrap, scMedium );
   theTerminal.Push( rectvkeypad );
}


function rectvkeypad_KeyDown(theScreen, theKey)

{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
   case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
   case "d":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
   case "u":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
   case "<":
    SendVirtualKeystroke( 0x42, true, true, false, false);
    break;   
   case ">":
    SendVirtualKeystroke( 0x46, true, true, false, false);
    break;                
  case "#":	        
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    break;
  case "0x0020":	        
    showmoreRecTVMenu();
    break;
  case "*":
    SendVirtualKeystroke( 0x08, false, false, false, false); //Backspace    
    break;
  case "0":	        
    showmoreRecTVMenu();
    break;
 
default :
ShowMessage(  );    
}
}

function rectvkeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {

  case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
  case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true );
    theTerminal.PopTo("MainMenu");
    break;  
  case "f":
    showmoreRecTVMenu();
    break;
    
default :
ShowMessage(  );    
}
}

function rectvkeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    SendVirtualKeystroke( 0x50, false, true, false, false);
    break;
  case "f":
    SendVirtualKeystroke( 0x4f, false, true, false, false );
    theTerminal.PopTo("navrectv");
    break; 

default :
ShowMessage(  );    
}
}
//================================

function showmoreRecTVMenu()
{
    var moreRecTVMenu = CreateListScreen( "moreRecTVMenu_");
    moreRecTVMenu.name = "moreRecTVmenu";
    moreRecTVMenu.title = "More Options";
    moreRecTVMenu.selectedItem = 0;
    moreRecTVMenu.itemLabels = moreRecTVMenuItems;
    theTerminal.Push( moreRecTVMenu );
}

function moreRecTVMenu_ValueUpdated(theScreen, theProperty)
{
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    var option = moreRecTVMenuItems[ theScreen.selectedItem];


    if( option == "Mute/Unmute" )          
    {
        SendVirtualKeystroke( 0x77, false, false, false, false );     
        return true;
    }


    else if( option == "Closed Captioning" )          
    {
         SendVirtualKeystroke( 0x43, true, true, false, false );
         return false;
    }

    else if( option == "Stop" )          
    {
         SendVirtualKeystroke( 0x53, true, true, false, false );
         theTerminal.PopTo("navrectv");
    }

    else if( option == "MCE Main Menu" )          
    {
          theTerminal.PopTo("MainMenu");
	  SendVirtualKeystroke( 0x0d, false, false, true, true );
	  return false;
    }


    else {
    return true;
        }   
   // Keep the keypad active
   return true; 
}
}

//========================= * Live TV Controller: tvkeypad * =====================================

function showtvkeypad()

{
   var tvkeypad = CreateMediaplayerScreen( "tvkeypad_" );
   tvkeypad.title = "Live TV Controller";
   tvkeypad.name = "livetv";
   tvkeypad.CreateRow( "", scCenter, scWrap, scsmall );   
   tvkeypad.CreateRow( "Channels: Left/ Right", scCenter, scWrap, scMedium );
   tvkeypad.CreateRow( "Volume: Up/ Down", scCenter, scWrap, scMedium );
   tvkeypad.CreateRow( "Mute: Center", scCenter, scWrap, scMedium );
   
   theTerminal.Push( tvkeypad ); 
}

function tvkeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "0": 
    SendVirtualKeystroke( 0x30, false, false, false, false);
    break;
   case "1":
    SendVirtualKeystroke( 0x31, false, false, false, false);
    break;
   case "2":
    SendVirtualKeystroke( 0x32, false, false, false, false);
    break;
   case "3": 
    SendVirtualKeystroke( 0x33, false, false, false, false);
    break;
   case "4":
    SendVirtualKeystroke( 0x34, false, false, false, false);
    break;
   case "5":
    SendVirtualKeystroke( 0x35, false, false, false, false);
    break;
   case "6":
    SendVirtualKeystroke( 0x36, false, false, false, false);
    break;
   case "7":
    SendVirtualKeystroke( 0x37, false, false, false, false);
    break;
   case "8":
    SendVirtualKeystroke( 0x38, false, false, false, false); 
    break;
   case "9":
    SendVirtualKeystroke( 0x39, false, false, false, false);
    break;
   case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
   case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
   case "<":
    SendVirtualKeystroke( 0x22, false, false, false, false);
    break;   
   case ">":
    SendVirtualKeystroke( 0x21, false, false, false, false);
    break;   
   case "u":
    SendVirtualKeystroke( 0xAF, false, false, false, false);
    break;
   case "d":
    SendVirtualKeystroke( 0xAE, false, false, false, false);
    break;   
   case "*":
    showSettingsMenu();
    break;                
   case "#":
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true );  //HOME
    break;                
  case "0x0020":	        
    SendVirtualKeystroke( 0x0d, false, false, false, false); 
    break;

default :



ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = false;
   return false;
}

function tvkeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
  case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
  case "u":
    SendVirtualKeystroke( 0xAF, false, false, false, false);
    break;
  case "d":
    SendVirtualKeystroke( 0xAE, false, false, false, false);
    break;   
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true );
    theTerminal.PopTo("selecttv");
    break;
case "f":
    showSettingsMenu();
    break;   

default :
ShowMessage(  );    
}
}

function tvkeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    SendVirtualKeystroke( 0x77, false, false, false, false );
    SendVirtualKeystroke( 0x20, false, false, false, false );
    break;
  case "f":
    showtvplayerkeypad();
    break;   
  

default :
ShowMessage(  );    
}
}

//============================ * tvplayerkeypad * ===============
function showtvplayerkeypad()

{
   var tvplayerkeypad = CreateMediaplayerScreen( "tvplayerkeypad_" );
   tvplayerkeypad.title = "More Live TV Controls";
   tvplayerkeypad.name = "livetvplayer";
   tvplayerkeypad.CreateRow( "", scCenter, scWrap, scsmall );   
   tvplayerkeypad.CreateRow( "Play/Pause: Center", scCenter, scWrap, scMedium );   
   tvplayerkeypad.CreateRow( "FF/REW: Left/ Right", scCenter, scWrap, scMedium );
   tvplayerkeypad.CreateRow( "Volume: Up/ Down", scCenter, scWrap, scMedium );
   tvplayerkeypad.CreateRow( "Hold 'Center' to Stop", scCenter, scWrap, scsmall );   
   theTerminal.Push( tvplayerkeypad ); 
}

//-----------------------------------------

function tvplayerkeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
   case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
   case "<":
    SendVirtualKeystroke( 0x42, true, true, false, false );    
    break;   
   case ">":
    SendVirtualKeystroke( 0x46, true, true, false, false );
    break;   
  case "#":	        
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    break;
  case "*":	        
    showTVMenu();
    break;  
  case "0":	        
    showTVMenu();
    break;
  case "0x0020":	        
    showTVMenu();
    break;
   case "u":
     SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
   case "d":
    SendVirtualKeystroke( 0xAE, false, false, false, false);
    break;   

default :
ShowMessage(  );    
}
}

function tvplayerkeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
  case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
  case "u":
    SendVirtualKeystroke( 0xAF, false, false, false, false);
    break;
  case "d":
    SendVirtualKeystroke( 0xAE, false, false, false, false);
    break;   
  case "f": 
    showTVMenu();
    break;
  case "s" || "c": 
    SendVirtualKeystroke( 0x53, true, true, false, false );
    theTerminal.PopTo("selecttv");
    break;

default :
ShowMessage(  );    
}
}

function tvplayerkeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "f": 
    theTerminal.PopTo("livetv");
    break;
   case "s" || "c": 
    SendVirtualKeystroke( 0x50, false, true, false, false); 
    SendVirtualKeystroke( 0x0d, false, false, false, false); 
    break;

default :
ShowMessage(  );    
}
}


//================================== * General Navigator (Main Menu) * ===============
function showgeneralNavigatorkeypad() 

{
   var generalNavigatorkeypad = CreateMediaplayerScreen( "generalNavigatorkeypad_" );
   generalNavigatorkeypad.title = "Navigation";
   generalNavigatorkeypad.name = "GeneralNavigator";
   generalNavigatorkeypad.CreateRow( "", scCenter, scWrap, scLarge );
   generalNavigatorkeypad.CreateRow( "Find & Select", scCenter, scWrap, scLarge );
   generalNavigatorkeypad.CreateRow( "", scCenter, scWrap, scLarge );
   theTerminal.Push( generalNavigatorkeypad );
}

function generalNavigatorkeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {        
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
  case "#":	        
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    break;
  case "0x0020":	        
    showSettingsMenu();
    break;
  case "*":	        
    SendVirtualKeystroke( 0x08, false, false, false, false); //Backspace        
    break;
  case "0":	        
    showSettingsMenu();
    break;

default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;
}

function generalNavigatorkeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {

  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, false, false);
    break;
  case "f":
    SendVirtualKeystroke( 0x0d, false, false, true, true);
    break;
       
default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;
}

function generalNavigatorkeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
   case "s" || "c":
     SendVirtualKeystroke( 0x0d, false, false, true, true );
     theTerminal.PopTo("MainMenu");
     break;
   case "f":
    showSettingsMenu();
    break;                


default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;
}

//======================================== * DVD * =======================

function showDVDkeypad()
{    
var DVDkeypad = CreateMediaPlayerScreen( "DVDkeypad_" );
DVDkeypad.title = "DVD Navigation";
DVDkeypad.name = "navdvd";
DVDkeypad.CreateRow( "", sccenter, scWrap, scLarge );
DVDkeypad.CreateRow( "DVD Menu Mode", sccenter, scWrap, scLarge );

   theTerminal.Push( DVDkeypad );    
}

function DVDkeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "v":
    SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
    break;
  case "^":
    SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
    break;
  case "<":
    SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
    break;
  case ">":
    SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
    break;
  case "#":	        
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    break;
  case "0x0020":	        
    showSettingsMenu();
    break;
  case "*":	        
    SendVirtualKeystroke( 0x08, false, false, false, false); //Backspace        
    break;
  case "0":	        
    showSettingsMenu();
    break;

default :
ShowMessage(  );    
}

   // Keep the keypad active
   keyRepeated = false;
   return false;
}

function DVDkeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true);
    theTerminal.PopTo("MainMenu")
    break;                
  case "f":
    showSettingsMenu();
    return true;
    break;                

default :
ShowMessage(  );    
}
}
function DVDkeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, false, false); // SELECT
    break;
  case "f":
    showDVDPlayerkeypad();
    break;
   
default :
ShowMessage(  );    
}
}

//==============================================
function showDVDPlayerkeypad()
{

var DVDPlayerkeypad = CreateMediaPlayerScreen( "DVDPlayerkeypad_" );
DVDPlayerkeypad.title = "DVD Player";
DVDPlayerkeypad.name = "DVDPlayer";
DVDPlayerkeypad.CreateRow( "", scCenter, scWrap, scMedium );
DVDPlayerkeypad.CreateRow( "Pause/Play/Resume: Center Button", scCenter, scWrap, scMedium );
DVDPlayerkeypad.CreateRow( "Rew/FFwd: Left/Right", scCenter, scWrap, scMedium );
DVDPlayerkeypad.CreateRow( "Volume: Up/Down", scCenter, scWrap, scMedium );


theTerminal.Push( DVDPlayerkeypad ); 
}

function DVDPlayerkeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
  case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
  case "<":
    SendVirtualKeystroke( 0x42, true, true, false, false);
    break;   
  case ">":
    SendVirtualKeystroke( 0x46, true, true, false, false);
    break;   
  case "u":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
  case "d":
    SendVirtualKeystroke( 0xAE, false, false, false, false);
    break;   
  case "#":	        
    theTerminal.PopTo("MainMenu");
    SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
    break;
  case "0x0020":	        
    showSettingsMenu();
    break;
  case "*":	        
    SendVirtualKeystroke( 0x08, false, false, false, false); //Backspace        
    break;
  case "0":	        
    showDVDMenu();
    break;
 
default :
ShowMessage(  );    
}
}

function DVDPlayerkeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "v":
    SendVirtualKeystroke( 0xae, false, false, false, false);
    break;
  case "^":
    SendVirtualKeystroke( 0xaf, false, false, false, false);
    break;
  case "f":
    showDVDMenu();
    break;
  case "s" || "c":
    SendVirtualKeystroke( 0x0d, false, false, true, true);
    theTerminal.PopTo("MainMenu");
    break;                
   
default :
ShowMessage(  );    
}
}
function DVDPlayerkeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
  case "s" || "c":
    SendVirtualKeystroke( 0xb3, false, false, false, false);
    break;      
  case "f":
    theTerminal.PopTo("navdvd");
    SendVirtualKeystroke( 0x4d, true, true, false, false);   
    break;

default :
ShowMessage(  );    
}
}


//===========================================

function showDVDMenu()
{
    var DVDMenu = CreateListScreen( "DVDMenu_");
    DVDMenu.name = "More DVD options";
    DVDMenu.title = "moredvd";
    DVDMenu.selectedItem = 0;
    DVDMenu.itemLabels = DVDMenuItems;
    theTerminal.Push( DVDMenu );
}

function DVDMenu_ValueUpdated(theScreen, theProperty)
{
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    var option = DVDMenuItems[ theScreen.selectedItem];

    if( option == "Next Chapter" )
    {
        SendVirtualKeystroke( 0x46, false, true, false, false);       
        return true;
    }

    else if( option == "Previous Chapter" )          
    {
         SendVirtualKeystroke( 0x42, false, true, false, false );
         return true;
    }

    else if( option == "Mute/ Unmute" )      
    {
         SendVirtualKeystroke( 0x77, false, false, false, false );
         return true;
    }

    else if( option == "Subtitles" )      
    {
         SendVirtualKeystroke( 0x55, false, true, false, false );
         return true;
    }

    else if( option == "Audio Selections" )      
    {
         SendVirtualKeystroke( 0x41, true, true, false, false );
         return true;
    }

    else if( option == "Aspect" )          
    {
         SendVirtualKeystroke( 0x5a, true, true, false, false );
         return true;
    }

    else if( option == "Stop" )
    {
         SendVirtualKeystroke( 0x53, true, true, false, false );
         theTerminal.PopTo("navdvd");
    }

    else if( option == "Title Menu" )
    {
         SendVirtualKeystroke( 0x4d, true, true, false, false );
	 theTerminal.PopTo("navdvd");
	 
    }


    else if( option == "Eject Disc" )    
    {
     SendVirtualKeystroke( 0x53, true, true, false, false );
     SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
     SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
     SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
     SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
     SendVirtualKeystroke( 0x0d, false, false, false, false); //DOWN ARROW      
     return false;
    }

    else {
    return true;
        }   
   // Keep the keypad active
   return true; 
}
}

