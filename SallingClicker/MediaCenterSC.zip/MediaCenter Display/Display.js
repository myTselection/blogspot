//The 'Monitor Off' option requires the use of Loftzon's 'Monitor Off' Script.

var MenuItems = new Array();
MenuItems[0] = "Monitor On";
MenuItems[1] = "Monitor Off";
MenuItems[2] = "Display to Monitor";
MenuItems[3] = "Display to TV";

var MenuItemUUIDs = new Array();
MenuItemUUIDs[1] = "02165472-7379-11DA-8BDE-F66BAD1E3F3A"; 

{   var Menu = CreateListScreen( "Menu_");
    Menu.name = "Display Settings";
    Menu.title = "Display Settings";
    Menu.selectedItem = 0;
    Menu.itemLabels = MenuItems;
    theTerminal.Push( Menu );
}

 function Menu_ValueUpdated(theScreen, theProperty)

{
	var option = MenuItems[ theScreen.selectedItem];

    
        if( option == "Display to Monitor" ) 
        {
        SendVirtualKeystroke( 0x72, false, true, true, false);         //f3: NOTEBOOK
        return false;
        }
 
        else if( option == "Monitor On" ) 
	{
        var wsh = new ActiveXObject('WScript.Shell');
        if (wsh) {
        wsh.Run("nircmd monitor on");
        }
        return false;
	}

        else if( option == "Monitor Off" ) 
	{
           theTerminal.ExecuteScript(MenuItemUUIDs[theScreen.selectedItem]);   
	
        return false;
	} 
        
        else if( option == "Display to TV" ) 
	{
        SendVirtualKeystroke( 0x71, false, true, true, false);          //f2: TV
        return false;
	}

 else {
	return false;
		}   
   // Keep the keypad active
   return true; 
}
   