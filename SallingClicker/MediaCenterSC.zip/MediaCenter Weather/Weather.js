
function getAppPath()



//****************YOU MAY NEED TO EDIT THIS PATH********************

{
    var path = "C:\\Program Files\\mceWeather\\mceWeather.mcl"; 
//************************************************************************************
    
    
    return path;
}

function launch()
{
    var shell = new ActiveXObject("Shell.Application");
    shell.ShellExecute(getAppPath(), "" )
}

launch();

{
var generalNavigatorkeypad = CreateKeypadScreen( "generalNavigatorkeypad_" );
generalNavigatorkeypad.title = "Weather";
generalNavigatorkeypad.CreateRow( "", sccenter, scWrap, scmedium );
generalNavigatorkeypad.CreateRow( "Weather", sccenter, scWrap, scLarge );
generalNavigatorkeypad.CreateRow( "", sccenter, scWrap, scsmall );
generalNavigatorkeypad.CreateRow( "", sccenter, scWrap, scsmall );
generalNavigatorkeypad.CreateRow( "Press 'More' for Fullscreen", sccenter, scWrap, scsmall );

   theTerminal.Push( generalNavigatorkeypad );    
}


function generalNavigatorkeypad_KeyDown(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
        
     case "v":
	SendVirtualKeystroke( 0x28, false, false, false, false); //DOWN ARROW
	break;

     case "^":
	SendVirtualKeystroke( 0x26, false, false, false, false);  //UP ARROW              
	break;

     case "<":
        SendVirtualKeystroke( 0x25, false, false, false, false); //LEFT ARROW        
	break;

     case ">":
        SendVirtualKeystroke( 0x27, false, false, false, false); //RIGHT ARROW        
	break;
   case "#":	        
       SendVirtualKeystroke( 0x0d, false, false, true, true); //Home        
       theTerminal.PopTo("MainMenu");
       break;
  case "0":	        
       theTerminal.ExecuteScript("5ea83688-c7b0-11db-8314-0800200c9a66");       
       break;
  case "0x0020":	        
        theTerminal.ExecuteScript("5ea83688-c7b0-11db-8314-0800200c9a66");
       break;
  case "*":	        
       SendVirtualKeystroke( 0x08, false, false, false, false); //BACKSPACE
       break;        

     

default :


ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;

}


function generalNavigatorkeypad_KeyRepeat(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {

     case "s":
        SendVirtualKeystroke( 0x0d, false, false, true, true);         
        theTerminal.PopTo("MainMenu");
	break;
    case "f":
        theTerminal.ExecuteScript("5ea83688-c7b0-11db-8314-0800200c9a66");
	break;	
     


default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;

}

function generalNavigatorkeypad_KeyUp(theScreen, theKey)
{
var windowHandle = FindWindow( "eHome Render Window", "" );
if( windowHandle != 0 ) ActivateWindow( windowHandle ); 
    switch (theKey)
    {
    case "s":
        SendVirtualKeystroke( 0x0d, false, false, false, false); // SELECT
        break;

    case "f":
	SendVirtualKeystroke( 0x0d, false, false, true, false);        	 	
	break;

default :
ShowMessage(  );    
}
   // Keep the keypad active
   keyRepeated = true;
   return false;

}