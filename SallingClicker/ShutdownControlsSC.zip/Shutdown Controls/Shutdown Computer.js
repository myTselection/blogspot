var MenuItems = new Array();
var helper = new ActiveXObject("SCHelper.SECHelper");
MenuItems[0] = "Lock Computer";
MenuItems[1] = "Unlock Computer";
MenuItems[2] = "Switch Window";
MenuItems[3] = "Close Program";
MenuItems[4] = "Monitor Off";
MenuItems[5] = "Monitor On";
MenuItems[6] = "Log Off";
MenuItems[7] = "Standby";
MenuItems[8] = "Hibernate";
MenuItems[9] = "Shutdown";
MenuItems[10] = "Reboot";
MenuItems[11] = "Cancel shutdown / reboot";


var Menu = CreateListScreen( "Menu_");
Menu.name = "Shutdown Computer ...";
Menu.title = "Shutdown Computer ...";
Menu.selectedItem = 0;
Menu.itemLabels = MenuItems;
theTerminal.Push( Menu );


function Menu_ValueUpdated(theScreen, theProperty)
{
    var option = MenuItems[ theScreen.selectedItem];
    
    if( option == "Shutdown" ) {
        var wsh = new ActiveXObject('WScript.Shell');
        if (wsh) {
			ShowMessage("SHUTDOWN in 10 sec");	
       		wsh.Run("shutdown -s -t 10");
       		return true;
   		}
    }
 
    else if( option == "Standby" ) 
	{	         
		var wsh = new ActiveXObject('WScript.Shell');
		if (wsh) {
			ShowMessage("STANDBY");	
			wsh.Run("powercfg -h off"), 
			wsh.Run("rundll32.exe powrprof.dll,SetSuspendState");
			return true;
		}
	}

    else if( option == "Hibernate" ) 
	{	         
		var wsh = new ActiveXObject('WScript.Shell');
	 	if (wsh) {
			ShowMessage("HIBERNATE");	
		  	wsh.Run("powercfg -h on"), 
			wsh.Run("rundll32.exe powrprof.dll,SetSuspendState");
			return false;
		}
	}


    else if( option == "Reboot" ) 
	{
        var wsh = new ActiveXObject('WScript.Shell');
		 if (wsh) {
			ShowMessage("REBOOT in 10 sec");	
	  		wsh.Run("shutdown -r -t 10");
	  		return false;
	  	}
	} 
	
    else if( option == "Cancel shutdown / reboot" ) 
	{
        var wsh = new ActiveXObject('WScript.Shell');
		 if (wsh) {
			ShowMessage("Shutdown / reboot canceled");	
	  		wsh.Run("shutdown -a");
	  		return false;
	  	}
	} 
        
    else if( option == "Log Off" ) 
	{
        var wsh = new ActiveXObject('WScript.Shell');
		if (wsh) {
			ShowMessage("LOG OFF");	
	  		wsh.Run("shutdown -l");
	  		return false;
		}
	}

    else if( option == "Close Program" ) 
	{
		SendVirtualKeystroke(0x73, false, false, true, false);
	  	return true;
	}
	
	else if( option == "Switch Window") 
	{
        SendVirtualKeystroke( 0x1b, false, false, true, false );
	  	return true;
	}

    else if( option == "Lock Computer" ) 
	{
        var wsh = new ActiveXObject('WScript.Shell');
		 if (wsh) {
			ShowMessage("LOCK");
	  		wsh.Run("rundll32.exe user32.dll, LockWorkStation");
	        return false;  
		}
	}

    else if( option == "Unlock Computer" ) 
	{
        var wsh = new ActiveXObject('WScript.Shell')
        
		// Set varible to the current date
		var right_now=new Date();
		
		// set variable to current month number (0-11)
		var month_num = right_now.getMonth() + 1;
		if (month_num < 10) {
			month_string = "0" + month_num;
		}
		else {
			month_string = month_num;
		}
		var path = "\"C:\\Documents and Settings\\janssenss\\My Documents\\My Clicker Scripts\\Unlocker\\Unlocker.exe\" janssenss Eva.LOGICA" + month_string;
		if( wsh ) {
			wsh.Run(path);
	        return false;        
		}
	}


    else if( option == "Monitor Off" ) 
	{
        var wsh = new ActiveXObject('WScript.Shell');
		if (wsh) {
			ShowMessage("MONITOR OFF");
			wsh.Run("nircmd monitor off");
	        return false;        
		}
	}
    else if( option == "Monitor On" ) 
	{
        var wsh = new ActiveXObject('WScript.Shell');
		if (wsh) {
			ShowMessage("MONITOR ON");
			wsh.Run("nircmd monitor on");
			return false;
		}
	}
	

     else {
	return false;
		}   
   // Keep the keypad active
   return true; 
}