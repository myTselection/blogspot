var keys = new Array();

keys[32] = " ";
keys[33] = "!";

keys[35] = "#";
keys[36] = "$";
keys[37] = "%";
keys[38] = "&";

keys[40] = "(";
keys[41] = ")";
keys[42] = "*";
keys[43] = "+";
keys[44] = ",";
keys[45] = "-";
keys[46] = ".";

keys[48] = "0";
keys[49] = "1";
keys[50] = "2";
keys[51] = "3";
keys[52] = "4";
keys[53] = "5";
keys[54] = "6";
keys[55] = "7";
keys[56] = "8";
keys[57] = "9";

keys[63] = "?";
keys[64] = "@";
keys[65] = "A";
keys[66] = "B";
keys[67] = "C";
keys[68] = "D";
keys[69] = "E";
keys[70] = "F";
keys[71] = "G";
keys[72] = "H";
keys[73] = "I";
keys[74] = "J";
keys[75] = "K";
keys[76] = "L";
keys[77] = "M";
keys[78] = "N";
keys[79] = "O";
keys[80] = "P";
keys[81] = "Q";
keys[82] = "R";
keys[83] = "S";
keys[84] = "T";
keys[85] = "U";
keys[86] = "V";
keys[87] = "W";
keys[88] = "X";
keys[89] = "Y";
keys[90] = "Z";

keys[97] = "a";
keys[98] = "b";
keys[99] = "c";
keys[100] = "d";
keys[101] = "e";
keys[102] = "f";
keys[103] = "g";
keys[104] = "h";
keys[105] = "i";
keys[106] = "j";
keys[107] = "k";
keys[108] = "l";
keys[109] = "m";
keys[110] = "n";
keys[111] = "o";
keys[112] = "p";
keys[113] = "q";
keys[114] = "r";
keys[115] = "s";
keys[116] = "t";
keys[117] = "u";
keys[118] = "v";
keys[119] = "w";
keys[120] = "x";
keys[121] = "y";
keys[122] = "z";


function launchWidget() {
	var optionList = CreateOptionListDialog( "option_");
	var optionLabels = new Array();
	var widgetValue = 0;
	
	optionLabels.push("Custom print");
	optionLabels.push("Custom show");
	optionLabels.push("Don't touch the computer");
	optionLabels.push("Computer will detonate in 10 seconds");
	optionLabels.push("Hello there!");
	
    optionList.title = "Show a message";
    optionList.itemLabels = optionLabels;
    optionList.value = 0;
	theTerminal.Push(optionList);

}
function option_ValueUpdated(theScreen, theProperty) {
	ShowMessage(theScreen.selectedItem);
}

function option_OK(widget)
{
	widgetValue = widget.value;
	if( widget.value == 0 || widget.value == 1) {
		var textField = CreateTextFieldDialog( "displayMsg_");
		
		textField.name = "Message";
		textField.title = "Display A Message";
		textField.maxLength = 100;
		textField.prompt = "Message:";
		textField.value = "";  
		
		theTerminal.Push(textField); 
	} else {
		ShowMessage(widget.itemLabels[widget.value]);
		launchWidget();
	}
}

function displayMsg_OK(textfield) {
	
	if( widgetValue == 1) {
		ShowMessage(textfield.value);
		launchWidget();
	}
	else if (widgetValue == 0) {
		for (var x = 0; x < textfield.value.length; x++)
		{
			for (var y =0; y < keys.length; y++)
			{
				if (textfield.value.charAt(x) == keys[y]) {
					SendUnicodeKeystroke (y);
				}
			}
		}
		SendVirtualKeystroke(0x0D,false, false, false, false);
		launchWidget();
	}
}

function displayMsg_Cancel(textfield) {
		launchWidget();
}

launchWidget();