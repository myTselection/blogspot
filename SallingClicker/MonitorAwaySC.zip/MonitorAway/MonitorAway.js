var shouldReactivate = false;

function EnteringProximity(theTerminal)
{
	if( shouldReactivate == true ) {
		var wsh = new ActiveXObject('WScript.Shell');
		if (wsh) {
		wsh.Run("nircmd monitor on");
		}
	}
}

function LeavingProximity(theTerminal)
{	
	var wsh = new ActiveXObject('WScript.Shell');
	if (wsh) {
		wsh.Run("nircmd screensaver");
		wsh.Run("nircmd monitor off");
	}
	shouldReactivate = true;
}
