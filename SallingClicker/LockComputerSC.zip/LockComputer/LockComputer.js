function EnteringProximity(theTerminal)
{
	// Need a method of reactivating the user session...
}

function LeavingProximity(theTerminal)
{	
	var wsh = new ActiveXObject('WScript.Shell');
	if( wsh ) {
		wsh.Run("%windir%\\System32\\rundll32.exe user32.dll, LockWorkStation");
	}
}
