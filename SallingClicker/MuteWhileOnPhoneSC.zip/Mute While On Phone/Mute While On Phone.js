var helper = new ActiveXObject("SCHelper.SECHelper");

function CallStatusChanged( theTerminal, theCallStatus, thePhoneNumber, theCallType, theCID )
{
	if( theCallStatus == 1 ) {
	//	Idle
		//helper.systemMute = false;
        var wsh = new ActiveXObject('WScript.Shell');
		if (wsh) {
		  wsh.Run("nircmd mutesysvolume 0");
	   	  ShowMessage("Volume",Volume);
		}
	} else if( theCallStatus == 2 || theCallStatus == 7 ) {
	//	Calling, Alerting
		//helper.systemMute = true;
        var wsh = new ActiveXObject('WScript.Shell');
		if (wsh) {
		  wsh.Run("nircmd mutesysvolume 1");
	   	  ShowMessage("Mute",Mute);
		}
	}
}