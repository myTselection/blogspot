var TBM_GETPOS = 0x400;
var keyRepeated = false;
var sampleRow = null;
var isLaunching = false;

// Initialize more menu items

var moreMenuItems = new Array();
moreMenuItems[0] = "Open Movie";
moreMenuItems[1] = "Quit VLC";

var moreMenuItemUUIDs = new Array();
moreMenuItemUUIDs[0] = "F5179CD8-4D4B-480f-8F97-704466E5F04A";	// Open Movie
moreMenuItemUUIDs[1] = "20566d00-fc02-11da-974d-0800200c9a66";	// Quit VLC


// Check if VLC is installed, and get the exe path if it is.

var VLCPlayerPath = null;
try {
	var wsh = new ActiveXObject("WScript.Shell");
	VLCPlayerPath = wsh.RegRead("HKLM\\SOFTWARE\\VideoLAN\\VLC\\");
} catch( e ) {
Log( "error = " + e.description );
}

if( VLCPlayerPath == null ) {
	var widget = CreatePopupDialog( "" ); // not interested in callbacks
	widget.textualContent = "Cannot find VLC.";
	theTerminal.Push( widget );
	exit();
}

// Check if BSPlayer is launched

var VLCwh = FindVLCWindow();
if( VLCwh == 0 ) {
	var widget = CreateQuestionDialog( "launcher_" );
	widget.textualContent = "Launch VLC?";
	theTerminal.Push( widget );
} else {
	ActivateWindow( VLCwh );
	launchWidget();
}





// Helpers and callbacks

function launchWidget()
{
	var widget = CreateKeypadScreen( "mykeypad_" );
	widget.title = "VLC";
	widget.name = "VLC";
	sampleRow = widget.CreateRow( "", scCenter, scWrap, scLarge );
	theTerminal.Push( widget );
}


function launcher_OK(w)
{
	new ActiveXObject("Shell.Application").ShellExecute( VLCPlayerPath, "--one-instance" );
	isLaunching = true;
	launchWidget();
}

function FindVLCWindow()
{
	var vlcHWND = 0;
	try {
		vlcHWND = FindWindow( "VLC DirectX", "" );
	} catch( e ) {
		vlcHWND = 0;
	}

	if( vlcHWND != 0 ) return vlcHWND;
	

	vlcHWND = 0;
	try {
		vlcHWND = FindWindow( "", "Reproductor de medios VLC" );
	} catch( e ) {
	}

	return vlcHWND;
}

function GetVolumeProgressBar( vlcHWND )
{
	var VolumeHWND = 0;
	try {
		VolumeHWND = FindWindowEx( vlcHWND, 0, "ToolbarWindow32", "" );
		var tmp = FindWindowEx( VolumeHWND, 0, "wxWindowClassNR", "" );
		VolumeHWND = FindWindowEx( VolumeHWND, tmp, "wxWindowClassNR", "" );
		VolumeHWND = FindWindowEx( VolumeHWND, 0, "msctls_progress32", "" );
	} catch( e ) {}
	if( VolumeHWND == 0 ) {
		throw "Wrong skin";
	}
	return VolumeHWND;
}

function GetTimelineTrackBar( vlcHWND )
{
	var trackerHWND = 0;
	try {
		var tmp = FindWindowEx( vlcHWND, 0, "wxWindowClassNR", "panel" );
		tmp = FindWindowEx( vlcHWND, tmp, "wxWindowClassNR", "panel" );
		tmp = FindWindowEx( vlcHWND, tmp, "wxWindowClassNR", "panel" );
		tmp = FindWindowEx( vlcHWND, tmp, "wxWindowClassNR", "panel" );
		trackerHWND = FindWindowEx( tmp, 0, "msctls_trackbar32", "" );
	} catch( e ) {}
	if( trackerHWND == 0 ) {
		throw "Wrong skin";
	}
	return trackerHWND;
}

function mykeypad_Update( theScreen )
{
	try {
	
		var VLC_HWND = FindVLCWindow();
		if( VLC_HWND == 0 ) {
			if( isLaunching ) {
				throw "Launching VLC...";
			} else {			
				throw "VLC not launched.";
			}
		}
		isLaunching = false;		

		//var volumeHWND = GetVolumeProgressBar( VLC_HWND );
		//var volume = SendMessage( volumeHWND, 0x408, 0, 0 );				// 0 - 200
		//theScreen.listeningVolume = volume / 2;

		//var timelineHWND = GetTimelineTrackBar( VLC_HWND );
		//var playheadpos = SendMessage( timelineHWND, TBM_GETPOS, 0, 0 );	// 0-10000

		if( sampleRow != null ) sampleRow.textualContent = "Use the directional controls.";
		

	} catch( e ) {
		if( sampleRow != null ) sampleRow.textualContent = e;
		theScreen.mediaLength = -1;
		theScreen.mediaLength = -1;
		theScreen.playerState = scIndeterminate;
	}
}



function mykeypad_KeyDown( theScreen, theKey )
{	
	try {
		var bspwh = FindVLCWindow();
		ActivateWindow( bspwh );
		
		if( theKey == "^" || theKey == "u" ) {
			SendVirtualKeystroke( 0x26, false, true, false, false );
		} else if( theKey == "v" || theKey == "d" ) {
			SendVirtualKeystroke( 0x28, false, true, false, false );
		} else if( theKey == ">" ) {
			SendVirtualKeystroke( 0x27, false, false, true, false );
		} else if( theKey == "<" ) {
			SendVirtualKeystroke( 0x25, false, false, true, false );
		} else if( theKey == "1" ) {
			SendVirtualKeystroke( 0x74, false, false, false, false );
		}
	} catch( e ) {}

	keyRepeated = false;

	// Keep the keypad active
	return true;
}



function mykeypad_KeyRepeat( theScreen, theKey )
{	
	try {
		var bspwh = FindVLCWindow();
		if( bspwh == 0 ) throw "null player";
				
		if( theKey == "s" && !keyRepeated ) {
			SendVirtualKeystroke( 0x46, false, false, false, false );
		} else if( theKey == "^" || theKey == "u" ) {
			SendVirtualKeystroke( 0x26, false, true, false, false );
		} else if( theKey == "v" || theKey == "d" ) {
			SendVirtualKeystroke( 0x28, false, true, false, false );
		} else if( theKey == ">" ) {
			SendVirtualKeystroke( 0x27, false, false, true, false );
		} else if( theKey == "<" ) {
			SendVirtualKeystroke( 0x25, false, false, true, false );
		} else if( theKey == "1" ) {
			SendVirtualKeystroke( 0x74, false, false, false, false );
		}
	} catch( e ) {}

	keyRepeated = true;
}


function mykeypad_KeyUp( theScreen, theKey )
{	
	try {
		var bspwh = FindVLCWindow();
		if( bspwh == 0 ) throw "null player";

		if( theKey == "s" && ! keyRepeated ) {
			SendVirtualKeystroke( 0x20, false, false, false, false );
		} else if( theKey == "f" ) {
			showMenu();
		} else if (theKey == ":help" || theKey == "#") {
	        showHelp();
		}
	} catch( e ) {}
	
	return true;
}


function showMenu()
{
	var moreMenu = CreateListScreen( "moreMenu_");
	moreMenu.name = "More menu list";
	moreMenu.title = "More";
	moreMenu.selectedItem = 0;
	moreMenu.itemLabels = moreMenuItems;
	theTerminal.Push( moreMenu );
}

function moreMenu_ValueUpdated(theScreen, theProperty)
{
	try {
		var uuid = moreMenuItemUUIDs[theScreen.selectedItem];
		if( uuid == "quit" ) {
			return false;
		} else if( uuid != "" ) {
			theTerminal.ExecuteScript(moreMenuItemUUIDs[theScreen.selectedItem]);	
		}
	} catch( e ) {}
}


function showHelp()
{
    var code = new Array();
    var title = new Array();
    var description = new Array();
    
    code[0] = "s";
    title[0] = "Play/Pause/Full";
    description[0] = "Toggle the player state. Hold to toggle full screen mode.";

    code[1] = new Array("v", "d");
    title[1] = "Volume Down";
    description[1] = "Softens the listening volume.";

    code[2] = new Array("^", "u");
    title[2] = "Volume Up";
    description[2] = "Raises the listening volume.";

    code[3] = new Array("<");
    title[3] = "Rewind";
    description[3] = "Hold to rewind through the currently playing movie.";

    code[4] = new Array(">");
    title[4] = "Fast forward";
    description[4] = "Hold to fast forward through the currently playing movie.";

    code[5] = new Array("1");
    title[5] = "Toggle Full Screen";
    description[5] = "Toggle Full Screen Mode On/Off. To function you must set the key shortcut to F5 on VLC.";

    code[6] = new Array("f", "*");
    title[6] = "More";
    description[6] = "Other settings and commands";



    theTerminal.ShowKeypadHelp("VLC Help", code, title, description);    
}