function CallStatusChanged( theTerminal, theCallStatus, thePhoneNumber, theCallType, theCID )
{
	if( theCallStatus == 7 ) {
		var message = theTerminal.bluetoothName + "\r";
		if( thePhoneNumber != null && thePhoneNumber != "" ) {
			message += "Incoming call from " + thePhoneNumber;
		} else {
			message += "Incoming call";
		}
      ShowMessage( message, NoIcon, -1, 30000 ); 
   }
   	if( theCallStatus == 1 ) {
	//	Idle
		//helper.systemMute = false;
        var wsh = new ActiveXObject('WScript.Shell');
		if (wsh) {
		  wsh.Run("nircmd mutesysvolume 0");
		}
	} else if( theCallStatus == 2 || theCallStatus == 7 ) {
	//	Calling, Alerting
		//helper.systemMute = true;
        var wsh = new ActiveXObject('WScript.Shell');
		if (wsh) {
		  wsh.Run("nircmd mutesysvolume 1");
		}
	}
}