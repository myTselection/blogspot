<?php
/* $Id: berkeleydb.lib.php 8102 2005-12-07 10:28:50Z cybot_tm $ */
// vim: expandtab sw=4 ts=4 sts=4:

include_once './libraries/engines/bdb.lib.php';

class PMA_StorageEngine_berkeleydb extends PMA_StorageEngine_bdb
{
}

?>
