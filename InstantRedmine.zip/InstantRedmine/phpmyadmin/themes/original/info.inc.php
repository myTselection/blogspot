<?php
/* $Id: info.inc.php 9277 2006-08-11 09:22:10Z cybot_tm $ */
/* Theme information */
$theme_name = 'Original';
$theme_full_version = '2.9';
?>
