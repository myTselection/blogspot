﻿Instructions
-------------

1. Unzip

2. Execute "DropBox Portable.exe", follow the Dropbox initial configuration wizard

3. Close Dropbox Portable (in system tray).

3. Place latest Dropbox executable SETUP file inside ".config\update" directory and rename it to "Update.exe"
		"Update.exe" in original .config\update folder is version 0.8.107, use this version for the first initial configuration wizard (else the folder configured in .config\config.cfg might not be respected and user directory will be used)
		"Update.exe" in head folder (next to this "readme.txt") is currently the latest, move it into .config\update
		Latest Dropbox executable setup file can also be downloaded from: https://www.dropbox.com/install

4. If needed: Change your config.cfg settings: you can specify the Dropbox folder name and location in it

5. Execute "DropBox Portable.exe" again
   Don't choose or change your Dropbox Directory directly in Dropbox!!!
   
   
Originally created by Filipe Ferreira http://forums.dropbox.com/topic.php?page=6&id=18638, update by myT http://myTselection.blogspot.com